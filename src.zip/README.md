# OrbitScan MVP

Стартовая кодовая база Android-приложения 3D-сканера объектов.

## Что уже есть

- Kotlin + Jetpack Compose.
- Главный экран OrbitScan.
- Экран настроек.
- Экран сканирования-заглушка.
- UI-симулятор покрытия объекта.
- Виртуальная сетка покрытия 16 × 3 = 48 секторов.
- Состояния секторов: красный / жёлтый / зелёный.
- Расчёт текущего сектора по позиции камеры относительно центра объекта.
- Модели данных: ScanProject, ScanFrame, CameraPose, CameraIntrinsics, CoverageSector.
- Подготовленные интерфейсы ArSessionManager и CameraPoseTracker для Этапа 2.
- ARCore подключён как optional dependency.

## Что пока является заглушкой

- Настоящая ARCore-камера.
- Hit test по объекту.
- Сохранение реальных фото.
- Depth API / Raw Depth API.
- Room/файловое сохранение проекта.
- Серверная реконструкция COLMAP/OpenMVS.
- GLB viewer.

## Как открыть

1. Распакуй проект.
2. Открой папку `OrbitScanMVP` в Android Studio.
3. Дождись Gradle Sync.
4. Запусти `app` на Android-устройстве или эмуляторе.

## Как проверить MVP-симулятор

1. Открой приложение.
2. Нажми `Новый скан`.
3. Нажми `Выбрать объект`.
4. Нажми `Начать`.
5. Нажимай `+ Кадр`.
6. Смотри, как зоны покрытия меняют цвет и растёт процент покрытия.
7. Нажми `Завершить` и открой предпросмотр.

## Следующий этап

Этап 2: заменить FakeCameraSurface на настоящий ARCore SurfaceView/GLSurfaceView, запрашивать camera permission, запускать `Session`, получать `Frame`, `Camera.pose`, `TrackingState`, `CameraIntrinsics`.
