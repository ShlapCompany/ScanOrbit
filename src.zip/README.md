# OrbitScan MVP

Android MVP-кодовая база 3D-сканера объектов.

## Прогресс после текущей итерации

Закрыто:

- Этап 1 — Kotlin + Jetpack Compose, экраны, модели.
- Этап 2 — ARCore camera preview через GLSurfaceView/OpenGL ES, pose tracking, fallback без ARCore.
- Этап 3 — выбор центра объекта через ARCore `Frame.hitTest(x, y)` + размер объекта.
- Этап 4 — виртуальная сетка покрытия 16 × 3, красные/жёлтые/зелёные сектора.
- Этап 5 — автосохранение реальных JPEG-кадров + pose/intrinsics/sector metadata.
- Этап 6 — реальный QualityAnalyzer: яркость, резкость, скорость камеры, reject плохих кадров.
- Этап 7 — сохранение depth/confidence PNG при наличии Depth API + per-frame PLY point cloud + merged `preview_points.ply`.
- Этап 8 — сохранение проектов в `filesDir/scans/<id>/scan_session.json`, список реальных проектов, удаление, thumbnail.
- Этап 9 — клиентская архитектура серверной обработки + mock-реконструкция с прогрессом.
- Этап 10 — экран результата с GLB inspector и resultModelPath. Полноценный Filament/SceneView-рендер GLB оставлен как следующий отдельный хвост.

## Что умеет приложение сейчас

- Запускает ARCore-камеру на поддерживаемом устройстве.
- Позволяет выбрать центр объекта тапом.
- Считает сектор камеры относительно центра объекта.
- Автоматически сохраняет полезные кадры.
- Не засчитывает сектор как GOOD, пока JPEG реально не сохранён.
- Анализирует яркость и размытие по Y-плоскости кадра.
- Сохраняет depth/confidence и PLY point cloud, если Depth API отдаёт данные.
- Пишет `scan_session.json` со списком кадров, camera pose, camera intrinsics, качеством и секторами.
- Показывает реальные проекты на главном экране.
- Открывает конкретный проект в предпросмотре.
- Запускает mock-обработку: CREATED → UPLOADING → ... → DONE.
- Создаёт минимальный валидный `output/model.glb` для проверки клиентской цепочки.

## Что пока осталось честным хвостом

- Полноценный сервер FastAPI/COLMAP/OpenMVS вместо `MockReconstructionApi`.
- Настоящий native GLB renderer через Filament/SceneView вместо текущего GLB inspector.
- Возврат в уже открытый проект для досъёмки, а не старт нового скана.
- Экспорт ZIP проекта / share sheet.
- Настройки через DataStore.

## Где лежит проект скана

В приватном хранилище приложения:

```text
filesDir/scans/<projectId>/
  scan_session.json
  frames/frame_0001.jpg
  depth/depth_0001.png
  depth/confidence_0001.png
  preview/thumbnail.jpg
  preview/points_0001.ply
  preview/preview_points.ply
  output/model.glb
  logs/scan_log.txt
```

## Как проверить

1. Открой проект в Android Studio.
2. Запусти на реальном Android-устройстве с ARCore.
3. Нажми `Новый скан`.
4. Дай разрешение на камеру.
5. Тапни по объекту/поверхности рядом с ним.
6. Нажми `Начать сканирование` и медленно обойди объект.
7. Нажми `Завершить` → `Открыть`.
8. В предпросмотре проверь карту покрытия, список кадров и depth/point cloud статистику.
9. Нажми `Отправить на обработку`.
10. Дождись `DONE`; в проекте появится `output/model.glb`.

## Важно

Mock-реконструкция не строит настоящую фотограмметрию. Она нужна, чтобы уже сейчас проверить Android-цепочку: скан → сохранённый проект → предпросмотр → отправка → статусы → готовая модель. Реальный сервер можно подключить позже, заменив `MockReconstructionApi` на Retrofit/Ktor-клиент.
