package com.karas.orbitscan.reconstruction

import com.karas.orbitscan.storage.ScanSessionWriter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Черновая локальная реконструкция на телефоне.
 *
 * Это НЕ фотограмметрия и НЕ финальная текстурированная модель. Класс берёт PLY-точки,
 * которые приложение сохранило из ARCore Depth/Raw Depth, переносит их приблизительно
 * в world-space по camera pose и создаёт GLB из маленьких voxel-кубиков.
 *
 * Если Depth API на устройстве не дал точек, локально строить форму пока нечем —
 * тогда нужен серверный/ПК pipeline по фотографиям.
 */
object LocalPointCloudGlbBuilder {
    data class Result(
        val ok: Boolean,
        val message: String,
        val outputPath: String? = null,
        val sourcePoints: Int = 0,
        val voxels: Int = 0
    )

    fun buildDepthPreviewModel(
        details: ScanSessionWriter.ProjectDetails,
        target: File,
        maxVoxels: Int = 650
    ): Result {
        return try {
            val rawPoints = mutableListOf<Vec3>()
            details.frames.forEach { frame ->
                val path = frame.pointCloudPath ?: return@forEach
                val plyFile = File(path)
                if (!plyFile.exists()) return@forEach
                val cameraPosition = frame.cameraPosition?.let { Vec3(it[0], it[1], it[2]) } ?: Vec3.ZERO
                val cameraRotation = frame.cameraRotation
                readAsciiPlyPoints(plyFile, maxPerFrame = 180).forEach { cameraPoint ->
                    // DepthFrameSaver писал +Z как «вперёд», а ARCore camera-space смотрит в -Z.
                    // Инверсия Z делает cloud ближе к ожидаемому world-space превью.
                    val correctedCameraPoint = Vec3(cameraPoint.x, cameraPoint.y, -cameraPoint.z)
                    val worldPoint = if (cameraRotation != null && cameraRotation.size >= 4) {
                        rotateByQuaternion(correctedCameraPoint, cameraRotation) + cameraPosition
                    } else {
                        correctedCameraPoint + cameraPosition
                    }
                    rawPoints.add(worldPoint)
                }
            }

            // Fallback без Depth API: если depth-точек мало, строим облако из
            // ПОЗИЦИЙ КАМЕР (траектория обхода всегда есть). Это не форма объекта,
            // но даёт визуализацию того, откуда снимали — лучше, чем пустой экран.
            val usedCameraFallback = rawPoints.size < 20
            if (usedCameraFallback) {
                rawPoints.clear()
                details.frames.forEach { frame ->
                    frame.cameraPosition?.let { rawPoints.add(Vec3(it[0], it[1], it[2])) }
                }
            }

            if (rawPoints.size < 4) {
                return Result(
                    ok = false,
                    message = "Недостаточно данных для модели: нет ни depth-точек, ни позиций камер.",
                    sourcePoints = rawPoints.size
                )
            }

            val sampled = rawPoints.evenSample(maxVoxels)
            val normalized = normalizeToUnitBox(sampled)
            if (normalized.isEmpty()) {
                return Result(false, "Не удалось нормализовать point cloud", sourcePoints = rawPoints.size)
            }

            val glbBytes = buildVoxelGlb(normalized)
            target.parentFile?.mkdirs()
            target.writeBytes(glbBytes)

            val note = if (usedCameraFallback) {
                "Depth недоступен — построено облако из ${normalized.size} позиций камер (черновое превью)."
            } else {
                "Создан черновой depth GLB: ${normalized.size} voxel из ${rawPoints.size} точек"
            }
            Result(
                ok = true,
                message = note,
                outputPath = target.absolutePath,
                sourcePoints = rawPoints.size,
                voxels = normalized.size
            )
        } catch (e: Exception) {
            Result(false, "Ошибка локальной сборки GLB: ${e.message}")
        }
    }

    /**
     * Экспорт того же point cloud в OBJ (вершины + грани вокселей).
     * OBJ — текстовый формат, открывается почти везде (Blender, Windows 3D Viewer и т.д.).
     * Возвращает Result с путём к .obj.
     */
    fun buildObj(
        details: ScanSessionWriter.ProjectDetails,
        target: File,
        maxVoxels: Int = 650
    ): Result {
        return try {
            val rawPoints = mutableListOf<Vec3>()
            details.frames.forEach { frame ->
                val path = frame.pointCloudPath
                val plyFile = path?.let { File(it) }
                val cameraPosition = frame.cameraPosition?.let { Vec3(it[0], it[1], it[2]) } ?: Vec3.ZERO
                val cameraRotation = frame.cameraRotation
                if (plyFile != null && plyFile.exists()) {
                    readAsciiPlyPoints(plyFile, maxPerFrame = 180).forEach { cp ->
                        val corrected = Vec3(cp.x, cp.y, -cp.z)
                        val world = if (cameraRotation != null && cameraRotation.size >= 4) {
                            rotateByQuaternion(corrected, cameraRotation) + cameraPosition
                        } else corrected + cameraPosition
                        rawPoints.add(world)
                    }
                }
            }
            val usedCameraFallback = rawPoints.size < 20
            if (usedCameraFallback) {
                rawPoints.clear()
                details.frames.forEach { f -> f.cameraPosition?.let { rawPoints.add(Vec3(it[0], it[1], it[2])) } }
            }
            if (rawPoints.size < 4) {
                return Result(false, "Недостаточно данных для OBJ.", sourcePoints = rawPoints.size)
            }

            val normalized = normalizeToUnitBox(rawPoints.evenSample(maxVoxels))
            val obj = buildVoxelObj(normalized)
            target.parentFile?.mkdirs()
            target.writeText(obj)
            Result(
                ok = true,
                message = "OBJ создан: ${normalized.size} вершин-вокселей.",
                outputPath = target.absolutePath,
                sourcePoints = rawPoints.size,
                voxels = normalized.size
            )
        } catch (e: Exception) {
            Result(false, "Ошибка сборки OBJ: ${e.message}")
        }
    }

    /** Строит OBJ-текст: для каждой точки — маленький куб (8 вершин, 12 треугольников). */
    private fun buildVoxelObj(points: List<Vec3>, half: Float = 0.012f): String {
        val sb = StringBuilder()
        sb.append("# OrbitScan local point-cloud export\n")
        sb.append("# vertices as small voxel cubes\n")
        var vBase = 0
        for (p in points) {
            // 8 вершин куба вокруг точки.
            val xs = floatArrayOf(-half, half)
            for (dx in xs) for (dy in xs) for (dz in xs) {
                sb.append("v ${p.x + dx} ${p.y + dy} ${p.z + dz}\n")
            }
            // 12 треугольников (6 граней), индексы OBJ 1-based.
            val f = intArrayOf(
                1,2,4, 1,4,3,   5,8,6, 5,7,8,
                1,5,6, 1,6,2,   3,4,8, 3,8,7,
                1,3,7, 1,7,5,   2,6,8, 2,8,4
            )
            var i = 0
            while (i < f.size) {
                sb.append("f ${vBase + f[i]} ${vBase + f[i+1]} ${vBase + f[i+2]}\n")
                i += 3
            }
            vBase += 8
        }
        return sb.toString()
    }

    private fun readAsciiPlyPoints(file: File, maxPerFrame: Int): List<Vec3> {
        val points = mutableListOf<Vec3>()
        var afterHeader = false
        file.forEachLine { line ->
            if (points.size >= maxPerFrame) return@forEachLine
            val trimmed = line.trim()
            if (!afterHeader) {
                if (trimmed == "end_header") afterHeader = true
                return@forEachLine
            }
            if (trimmed.isBlank()) return@forEachLine
            val parts = trimmed.split(Regex("\\s+"))
            if (parts.size < 3) return@forEachLine
            val x = parts[0].toFloatOrNull() ?: return@forEachLine
            val y = parts[1].toFloatOrNull() ?: return@forEachLine
            val z = parts[2].toFloatOrNull() ?: return@forEachLine
            if (x.isFinite() && y.isFinite() && z.isFinite()) points.add(Vec3(x, y, z))
        }
        return points
    }

    private fun List<Vec3>.evenSample(limit: Int): List<Vec3> {
        if (size <= limit) return this
        val step = size.toFloat() / limit.toFloat()
        return List(limit) { index -> this[(index * step).toInt().coerceIn(0, lastIndex)] }
    }

    private fun normalizeToUnitBox(points: List<Vec3>): List<Vec3> {
        if (points.isEmpty()) return emptyList()
        val minX = points.minOf { it.x }
        val minY = points.minOf { it.y }
        val minZ = points.minOf { it.z }
        val maxX = points.maxOf { it.x }
        val maxY = points.maxOf { it.y }
        val maxZ = points.maxOf { it.z }
        val center = Vec3((minX + maxX) * 0.5f, (minY + maxY) * 0.5f, (minZ + maxZ) * 0.5f)
        val maxSpan = max(max(maxX - minX, maxY - minY), maxZ - minZ).takeIf { it > 0.0001f } ?: return emptyList()
        val scale = 1.6f / maxSpan
        return points.map { (it - center) * scale }
    }

    private fun rotateByQuaternion(v: Vec3, q: FloatArray): Vec3 {
        val x = q[0]
        val y = q[1]
        val z = q[2]
        val w = q[3]

        val tx = 2f * (y * v.z - z * v.y)
        val ty = 2f * (z * v.x - x * v.z)
        val tz = 2f * (x * v.y - y * v.x)

        return Vec3(
            v.x + w * tx + (y * tz - z * ty),
            v.y + w * ty + (z * tx - x * tz),
            v.z + w * tz + (x * ty - y * tx)
        )
    }

    private fun buildVoxelGlb(points: List<Vec3>): ByteArray {
        val positions = ArrayList<Float>(points.size * CUBE_POSITIONS.size)
        val normals = ArrayList<Float>(points.size * CUBE_NORMALS.size)
        val indices = ArrayList<Int>(points.size * CUBE_INDICES.size)
        val halfSize = 0.018f

        points.forEachIndexed { cubeIndex, p ->
            val vertexBase = cubeIndex * 24
            var i = 0
            while (i < CUBE_POSITIONS.size) {
                positions.add(p.x + CUBE_POSITIONS[i] * halfSize)
                positions.add(p.y + CUBE_POSITIONS[i + 1] * halfSize)
                positions.add(p.z + CUBE_POSITIONS[i + 2] * halfSize)
                i += 3
            }
            CUBE_NORMALS.forEach { normals.add(it) }
            CUBE_INDICES.forEach { indices.add(vertexBase + it) }
        }

        val vertexCount = positions.size / 3
        val min = listOf(-1f, -1f, -1f).joinToString(prefix = "[", postfix = "]")
        val max = listOf(1f, 1f, 1f).joinToString(prefix = "[", postfix = "]")

        val positionBytes = positions.size * FLOAT_SIZE
        val normalBytes = normals.size * FLOAT_SIZE
        val indexBytes = indices.size * SHORT_SIZE
        val normalOffset = positionBytes
        val indexOffset = positionBytes + normalBytes
        val binaryLength = positionBytes + normalBytes + indexBytes

        val binary = ByteBuffer.allocate(binaryLength).order(ByteOrder.LITTLE_ENDIAN)
        positions.forEach { binary.putFloat(it) }
        normals.forEach { binary.putFloat(it) }
        indices.forEach { binary.putShort(it.toShort()) }

        val json = """
            {
              "asset": { "version": "2.0", "generator": "OrbitScan local depth preview" },
              "scene": 0,
              "scenes": [{ "nodes": [0] }],
              "nodes": [{ "name": "OrbitScan local depth voxel cloud", "mesh": 0 }],
              "meshes": [{
                "name": "Local depth preview model",
                "primitives": [{
                  "attributes": { "POSITION": 0, "NORMAL": 1 },
                  "indices": 2,
                  "material": 0,
                  "mode": 4
                }]
              }],
              "materials": [{
                "name": "OrbitScan depth preview material",
                "pbrMetallicRoughness": {
                  "baseColorFactor": [0.12, 0.72, 1.0, 1.0],
                  "metallicFactor": 0.0,
                  "roughnessFactor": 0.85
                },
                "doubleSided": true
              }],
              "buffers": [{ "byteLength": $binaryLength }],
              "bufferViews": [
                { "buffer": 0, "byteOffset": 0, "byteLength": $positionBytes, "target": 34962 },
                { "buffer": 0, "byteOffset": $normalOffset, "byteLength": $normalBytes, "target": 34962 },
                { "buffer": 0, "byteOffset": $indexOffset, "byteLength": $indexBytes, "target": 34963 }
              ],
              "accessors": [
                { "bufferView": 0, "byteOffset": 0, "componentType": 5126, "count": $vertexCount, "type": "VEC3", "min": $min, "max": $max },
                { "bufferView": 1, "byteOffset": 0, "componentType": 5126, "count": $vertexCount, "type": "VEC3" },
                { "bufferView": 2, "byteOffset": 0, "componentType": 5123, "count": ${indices.size}, "type": "SCALAR" }
              ]
            }
        """.trimIndent().replace("\n", "").replace(Regex("\\s+"), " ")

        return packGlb(json, binary.array())
    }

    private fun packGlb(json: String, binary: ByteArray): ByteArray {
        val jsonBytes = json.toByteArray(Charsets.UTF_8)
        val paddedJsonLength = jsonBytes.size.padded4()
        val paddedBinaryLength = binary.size.padded4()
        val totalLength = 12 + 8 + paddedJsonLength + 8 + paddedBinaryLength
        val out = ByteBuffer.allocate(totalLength).order(ByteOrder.LITTLE_ENDIAN)
        out.putInt(0x46546C67)
        out.putInt(2)
        out.putInt(totalLength)
        out.putInt(paddedJsonLength)
        out.putInt(0x4E4F534A)
        out.put(jsonBytes)
        repeat(paddedJsonLength - jsonBytes.size) { out.put(0x20.toByte()) }
        out.putInt(paddedBinaryLength)
        out.putInt(0x004E4942)
        out.put(binary)
        repeat(paddedBinaryLength - binary.size) { out.put(0.toByte()) }
        return out.array()
    }

    private fun Int.padded4(): Int = ((this + 3) / 4) * 4

    private data class Vec3(val x: Float, val y: Float, val z: Float) {
        operator fun plus(other: Vec3) = Vec3(x + other.x, y + other.y, z + other.z)
        operator fun minus(other: Vec3) = Vec3(x - other.x, y - other.y, z - other.z)
        operator fun times(value: Float) = Vec3(x * value, y * value, z * value)
        companion object { val ZERO = Vec3(0f, 0f, 0f) }
    }

    private const val FLOAT_SIZE = 4
    private const val SHORT_SIZE = 2

    private val CUBE_POSITIONS = floatArrayOf(
        -1f, -1f, 1f, 1f, -1f, 1f, 1f, 1f, 1f, -1f, 1f, 1f,
        1f, -1f, -1f, -1f, -1f, -1f, -1f, 1f, -1f, 1f, 1f, -1f,
        -1f, -1f, -1f, -1f, -1f, 1f, -1f, 1f, 1f, -1f, 1f, -1f,
        1f, -1f, 1f, 1f, -1f, -1f, 1f, 1f, -1f, 1f, 1f, 1f,
        -1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, -1f, -1f, 1f, -1f,
        -1f, -1f, -1f, 1f, -1f, -1f, 1f, -1f, 1f, -1f, -1f, 1f
    )

    private val CUBE_NORMALS = floatArrayOf(
        0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f,
        0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f,
        -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f,
        1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f,
        0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f,
        0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f
    )

    private val CUBE_INDICES = intArrayOf(
        0, 1, 2, 0, 2, 3,
        4, 5, 6, 4, 6, 7,
        8, 9, 10, 8, 10, 11,
        12, 13, 14, 12, 14, 15,
        16, 17, 18, 16, 18, 19,
        20, 21, 22, 20, 22, 23
    )
}
