package com.karas.orbitscan.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.karas.orbitscan.core.AppLog
import com.karas.orbitscan.core.AppSettings
import com.karas.orbitscan.storage.FileStorageManager

@Composable
fun SettingsScreen(
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val settings = remember { AppSettings(context) }
    val storage = remember { FileStorageManager(context.applicationContext) }

    var scanningEnabled by remember { mutableStateOf(settings.scanningEnabled) }
    var useDepth by remember { mutableStateOf(settings.useDepth) }
    var advancedHints by remember { mutableStateOf(settings.advancedHints) }
    var serverUrl by remember { mutableStateOf(settings.serverUrl) }

    var showLog by remember { mutableStateOf(false) }
    var logText by remember { mutableStateOf("") }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var actionMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Настройки", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)

        // --- Функция сканирования ---
        SettingsSwitchRow(
            title = "Сканирование включено",
            description = "Главный выключатель функции скана. Если выключить — кнопка сканирования будет недоступна.",
            checked = scanningEnabled,
            onCheckedChange = {
                scanningEnabled = it
                settings.scanningEnabled = it
                AppLog.log("Settings", "scanningEnabled = $it")
            }
        )
        SettingsSwitchRow(
            title = "Использовать Depth API",
            description = "Если устройство поддерживает depth — строить грубое облако точек.",
            checked = useDepth,
            onCheckedChange = {
                useDepth = it
                settings.useDepth = it
                AppLog.log("Settings", "useDepth = $it")
            }
        )
        SettingsSwitchRow(
            title = "Расширенные подсказки",
            description = "Показывать советы по качеству кадра и недостающим зонам.",
            checked = advancedHints,
            onCheckedChange = {
                advancedHints = it
                settings.advancedHints = it
            }
        )

        // --- Коннект с компом (Этап 9) ---
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Сервер реконструкции (ПК)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "Адрес компьютера, который будет собирать 3D-модель из фотографий. Пример: http://192.168.0.10:8000",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                OutlinedTextField(
                    value = serverUrl,
                    onValueChange = { serverUrl = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("URL сервера") }
                )
                Button(
                    onClick = {
                        settings.serverUrl = serverUrl.trim()
                        AppLog.log("Settings", "serverUrl сохранён")
                        actionMessage = "Адрес сервера сохранён"
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Сохранить адрес")
                }
            }
        }

        // --- Лог приложения ---
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Лог приложения", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = {
                            logText = AppLog.readAll()
                            showLog = !showLog
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(if (showLog) "Скрыть" else "Показать")
                    }
                    OutlinedButton(
                        onClick = {
                            AppLog.clear()
                            logText = ""
                            actionMessage = "Лог очищен"
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Очистить лог")
                    }
                }
                if (showLog) {
                    SelectionContainer {
                        Text(
                            text = logText.ifBlank { "Лог пуст." },
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 220.dp)
                                .verticalScroll(rememberScrollState())
                        )
                    }
                }
            }
        }

        // --- Опасная зона ---
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Данные", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "Удаляет все сканы и кадры с устройства. Действие необратимо.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Button(
                    onClick = { showDeleteDialog = true },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("УДАЛИТЬ ВСЕ ДАННЫЕ")
                }
            }
        }

        actionMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
        }

        OutlinedButton(onClick = onBackClick, modifier = Modifier.fillMaxWidth()) {
            Text("Назад")
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Удалить все данные?") },
            text = { Text("Все сохранённые сканы, кадры и модели будут удалены безвозвратно.") },
            confirmButton = {
                TextButton(onClick = {
                    val ok = storage.deleteAllData()
                    AppLog.log("Settings", "deleteAllData ok=$ok")
                    actionMessage = if (ok) "Все данные удалены" else "Не удалось удалить данные"
                    showDeleteDialog = false
                }) {
                    Text("Удалить", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Отмена")
                }
            }
        )
    }
}

@Composable
private fun SettingsSwitchRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(description, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}
