package com.karas.orbitscan.domain.model

enum class ScanStatus(val title: String) {
    Draft("Черновик"),
    Scanning("Сканирование"),
    ScanFinished("Скан завершён"),
    Processing("Обработка"),
    ModelReady("Модель готова"),
    Failed("Ошибка")
}
