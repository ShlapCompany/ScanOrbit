package com.karas.orbitscan.ui.viewer

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import io.github.sceneview.SceneView
import io.github.sceneview.node.ModelNode
import io.github.sceneview.rememberCameraManipulator
import io.github.sceneview.rememberEngine
import io.github.sceneview.rememberModelInstance
import io.github.sceneview.rememberModelLoader
import java.io.File

/**
 * Настоящий GLB viewer на SceneView/Filament.
 *
 * Важно: этот экран только РЕНДЕРИТ .glb/.gltf. Он не строит модель.
 * В MVP модель пока создаётся mock-реконструкцией, а позже сюда придёт
 * настоящий GLB с backend/COLMAP/OpenMVS pipeline.
 */
@Composable
fun GlbModelViewer(
    modelPath: String,
    modifier: Modifier = Modifier
) {
    val modelFile = remember(modelPath) { File(modelPath) }
    val modelLocation = remember(modelPath) { Uri.fromFile(modelFile).toString() }
    val engine = rememberEngine()
    val modelLoader = rememberModelLoader(engine)
    Box(
        modifier = modifier.background(Color(0xFF0F1823)),
        contentAlignment = Alignment.Center
    ) {
        if (!modelFile.exists() || modelFile.length() <= 0L) {
            MissingModelMessage(modelPath = modelPath)
            return@Box
        }

        SceneView(
            modifier = Modifier.fillMaxSize(),
            engine = engine,
            modelLoader = modelLoader,
            cameraManipulator = rememberCameraManipulator(),
            autoCenterContent = true,
            autoFitContent = true
        ) {
            val modelInstance = rememberModelInstance(modelLoader, modelLocation)
            if (modelInstance != null) {
                ModelNode(
                    modelInstance = modelInstance,
                    scaleToUnits = 1.0f,
                    autoAnimate = true
                )
            }
        }

        Text(
            text = "Поверните модель пальцем · pinch zoom",
            color = Color.White.copy(alpha = 0.7f),
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(12.dp)
        )
    }
}

@Composable
private fun MissingModelMessage(modelPath: String) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        androidx.compose.foundation.layout.Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "GLB-файл не найден",
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = modelPath,
                color = Color.White.copy(alpha = 0.6f),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(16.dp)
            )
            CircularProgressIndicator(modifier = Modifier.padding(top = 8.dp))
        }
    }
}
