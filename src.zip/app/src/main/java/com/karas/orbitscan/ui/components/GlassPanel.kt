package com.karas.orbitscan.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.karas.orbitscan.ui.theme.OrbitGlass
import com.karas.orbitscan.ui.theme.OrbitGlassStrong
import com.karas.orbitscan.ui.theme.OrbitHairline

/**
 * Этап 5.2 — «стеклянная» панель в стиле iOS-камеры: полупрозрачный тёмный фон
 * + тонкая светлая граница (hairline). Это фирменный элемент оверлея OrbitScan.
 *
 * Примечание: настоящий blur фона (как у iOS) на Compose требует RenderEffect
 * (API 31+) и заметно бьёт по перформансу поверх живой камеры, поэтому используем
 * полупрозрачную заливку — визуально близко, дёшево, работает с minSdk 26.
 */
@Composable
fun GlassPanel(
    modifier: Modifier = Modifier,
    strong: Boolean = false,
    cornerRadius: Dp = 18.dp,
    contentPadding: Dp = 14.dp,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)
    Box(
        modifier = modifier
            .background(if (strong) OrbitGlassStrong else OrbitGlass, shape)
            .border(width = 0.5.dp, color = OrbitHairline, shape = shape)
            .padding(contentPadding)
    ) {
        content()
    }
}
