package com.karas.orbitscan.core

import android.content.Context
import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Простой лог приложения, который пишется в файл и виден в Настройках.
 *
 * Кольцевой по размеру: при превышении лимита старые строки обрезаются,
 * чтобы файл не рос бесконечно. Потокобезопасен (synchronized).
 */
object AppLog {
    private const val MAX_BYTES = 256 * 1024 // 256 KB
    private var logFile: File? = null
    private val sdf = SimpleDateFormat("dd.MM HH:mm:ss", Locale.getDefault())

    fun init(context: Context) {
        if (logFile == null) {
            logFile = File(context.applicationContext.filesDir, "app_log.txt")
        }
    }

    @Synchronized
    fun log(tag: String, message: String) {
        Log.d(tag, message)
        val f = logFile ?: return
        try {
            val line = "${sdf.format(Date())}  [$tag]  $message\n"
            f.appendText(line)
            if (f.length() > MAX_BYTES) trim(f)
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun readAll(): String = try {
        logFile?.takeIf { it.exists() }?.readText() ?: "Лог пуст."
    } catch (e: Exception) {
        "Не удалось прочитать лог: ${e.message}"
    }

    @Synchronized
    fun clear() {
        try {
            logFile?.writeText("")
        } catch (_: Exception) {
        }
    }

    private fun trim(f: File) {
        try {
            // оставляем последнюю половину
            val text = f.readText()
            val keep = text.substring(text.length / 2)
            f.writeText("...(обрезано)\n$keep")
        } catch (_: Exception) {
        }
    }
}
