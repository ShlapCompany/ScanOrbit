package com.karas.orbitscan.reconstruction

/**
 * Контракт для будущего FastAPI/COLMAP сервера.
 * MockReconstructionApi реализует ту же клиентскую цепочку локально.
 */
interface ReconstructionApi {
    suspend fun createJob(projectId: String): String
    suspend fun uploadProject(jobId: String, projectId: String): Boolean
    suspend fun getStatus(jobId: String): ReconstructionStatus
    suspend fun downloadResult(jobId: String, projectId: String): String?
}
