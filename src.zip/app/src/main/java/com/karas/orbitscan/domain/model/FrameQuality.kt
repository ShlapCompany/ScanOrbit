package com.karas.orbitscan.domain.model

data class FrameQuality(
    val brightnessScore: Float,
    val blurScore: Float,
    val cameraSpeedScore: Float,
    val trackingOk: Boolean,
    val hasDepth: Boolean
) {
    val totalScore: Int
        get() = listOf(
            brightnessScore >= 0.45f,
            blurScore >= 0.45f,
            cameraSpeedScore >= 0.45f,
            trackingOk,
            hasDepth
        ).count { it }

    val isAcceptable: Boolean
        get() = trackingOk && brightnessScore >= 0.25f && cameraSpeedScore >= 0.25f
}
