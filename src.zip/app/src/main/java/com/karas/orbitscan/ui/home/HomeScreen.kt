package com.karas.orbitscan.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.karas.orbitscan.domain.model.ScanProject
import com.karas.orbitscan.storage.ScanProjectRepository

@Composable
fun HomeScreen(
    onNewScanClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onOpenProjectClick: () -> Unit
) {
    val projects = remember { ScanProjectRepository().demoProjects() }

    Scaffold { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding),
            contentPadding = PaddingValues(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                HomeHeader(
                    onNewScanClick = onNewScanClick,
                    onSettingsClick = onSettingsClick
                )
            }

            item {
                Text(
                    text = "Проекты",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.SemiBold
                )
            }

            items(projects) { project ->
                ProjectCard(project = project, onOpenProjectClick = onOpenProjectClick)
            }
        }
    }
}

@Composable
private fun HomeHeader(
    onNewScanClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(
            text = "OrbitScan",
            style = MaterialTheme.typography.displaySmall,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "MVP 3D-сканера: AR-покрытие, автокадры и подготовка данных для реконструкции.",
            style = MaterialTheme.typography.bodyLarge
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = onNewScanClick) {
                Text("Новый скан")
            }
            OutlinedButton(onClick = onSettingsClick) {
                Text("Настройки")
            }
        }
    }
}

@Composable
private fun ProjectCard(
    project: ScanProject,
    onOpenProjectClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        onClick = onOpenProjectClick,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(project.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(project.mode.title, style = MaterialTheme.typography.bodyMedium)
                }
                Text(project.status.title, style = MaterialTheme.typography.labelLarge)
            }
            LinearProgressIndicator(
                progress = { project.coveragePercent / 100f },
                modifier = Modifier.fillMaxWidth()
            )
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Покрытие: ${project.coveragePercent}%")
                Text("Фото: ${project.frameCount}")
            }
        }
    }
}
