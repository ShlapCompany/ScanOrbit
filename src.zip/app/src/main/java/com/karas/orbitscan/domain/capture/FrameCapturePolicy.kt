package com.karas.orbitscan.domain.capture

import com.karas.orbitscan.domain.model.FrameQuality

class FrameCapturePolicy(
    private val minDelayMillis: Long = 900L
) {
    private var lastAcceptedAt: Long = 0L
    private val acceptedSectorIds = mutableSetOf<Int>()

    fun shouldCapture(
        nowMillis: Long,
        sectorId: Int,
        quality: FrameQuality
    ): Boolean {
        if (!quality.isAcceptable) return false
        if (nowMillis - lastAcceptedAt < minDelayMillis) return false
        return sectorId !in acceptedSectorIds || quality.totalScore >= 3
    }

    fun markCaptured(nowMillis: Long, sectorId: Int) {
        lastAcceptedAt = nowMillis
        acceptedSectorIds += sectorId
    }

    fun reset() {
        lastAcceptedAt = 0L
        acceptedSectorIds.clear()
    }
}
