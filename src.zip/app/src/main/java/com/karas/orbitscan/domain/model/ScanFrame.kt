package com.karas.orbitscan.domain.model

data class ScanFrame(
    val id: String,
    val imagePath: String,
    val timestampMillis: Long,
    val cameraPose: CameraPose?,
    val cameraIntrinsics: CameraIntrinsics?,
    val sectorId: Int,
    val qualityScore: Int,
    val blurScore: Float,
    val brightnessScore: Float,
    val hasDepth: Boolean,
    val depthPath: String? = null,
    val confidencePath: String? = null,
    val pointCloudPath: String? = null,
    val depthPointCount: Int = 0,
    val depthAverageConfidence: Float = 0f
)
