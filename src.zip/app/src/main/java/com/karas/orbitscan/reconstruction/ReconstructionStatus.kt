package com.karas.orbitscan.reconstruction

enum class ReconstructionStatus(
    val title: String,
    val progress: Int
) {
    Created("CREATED", 2),
    Uploading("UPLOADING", 10),
    Queued("QUEUED", 18),
    FeatureExtraction("FEATURE_EXTRACTION", 28),
    FeatureMatching("FEATURE_MATCHING", 40),
    SparseReconstruction("SPARSE_RECONSTRUCTION", 52),
    DenseReconstruction("DENSE_RECONSTRUCTION", 68),
    Meshing("MESHING", 78),
    Texturing("TEXTURING", 88),
    ExportingGlb("EXPORTING_GLB", 96),
    Done("DONE", 100),
    Failed("FAILED", 0)
}
