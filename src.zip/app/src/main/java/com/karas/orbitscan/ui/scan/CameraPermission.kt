package com.karas.orbitscan.ui.scan

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat

/** Этап 2: маленький хелпер проверки разрешения камеры (без сторонних библиотек). */
object CameraPermission {
    const val PERMISSION = Manifest.permission.CAMERA

    fun isGranted(context: Context): Boolean =
        ContextCompat.checkSelfPermission(context, PERMISSION) == PackageManager.PERMISSION_GRANTED
}
