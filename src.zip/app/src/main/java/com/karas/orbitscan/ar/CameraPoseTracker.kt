package com.karas.orbitscan.ar

import com.karas.orbitscan.domain.model.CameraPose

/**
 * Этап 2-3: будет получать pose из ARCore frame.camera.pose.
 */
interface CameraPoseTracker {
    fun currentPoseOrNull(): CameraPose?
    fun cameraSpeedMetersPerSecond(): Float
}

class StubCameraPoseTracker : CameraPoseTracker {
    override fun currentPoseOrNull(): CameraPose? = null
    override fun cameraSpeedMetersPerSecond(): Float = 0f
}
