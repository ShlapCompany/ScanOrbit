package com.karas.orbitscan.ar

import com.google.ar.core.Pose
import com.karas.orbitscan.domain.model.CameraPose
import com.karas.orbitscan.domain.model.Vector3
import kotlin.math.sqrt

/**
 * Этап 2-3: получает pose из ARCore frame.camera.pose и считает скорость
 * движения камеры (нужно для QualityAnalyzer — "двигайтесь медленнее").
 *
 * Заметка для продолжения: класс хранит только последнюю позицию и время,
 * скорость = расстояние / dt. Этого достаточно для MVP-подсказок.
 */
interface CameraPoseTracker {
    fun currentPoseOrNull(): CameraPose?
    fun cameraSpeedMetersPerSecond(): Float
    /** Вызывается из рендера на каждом ARCore-кадре с актуальным pose. */
    fun onArCorePose(pose: Pose, timestampNanos: Long)
    fun reset()
}

class RealCameraPoseTracker : CameraPoseTracker {

    @Volatile
    private var lastPose: CameraPose? = null

    @Volatile
    private var speed: Float = 0f

    private var lastPositionForSpeed: Vector3? = null
    private var lastTimestampNanos: Long = 0L

    override fun currentPoseOrNull(): CameraPose? = lastPose

    override fun cameraSpeedMetersPerSecond(): Float = speed

    override fun onArCorePose(pose: Pose, timestampNanos: Long) {
        val position = Vector3(pose.tx(), pose.ty(), pose.tz())
        val rotation = FloatArray(4)
        pose.getRotationQuaternion(rotation, 0)
        lastPose = CameraPose(position = position, rotationQuaternion = rotation)

        // Оценка скорости по смещению между кадрами.
        val prevPos = lastPositionForSpeed
        val prevTime = lastTimestampNanos
        if (prevPos != null && prevTime != 0L) {
            val dtSeconds = (timestampNanos - prevTime) / 1_000_000_000f
            if (dtSeconds > 0.0001f) {
                val d = position - prevPos
                val distance = sqrt(d.x * d.x + d.y * d.y + d.z * d.z)
                // Лёгкое сглаживание, чтобы цифра не дёргалась.
                speed = 0.6f * speed + 0.4f * (distance / dtSeconds)
            }
        }
        lastPositionForSpeed = position
        lastTimestampNanos = timestampNanos
    }

    override fun reset() {
        lastPose = null
        speed = 0f
        lastPositionForSpeed = null
        lastTimestampNanos = 0L
    }
}

class StubCameraPoseTracker : CameraPoseTracker {
    override fun currentPoseOrNull(): CameraPose? = null
    override fun cameraSpeedMetersPerSecond(): Float = 0f
    override fun onArCorePose(pose: Pose, timestampNanos: Long) = Unit
    override fun reset() = Unit
}
