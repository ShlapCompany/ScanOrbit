package com.karas.orbitscan.domain.model

data class CameraPose(
    val position: Vector3,
    val rotationQuaternion: FloatArray
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (javaClass != other?.javaClass) return false
        other as CameraPose
        return position == other.position && rotationQuaternion.contentEquals(other.rotationQuaternion)
    }

    override fun hashCode(): Int {
        var result = position.hashCode()
        result = 31 * result + rotationQuaternion.contentHashCode()
        return result
    }
}

data class CameraIntrinsics(
    val focalLengthX: Float,
    val focalLengthY: Float,
    val principalPointX: Float,
    val principalPointY: Float,
    val imageWidth: Int,
    val imageHeight: Int
)
