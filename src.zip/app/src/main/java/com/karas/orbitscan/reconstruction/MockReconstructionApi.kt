package com.karas.orbitscan.reconstruction

import com.karas.orbitscan.domain.model.ScanStatus
import com.karas.orbitscan.storage.FileStorageManager
import com.karas.orbitscan.storage.ScanSessionWriter
import kotlinx.coroutines.delay
import java.util.UUID

/**
 * Этап 9: клиентская часть обработки + mock-сервер.
 *
 * Реальный backend позже должен заменить только этот класс: UI и scan_session.json
 * уже работают через статусы и resultModelPath.
 */
class MockReconstructionApi(
    private val storage: FileStorageManager,
    private val sessionWriter: ScanSessionWriter = ScanSessionWriter()
) : ReconstructionApi {
    override suspend fun createJob(projectId: String): String = UUID.randomUUID().toString()

    override suspend fun uploadProject(jobId: String, projectId: String): Boolean {
        delay(120)
        return storage.sessionJsonFile(projectId).exists()
    }

    override suspend fun getStatus(jobId: String): ReconstructionStatus = ReconstructionStatus.Done

    override suspend fun downloadResult(jobId: String, projectId: String): String? {
        val modelFile = storage.modelGlbFile(projectId)
        return if (modelFile.exists()) modelFile.absolutePath else null
    }

    suspend fun processProject(
        projectId: String,
        onStatus: (ReconstructionStatus) -> Unit
    ): Boolean {
        val jobId = createJob(projectId)
        val sessionFile = storage.sessionJsonFile(projectId)

        val pipeline = listOf(
            ReconstructionStatus.Created,
            ReconstructionStatus.Uploading,
            ReconstructionStatus.Queued,
            ReconstructionStatus.FeatureExtraction,
            ReconstructionStatus.FeatureMatching,
            ReconstructionStatus.SparseReconstruction,
            ReconstructionStatus.DenseReconstruction,
            ReconstructionStatus.Meshing,
            ReconstructionStatus.Texturing,
            ReconstructionStatus.ExportingGlb
        )

        pipeline.forEach { status ->
            onStatus(status)
            sessionWriter.updateProcessingStatus(
                file = sessionFile,
                status = ScanStatus.Processing,
                serverJobId = jobId,
                processingStage = status.title,
                processingProgress = status.progress
            )
            delay(280)
        }

        val modelFile = storage.modelGlbFile(projectId)
        val ok = GlbPlaceholderWriter.writeMinimalGlb(modelFile)
        val finalStatus = if (ok) ReconstructionStatus.Done else ReconstructionStatus.Failed
        onStatus(finalStatus)

        sessionWriter.updateProcessingStatus(
            file = sessionFile,
            status = if (ok) ScanStatus.ModelReady else ScanStatus.Failed,
            serverJobId = jobId,
            processingStage = finalStatus.title,
            processingProgress = finalStatus.progress,
            resultModelPath = if (ok) modelFile.absolutePath else null,
            errorMessage = if (ok) null else "Не удалось создать mock GLB"
        )
        return ok
    }
}
