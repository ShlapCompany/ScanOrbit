package com.karas.orbitscan

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.karas.orbitscan.core.AppLog
import com.karas.orbitscan.ui.OrbitScanApp
import com.karas.orbitscan.ui.theme.OrbitScanTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLog.init(applicationContext)
        AppLog.log("App", "Запуск приложения")
        enableEdgeToEdge()
        setContent {
            OrbitScanTheme {
                OrbitScanApp()
            }
        }
    }
}
