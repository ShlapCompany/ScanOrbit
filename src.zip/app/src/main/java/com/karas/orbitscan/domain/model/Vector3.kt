package com.karas.orbitscan.domain.model

import kotlin.math.sqrt

data class Vector3(
    val x: Float,
    val y: Float,
    val z: Float
) {
    operator fun minus(other: Vector3): Vector3 = Vector3(x - other.x, y - other.y, z - other.z)
    operator fun plus(other: Vector3): Vector3 = Vector3(x + other.x, y + other.y, z + other.z)
    operator fun times(value: Float): Vector3 = Vector3(x * value, y * value, z * value)

    fun length(): Float = sqrt(x * x + y * y + z * z)

    fun normalized(): Vector3 {
        val len = length()
        return if (len <= 0.00001f) Zero else Vector3(x / len, y / len, z / len)
    }

    companion object {
        val Zero = Vector3(0f, 0f, 0f)
    }
}
