package com.karas.orbitscan.ui.scan

import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import com.google.ar.core.Session
import com.karas.orbitscan.ar.CameraPoseTracker
import com.karas.orbitscan.ar.render.ArRenderer
import com.karas.orbitscan.domain.model.Vector3

/**
 * Этап 2-3: Compose-обёртка над GLSurfaceView с ARCore-рендером.
 *
 * Этап 3 добавляет tap-to-select:
 * - ACTION_UP по GLSurfaceView передаётся в ArRenderer.queueObjectSelectionTap(x, y);
 * - ArRenderer на GL-потоке вызывает Frame.hitTest(x, y);
 * - результат возвращается во ViewModel как objectCenter в AR-пространстве.
 */
@Composable
fun ArCameraView(
    sessionProvider: () -> Session?,
    poseTracker: CameraPoseTracker,
    onTrackingState: (Boolean) -> Unit,
    onPoseUpdated: () -> Unit,
    onObjectCenterSelected: (center: Vector3, screenXFraction: Float, screenYFraction: Float) -> Unit,
    onObjectSelectionFailed: () -> Unit,
    // Этап 5: выполняется НА GL-ПОТОКЕ (без mainHandler!), т.к. acquireCameraImage
    // валиден только в пределах этого вызова для текущего frame.
    onArFrameForCapture: (frame: com.google.ar.core.Frame) -> Unit,
    modifier: Modifier = Modifier
) {
    val mainHandler = remember { Handler(Looper.getMainLooper()) }

    AndroidView(
        modifier = modifier,
        factory = { context ->
            val renderer = ArRenderer(
                sessionProvider = sessionProvider,
                poseTracker = poseTracker,
                onTrackingState = { tracking ->
                    mainHandler.post { onTrackingState(tracking) }
                },
                onPoseUpdated = {
                    mainHandler.post { onPoseUpdated() }
                },
                onObjectCenterSelected = { center, xFraction, yFraction ->
                    mainHandler.post { onObjectCenterSelected(center, xFraction, yFraction) }
                },
                onObjectSelectionFailed = {
                    mainHandler.post { onObjectSelectionFailed() }
                },
                // НЕ оборачиваем в mainHandler: захват обязан идти на GL-потоке.
                onArFrameForCapture = { frame -> onArFrameForCapture(frame) }
            )

            GLSurfaceView(context).apply {
                preserveEGLContextOnPause = true
                setEGLContextClientVersion(2)
                setEGLConfigChooser(8, 8, 8, 8, 16, 0)
                setRenderer(renderer)
                renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                setOnTouchListener { view, event ->
                    when (event.actionMasked) {
                        MotionEvent.ACTION_UP -> {
                            renderer.queueObjectSelectionTap(event.x, event.y)
                            view.performClick()
                            true
                        }
                        MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> true
                        else -> false
                    }
                }
            }
        }
    )

    DisposableEffect(Unit) {
        onDispose { /* GLSurfaceView сам остановит рендер при detach */ }
    }
}
