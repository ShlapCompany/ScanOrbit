package com.karas.orbitscan.reconstruction

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Этап 9/10 mock: создаёт минимально валидный GLB 2.0 без mesh-геометрии.
 * Это не результат фотограмметрии, а локальный placeholder, чтобы проверить
 * клиентскую цепочку: scan -> processing -> resultModelPath -> model viewer.
 */
object GlbPlaceholderWriter {
    fun writeMinimalGlb(target: File): Boolean {
        return try {
            val json = """
                {"asset":{"version":"2.0","generator":"OrbitScan Mock Reconstruction"},"scene":0,"scenes":[{"nodes":[0]}],"nodes":[{"name":"OrbitScan placeholder model"}]}
            """.trimIndent()
            val jsonBytes = json.toByteArray(Charsets.UTF_8)
            val paddedJsonLength = ((jsonBytes.size + 3) / 4) * 4
            val totalLength = 12 + 8 + paddedJsonLength
            val buffer = ByteBuffer.allocate(totalLength).order(ByteOrder.LITTLE_ENDIAN)
            buffer.putInt(0x46546C67) // glTF
            buffer.putInt(2)
            buffer.putInt(totalLength)
            buffer.putInt(paddedJsonLength)
            buffer.putInt(0x4E4F534A) // JSON
            buffer.put(jsonBytes)
            repeat(paddedJsonLength - jsonBytes.size) { buffer.put(0x20.toByte()) }
            target.parentFile?.mkdirs()
            target.writeBytes(buffer.array())
            true
        } catch (e: Exception) {
            false
        }
    }
}
