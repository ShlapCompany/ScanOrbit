package com.karas.orbitscan.reconstruction

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Этап 9/10 mock: создаёт валидный GLB 2.0 с простой видимой геометрией.
 * Это не результат фотограмметрии, а локальный placeholder, чтобы проверить
 * клиентскую цепочку: scan -> processing -> resultModelPath -> GLB viewer.
 */
object GlbPlaceholderWriter {
    fun writeMinimalGlb(target: File): Boolean {
        return try {
            val binary = buildCubeBinary()
            val json = buildCubeJson(binary.size)
            val jsonBytes = json.toByteArray(Charsets.UTF_8)
            val paddedJsonLength = jsonBytes.size.padded4()
            val paddedBinaryLength = binary.size.padded4()
            val totalLength = 12 + 8 + paddedJsonLength + 8 + paddedBinaryLength

            val buffer = ByteBuffer.allocate(totalLength).order(ByteOrder.LITTLE_ENDIAN)
            buffer.putInt(0x46546C67) // glTF
            buffer.putInt(2)
            buffer.putInt(totalLength)

            buffer.putInt(paddedJsonLength)
            buffer.putInt(0x4E4F534A) // JSON
            buffer.put(jsonBytes)
            repeat(paddedJsonLength - jsonBytes.size) { buffer.put(0x20.toByte()) }

            buffer.putInt(paddedBinaryLength)
            buffer.putInt(0x004E4942) // BIN\0
            buffer.put(binary)
            repeat(paddedBinaryLength - binary.size) { buffer.put(0.toByte()) }

            target.parentFile?.mkdirs()
            target.writeBytes(buffer.array())
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun buildCubeJson(binaryLength: Int): String {
        val positionBytes = POSITIONS.size * FLOAT_SIZE
        val normalBytes = NORMALS.size * FLOAT_SIZE
        val indexBytes = INDICES.size * SHORT_SIZE
        val normalOffset = positionBytes
        val indexOffset = positionBytes + normalBytes
        val min = listOf(-0.5f, -0.5f, -0.5f).joinToString(prefix = "[", postfix = "]")
        val max = listOf(0.5f, 0.5f, 0.5f).joinToString(prefix = "[", postfix = "]")

        return """
            {
              "asset": { "version": "2.0", "generator": "OrbitScan Mock Reconstruction" },
              "scene": 0,
              "scenes": [{ "nodes": [0] }],
              "nodes": [{ "name": "OrbitScan preview cube", "mesh": 0 }],
              "meshes": [{
                "name": "Mock reconstructed object",
                "primitives": [{
                  "attributes": { "POSITION": 0, "NORMAL": 1 },
                  "indices": 2,
                  "material": 0,
                  "mode": 4
                }]
              }],
              "materials": [{
                "name": "OrbitScan green material",
                "pbrMetallicRoughness": {
                  "baseColorFactor": [0.10, 0.85, 0.35, 1.0],
                  "metallicFactor": 0.0,
                  "roughnessFactor": 0.55
                },
                "doubleSided": true
              }],
              "buffers": [{ "byteLength": $binaryLength }],
              "bufferViews": [
                { "buffer": 0, "byteOffset": 0, "byteLength": $positionBytes, "target": 34962 },
                { "buffer": 0, "byteOffset": $normalOffset, "byteLength": $normalBytes, "target": 34962 },
                { "buffer": 0, "byteOffset": $indexOffset, "byteLength": $indexBytes, "target": 34963 }
              ],
              "accessors": [
                { "bufferView": 0, "byteOffset": 0, "componentType": 5126, "count": 24, "type": "VEC3", "min": $min, "max": $max },
                { "bufferView": 1, "byteOffset": 0, "componentType": 5126, "count": 24, "type": "VEC3" },
                { "bufferView": 2, "byteOffset": 0, "componentType": 5123, "count": 36, "type": "SCALAR" }
              ]
            }
        """.trimIndent().replace("\n", "").replace(Regex("\\s+"), " ")
    }

    private fun buildCubeBinary(): ByteArray {
        val size = POSITIONS.size * FLOAT_SIZE + NORMALS.size * FLOAT_SIZE + INDICES.size * SHORT_SIZE
        val buffer = ByteBuffer.allocate(size).order(ByteOrder.LITTLE_ENDIAN)
        POSITIONS.forEach { buffer.putFloat(it) }
        NORMALS.forEach { buffer.putFloat(it) }
        INDICES.forEach { buffer.putShort(it.toShort()) }
        return buffer.array()
    }

    private fun Int.padded4(): Int = ((this + 3) / 4) * 4

    private const val FLOAT_SIZE = 4
    private const val SHORT_SIZE = 2

    private val POSITIONS = floatArrayOf(
        // Front +Z
        -0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f,
        // Back -Z
        0.5f, -0.5f, -0.5f, -0.5f, -0.5f, -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f,
        // Left -X
        -0.5f, -0.5f, -0.5f, -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, -0.5f,
        // Right +X
        0.5f, -0.5f, 0.5f, 0.5f, -0.5f, -0.5f, 0.5f, 0.5f, -0.5f, 0.5f, 0.5f, 0.5f,
        // Top +Y
        -0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, 0.5f, -0.5f, -0.5f, 0.5f, -0.5f,
        // Bottom -Y
        -0.5f, -0.5f, -0.5f, 0.5f, -0.5f, -0.5f, 0.5f, -0.5f, 0.5f, -0.5f, -0.5f, 0.5f
    )

    private val NORMALS = floatArrayOf(
        0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f,
        0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f,
        -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f,
        1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f,
        0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f,
        0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f, 0f, -1f, 0f
    )

    private val INDICES = intArrayOf(
        0, 1, 2, 0, 2, 3,
        4, 5, 6, 4, 6, 7,
        8, 9, 10, 8, 10, 11,
        12, 13, 14, 12, 14, 15,
        16, 17, 18, 16, 18, 19,
        20, 21, 22, 20, 22, 23
    )
}
