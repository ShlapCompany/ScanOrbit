package com.karas.orbitscan.storage

import com.google.ar.core.Frame
import com.google.ar.core.exceptions.NotYetAvailableException
import com.karas.orbitscan.domain.model.CameraIntrinsics
import com.karas.orbitscan.domain.model.CameraPose
import com.karas.orbitscan.domain.model.FrameQuality
import com.karas.orbitscan.domain.model.ScanFrame
import com.karas.orbitscan.domain.model.Vector3
import com.karas.orbitscan.domain.quality.QualityAnalyzer
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Этап 5-7: координатор реального захвата кадра.
 *
 * Вызов capture() должен идти на GL-потоке текущего ARCore frame:
 * - acquireCameraImage(), acquireDepthImage16Bits()/rawDepth валидны только для current frame;
 * - Image закрываем сразу;
 * - запись JPEG/PNG/PLY переносим в single-thread executor.
 */
class ScanFrameCaptureCoordinator(
    private val storage: FileStorageManager,
    private val jpegQuality: Int = 90,
    private val qualityAnalyzer: QualityAnalyzer = QualityAnalyzer()
) {
    private val ioExecutor = Executors.newSingleThreadExecutor()

    @Volatile
    private var projectId: String? = null

    @Volatile
    private var frameCounter: Int = 0

    fun beginProject(projectId: String) {
        this.projectId = projectId
        this.frameCounter = 0
    }

    fun isActive(): Boolean = projectId != null

    fun capture(
        frame: Frame,
        sectorId: Int,
        cameraSpeedMetersPerSecond: Float,
        trackingOk: Boolean,
        depthEnabled: Boolean,
        onFrameSaved: (ScanFrame, FrameQuality) -> Unit,
        onFrameRejected: (FrameQuality) -> Unit
    ) {
        val pid = projectId ?: return

        val frameIndex = frameCounter + 1
        val targetFile = storage.frameFile(pid, frameIndex)
        val thumbnailFile = storage.thumbnailFile(pid)

        val camera = frame.camera
        val pose = runCatching {
            val p = camera.pose
            val rot = FloatArray(4)
            p.getRotationQuaternion(rot, 0)
            CameraPose(Vector3(p.tx(), p.ty(), p.tz()), rot)
        }.getOrNull()

        val intrinsics = runCatching {
            val intr = camera.imageIntrinsics
            val fl = intr.focalLength
            val pp = intr.principalPoint
            val dim = intr.imageDimensions
            CameraIntrinsics(
                focalLengthX = fl[0],
                focalLengthY = fl[1],
                principalPointX = pp[0],
                principalPointY = pp[1],
                imageWidth = dim[0],
                imageHeight = dim[1]
            )
        }.getOrNull()

        val depthCapture = if (depthEnabled) {
            DepthFrameSaver.captureDepth(frame, intrinsics)
        } else null

        var jpegBytes: ByteArray? = null
        var analyzedQuality: FrameQuality? = null
        try {
            frame.acquireCameraImage().use { image ->
                val q = qualityAnalyzer.analyzeCameraImage(
                    image = image,
                    cameraSpeedMetersPerSecond = cameraSpeedMetersPerSecond,
                    trackingOk = trackingOk,
                    hasDepth = depthCapture != null
                )
                analyzedQuality = q
                if (!q.isAcceptable) {
                    onFrameRejected(q)
                    return
                }
                jpegBytes = FrameImageSaver.yuvImageToJpegBytes(image, jpegQuality) ?: return
            }
        } catch (e: NotYetAvailableException) {
            return
        } catch (e: Throwable) {
            return
        }

        val acceptedJpegBytes = jpegBytes ?: return
        val quality = analyzedQuality ?: return
        frameCounter = frameIndex

        ioExecutor.execute {
            val ok = FrameImageSaver.writeJpeg(acceptedJpegBytes, targetFile)
            if (!ok) return@execute

            if (frameIndex == 1) {
                // Мелкий хвост Этапа 8: первый принятый кадр становится thumbnail.jpg.
                FrameImageSaver.writeJpeg(acceptedJpegBytes, thumbnailFile)
            }

            val depthSaved = depthCapture?.let {
                DepthFrameSaver.writeDepthOutputs(
                    capture = it,
                    depthFile = storage.depthFile(pid, frameIndex),
                    confidenceFile = storage.confidenceFile(pid, frameIndex),
                    pointCloudFile = storage.pointCloudFile(pid, frameIndex)
                )
            }

            val scanFrame = ScanFrame(
                id = UUID.randomUUID().toString(),
                imagePath = targetFile.absolutePath,
                timestampMillis = System.currentTimeMillis(),
                cameraPose = pose,
                cameraIntrinsics = intrinsics,
                sectorId = sectorId,
                qualityScore = quality.totalScore,
                blurScore = quality.blurScore,
                brightnessScore = quality.brightnessScore,
                hasDepth = depthSaved != null,
                depthPath = depthSaved?.depthPath,
                confidencePath = depthSaved?.confidencePath,
                pointCloudPath = depthSaved?.pointCloudPath,
                depthPointCount = depthSaved?.validPointCount ?: 0,
                depthAverageConfidence = depthSaved?.averageConfidence ?: 0f
            )
            onFrameSaved(scanFrame, quality.copy(hasDepth = depthSaved != null))
        }
    }

    fun endProject() {
        projectId = null
        frameCounter = 0
    }

    fun shutdown() {
        ioExecutor.shutdown()
    }
}
