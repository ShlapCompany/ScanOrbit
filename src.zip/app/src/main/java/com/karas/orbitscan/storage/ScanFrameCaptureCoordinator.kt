package com.karas.orbitscan.storage

import com.google.ar.core.Frame
import com.google.ar.core.exceptions.NotYetAvailableException
import com.karas.orbitscan.domain.model.CameraIntrinsics
import com.karas.orbitscan.domain.model.CameraPose
import com.karas.orbitscan.domain.model.ScanFrame
import com.karas.orbitscan.domain.model.Vector3
import java.util.UUID
import java.util.concurrent.Executors

/**
 * Этап 5: координатор реального захвата кадра.
 *
 * Ключевая идея потоков:
 * - capture(frame, ...) вызывается на GL-потоке (из ArRenderer.onDrawFrame),
 *   потому что acquireCameraImage() валиден только для ТЕКУЩЕГО frame.
 * - Тяжёлая часть (YUV->JPEG + запись файла) уходит в single-thread executor,
 *   чтобы не тормозить рендер. Image закрываем СРАЗУ после извлечения байт.
 * - Готовый ScanFrame возвращается через колбэк onFrameSaved (уже на фоне);
 *   ViewModel сам перекинет его в main-поток при обновлении состояния.
 *
 * Координатор НЕ решает, нужно ли захватывать кадр — это делает ViewModel
 * через FrameCapturePolicy. Сюда приходит уже одобренный кадр.
 */
class ScanFrameCaptureCoordinator(
    private val storage: FileStorageManager,
    private val jpegQuality: Int = 90
) {
    private val ioExecutor = Executors.newSingleThreadExecutor()

    @Volatile
    private var projectId: String? = null

    @Volatile
    private var frameCounter: Int = 0

    /** Вызвать при старте сканирования: фиксирует проект, в который пишем кадры. */
    fun beginProject(projectId: String) {
        this.projectId = projectId
        this.frameCounter = 0
    }

    fun isActive(): Boolean = projectId != null

    /**
     * Захватывает текущий кадр. ВЫЗЫВАТЬ НА GL-ПОТОКЕ.
     * @param sectorId сектор, к которому привязан кадр
     * @param qualityScore оценка качества (0..5) из QualityAnalyzer
     * @param hasDepth есть ли depth для этого кадра
     * @param onFrameSaved колбэк с готовым ScanFrame (вызывается на фоновом потоке)
     */
    fun capture(
        frame: Frame,
        sectorId: Int,
        qualityScore: Int,
        blurScore: Float,
        brightnessScore: Float,
        hasDepth: Boolean,
        onFrameSaved: (ScanFrame) -> Unit
    ) {
        val pid = projectId ?: return

        // 1) Извлекаем JPEG-байты СИНХРОННО на GL-потоке и сразу закрываем Image.
        val jpegBytes: ByteArray = try {
            frame.acquireCameraImage().use { image ->
                FrameImageSaver.yuvImageToJpegBytes(image, jpegQuality) ?: return
            }
        } catch (e: NotYetAvailableException) {
            // Нормально на первых кадрах после старта — просто пропускаем.
            return
        } catch (e: Throwable) {
            return
        }

        // 2) Снимаем pose + intrinsics с текущего кадра (тоже на GL-потоке).
        val camera = frame.camera
        val pose = runCatching {
            val p = camera.pose
            val rot = FloatArray(4)
            p.getRotationQuaternion(rot, 0)
            CameraPose(Vector3(p.tx(), p.ty(), p.tz()), rot)
        }.getOrNull()

        val intrinsics = runCatching {
            val intr = camera.imageIntrinsics
            val fl = intr.focalLength          // {fx, fy}
            val pp = intr.principalPoint        // {cx, cy}
            val dim = intr.imageDimensions      // {w, h}
            CameraIntrinsics(
                focalLengthX = fl[0],
                focalLengthY = fl[1],
                principalPointX = pp[0],
                principalPointY = pp[1],
                imageWidth = dim[0],
                imageHeight = dim[1]
            )
        }.getOrNull()

        val frameIndex = ++frameCounter
        val targetFile = storage.frameFile(pid, frameIndex)

        // 3) Запись файла — в фоне.
        ioExecutor.execute {
            val ok = FrameImageSaver.writeJpeg(jpegBytes, targetFile)
            if (!ok) return@execute

            val scanFrame = ScanFrame(
                id = UUID.randomUUID().toString(),
                imagePath = targetFile.absolutePath,
                timestampMillis = System.currentTimeMillis(),
                cameraPose = pose,
                cameraIntrinsics = intrinsics,
                sectorId = sectorId,
                qualityScore = qualityScore,
                blurScore = blurScore,
                brightnessScore = brightnessScore,
                hasDepth = hasDepth
            )
            onFrameSaved(scanFrame)
        }
    }

    /** Вызвать при завершении/сбросе скана. */
    fun endProject() {
        projectId = null
        frameCounter = 0
    }

    fun shutdown() {
        ioExecutor.shutdown()
    }
}
