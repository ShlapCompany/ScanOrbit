package com.karas.orbitscan.reconstruction

import com.karas.orbitscan.storage.FileStorageManager
import java.io.File

/**
 * Этап 9: подготовка локального проекта к отправке на backend.
 * Пока не делает HTTP, а собирает список файлов, которые должны уходить в POST /upload.
 */
class UploadManager(private val storage: FileStorageManager) {
    data class UploadManifest(
        val projectId: String,
        val sessionJson: File,
        val frames: List<File>,
        val depthFiles: List<File>,
        val totalBytes: Long
    )

    fun buildManifest(projectId: String): UploadManifest {
        val projectDir = storage.projectDir(projectId)
        val session = storage.sessionJsonFile(projectId)
        val frames = storage.framesDir(projectId).listFiles()?.filter { it.isFile && it.extension.equals("jpg", true) } ?: emptyList()
        val depth = storage.depthDir(projectId).listFiles()?.filter { it.isFile && it.extension.equals("png", true) } ?: emptyList()
        val all = buildList {
            add(session)
            addAll(frames)
            addAll(depth)
        }.filter { it.exists() }
        return UploadManifest(
            projectId = projectId,
            sessionJson = session,
            frames = frames,
            depthFiles = depth,
            totalBytes = all.sumOf { it.length() }
        )
    }
}
