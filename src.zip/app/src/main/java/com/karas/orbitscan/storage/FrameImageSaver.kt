package com.karas.orbitscan.storage

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.Image
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

/**
 * Этап 5: конвертирует ARCore camera image (YUV_420_888) в JPEG и пишет на диск.
 *
 * Важно по потокам:
 * - acquireCameraImage() и работа с Image ДОЛЖНЫ происходить на том же кадре,
 *   что и session.update() (т.е. на GL-потоке внутри ArRenderer.onDrawFrame).
 * - Image нужно ОБЯЗАТЕЛЬНО закрывать (image.close()), иначе ARCore быстро
 *   упрётся в ResourceExhaustedException (лимит одновременно удерживаемых image).
 * - Поэтому конвертацию YUV->byte[] делаем синхронно здесь, а запись файла
 *   можно вынести в фон (см. ScanFrameCaptureCoordinator).
 *
 * Качество JPEG для MVP — 90. Позже можно завязать на настройку качества (раздел 18 ТЗ).
 */
object FrameImageSaver {

    /**
     * Превращает YUV_420_888 в JPEG-байты. Не закрывает image — закрытие на вызывающей стороне.
     * Возвращает null, если формат неожиданный.
     *
     * @param rotationDegrees на сколько повернуть изображение по часовой стрелке (0/90/180/270).
     *   ARCore camera image приходит в ориентации сенсора (обычно landscape), поэтому при
     *   вертикальной съёмке нужно повернуть, иначе фото «лежит на боку». Угол вычисляется
     *   из ориентации дисплея + ориентации сенсора (см. ScanFrameCaptureCoordinator).
     */
    fun yuvImageToJpegBytes(image: Image, jpegQuality: Int = 90, rotationDegrees: Int = 0): ByteArray? {
        if (image.format != ImageFormat.YUV_420_888) return null

        val nv21 = yuv420888ToNv21(image)
        val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        val ok = yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), jpegQuality, out)
        if (!ok) return null

        val baseJpeg = out.toByteArray()
        // Если поворот не нужен — отдаём как есть (быстрый путь).
        if (rotationDegrees % 360 == 0) return baseJpeg

        // Иначе декодируем, поворачиваем матрицей и пережимаем.
        return rotateJpeg(baseJpeg, rotationDegrees, jpegQuality) ?: baseJpeg
    }

    private fun rotateJpeg(jpeg: ByteArray, rotationDegrees: Int, jpegQuality: Int): ByteArray? {
        return try {
            val src = BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size) ?: return null
            val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            val rotated = Bitmap.createBitmap(src, 0, 0, src.width, src.height, matrix, true)
            val out = ByteArrayOutputStream()
            rotated.compress(Bitmap.CompressFormat.JPEG, jpegQuality, out)
            if (rotated != src) rotated.recycle()
            src.recycle()
            out.toByteArray()
        } catch (e: OutOfMemoryError) {
            null
        } catch (e: Exception) {
            null
        }
    }

    /** Пишет уже готовые JPEG-байты в файл. Безопасно для фонового потока. */
    fun writeJpeg(bytes: ByteArray, targetFile: File): Boolean {
        return try {
            targetFile.parentFile?.mkdirs()
            FileOutputStream(targetFile).use { it.write(bytes) }
            true
        } catch (e: Exception) {
            false
        }
    }

    /**
     * Преобразование трёх плоскостей YUV_420_888 в массив NV21 (Y + чередующиеся VU).
     * Учитываем rowStride/pixelStride, т.к. на разных устройствах буферы выровнены по-разному.
     * Основано на общепринятом подходе из документации Android Image.
     */
    private fun yuv420888ToNv21(image: Image): ByteArray {
        val width = image.width
        val height = image.height
        val ySize = width * height
        val nv21 = ByteArray(ySize + ySize / 2)

        val yPlane = image.planes[0]
        val uPlane = image.planes[1]
        val vPlane = image.planes[2]

        val yBuffer = yPlane.buffer
        val uBuffer = uPlane.buffer
        val vBuffer = vPlane.buffer

        // --- Y ---
        var pos = 0
        val yRowStride = yPlane.rowStride
        val yPixelStride = yPlane.pixelStride
        if (yPixelStride == 1 && yRowStride == width) {
            yBuffer.get(nv21, 0, ySize)
            pos = ySize
        } else {
            var yBufferPos = 0
            for (row in 0 until height) {
                yBufferPos = row * yRowStride
                yBuffer.position(yBufferPos)
                for (col in 0 until width) {
                    nv21[pos++] = yBuffer.get(yBufferPos + col * yPixelStride)
                }
            }
        }

        // --- VU (NV21 = Y, затем V,U,V,U...) ---
        val uvRowStride = uPlane.rowStride
        val uvPixelStride = uPlane.pixelStride
        val uvWidth = width / 2
        val uvHeight = height / 2

        for (row in 0 until uvHeight) {
            for (col in 0 until uvWidth) {
                val vuIndex = row * uvRowStride + col * uvPixelStride
                nv21[pos++] = vBuffer.get(vuIndex)
                nv21[pos++] = uBuffer.get(vuIndex)
            }
        }

        return nv21
    }
}
