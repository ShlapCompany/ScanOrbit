package com.karas.orbitscan.domain.quality

import com.karas.orbitscan.domain.model.FrameQuality

class QualityAnalyzer {
    /**
     * MVP-заглушка: настоящая версия будет считать яркость по пикселям изображения,
     * blurScore через Laplacian/градиенты, а cameraSpeedScore — из ARCore pose delta.
     */
    fun estimateStub(
        cameraSpeedMetersPerSecond: Float,
        trackingOk: Boolean,
        hasDepth: Boolean
    ): FrameQuality {
        val speedScore = (1f - cameraSpeedMetersPerSecond / 1.2f).coerceIn(0f, 1f)
        return FrameQuality(
            brightnessScore = 0.75f,
            blurScore = 0.70f,
            cameraSpeedScore = speedScore,
            trackingOk = trackingOk,
            hasDepth = hasDepth
        )
    }
}
