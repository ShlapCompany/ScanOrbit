package com.karas.orbitscan.domain.quality

import android.media.Image
import com.karas.orbitscan.domain.model.FrameQuality
import kotlin.math.max
import kotlin.math.min

/**
 * Этап 6: реальный анализ качества кадра.
 *
 * Для MVP анализируем только Y-плоскость YUV_420_888, потому что она уже есть в
 * ARCore camera image и не требует дорогого RGB-преобразования:
 * - brightnessScore: средняя яркость + штраф за пересвет/почти чёрные пиксели;
 * - blurScore: грубая variance of Laplacian по downscaled Y-плоскости;
 * - cameraSpeedScore: из ARCore pose delta.
 */
class QualityAnalyzer {

    fun estimateMotionOnly(
        cameraSpeedMetersPerSecond: Float,
        trackingOk: Boolean,
        hasDepth: Boolean
    ): FrameQuality = FrameQuality(
        brightnessScore = 0.75f,
        blurScore = 0.70f,
        cameraSpeedScore = speedScore(cameraSpeedMetersPerSecond),
        trackingOk = trackingOk,
        hasDepth = hasDepth
    )

    /** Старое имя оставлено как compatibility wrapper для fallback/simulation. */
    fun estimateStub(
        cameraSpeedMetersPerSecond: Float,
        trackingOk: Boolean,
        hasDepth: Boolean
    ): FrameQuality = estimateMotionOnly(cameraSpeedMetersPerSecond, trackingOk, hasDepth)

    fun analyzeCameraImage(
        image: Image,
        cameraSpeedMetersPerSecond: Float,
        trackingOk: Boolean,
        hasDepth: Boolean
    ): FrameQuality {
        val yPlane = image.planes.firstOrNull()
            ?: return estimateMotionOnly(cameraSpeedMetersPerSecond, trackingOk, hasDepth)

        val yBuffer = yPlane.buffer.duplicate()
        val luminance = sampleLuminanceGrid(
            width = image.width,
            height = image.height,
            rowStride = yPlane.rowStride,
            pixelStride = max(1, yPlane.pixelStride),
            getByte = { index -> if (index < yBuffer.capacity()) yBuffer.get(index).toInt() and 0xFF else 0 }
        )

        val brightness = brightnessScore(luminance.values)
        val blur = blurScore(luminance.values, luminance.width, luminance.height)

        return FrameQuality(
            brightnessScore = brightness,
            blurScore = blur,
            cameraSpeedScore = speedScore(cameraSpeedMetersPerSecond),
            trackingOk = trackingOk,
            hasDepth = hasDepth
        )
    }

    private fun speedScore(speed: Float): Float {
        // До ~0.25 м/с отлично, после ~1.2 м/с кадры обычно смазаны/плохо матчятся.
        return (1f - (speed - 0.25f) / 0.95f).coerceIn(0f, 1f)
    }

    private fun brightnessScore(values: IntArray): Float {
        if (values.isEmpty()) return 0f
        var sum = 0L
        var veryDark = 0
        var clippedBright = 0
        for (v in values) {
            sum += v
            if (v < 18) veryDark++
            if (v > 245) clippedBright++
        }
        val mean = sum.toFloat() / values.size.toFloat()
        val meanScore = ((mean - 28f) / 110f).coerceIn(0f, 1f)
        val clippingPenalty = (1f - (veryDark + clippedBright).toFloat() / values.size.toFloat()).coerceIn(0f, 1f)
        return (meanScore * (0.55f + 0.45f * clippingPenalty)).coerceIn(0f, 1f)
    }

    private fun blurScore(values: IntArray, width: Int, height: Int): Float {
        if (width < 3 || height < 3 || values.size < width * height) return 0.5f

        var sum = 0.0
        var sumSq = 0.0
        var count = 0
        for (y in 1 until height - 1) {
            val row = y * width
            for (x in 1 until width - 1) {
                val center = values[row + x]
                val lap = -4 * center +
                    values[row + x - 1] + values[row + x + 1] +
                    values[row - width + x] + values[row + width + x]
                sum += lap.toDouble()
                sumSq += (lap * lap).toDouble()
                count++
            }
        }
        if (count == 0) return 0.5f
        val mean = sum / count
        val variance = (sumSq / count) - mean * mean

        // Эмпирическая нормализация: ниже ~50 — очень мыльно, выше ~1200 — достаточно резко.
        return ((variance - 45.0) / 1150.0).toFloat().coerceIn(0f, 1f)
    }

    private data class LuminanceGrid(
        val values: IntArray,
        val width: Int,
        val height: Int
    )

    private fun sampleLuminanceGrid(
        width: Int,
        height: Int,
        rowStride: Int,
        pixelStride: Int,
        getByte: (Int) -> Int
    ): LuminanceGrid {
        // Downscale до максимум ~120px по ширине, чтобы не тормозить GL-поток.
        val targetMaxWidth = 120
        val step = max(1, width / targetMaxWidth)
        val sampledWidth = max(1, (width + step - 1) / step)
        val sampledHeight = max(1, (height + step - 1) / step)
        val values = IntArray(sampledWidth * sampledHeight)

        var out = 0
        for (sy in 0 until sampledHeight) {
            val y = min(height - 1, sy * step)
            for (sx in 0 until sampledWidth) {
                val x = min(width - 1, sx * step)
                val index = y * rowStride + x * pixelStride
                values[out++] = getByte(index)
            }
        }
        return LuminanceGrid(values, sampledWidth, sampledHeight)
    }
}
