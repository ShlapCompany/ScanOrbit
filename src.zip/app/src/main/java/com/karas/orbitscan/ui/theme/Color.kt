package com.karas.orbitscan.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================================
// Этап 5.2 — дизайн-токены (iOS-вдохновлённая тёмная тема).
// ============================================================================

// Акценты (статусы покрытия). Чуть приглушены под тёмный фон.
val OrbitGreen = Color(0xFF30D158)   // iOS systemGreen (dark)
val OrbitYellow = Color(0xFFFFD60A)  // iOS systemYellow (dark)
val OrbitRed = Color(0xFFFF453A)     // iOS systemRed (dark)
val OrbitBlue = Color(0xFF0A84FF)    // iOS systemBlue (dark) — для нейтральных действий

// Фоны и поверхности.
val OrbitDark = Color(0xFF0A0E14)        // глубокий фон (камера/AR — про пространство)
val OrbitSurface = Color(0xFF1C1C1E)     // iOS secondarySystemBackground
val OrbitSurfaceElevated = Color(0xFF2C2C2E) // iOS tertiarySystemBackground

// «Стекло» — полупрозрачные панели поверх камеры (frosted look).
val OrbitGlass = Color(0xCC161A20)       // ~80% непрозрачности
val OrbitGlassStrong = Color(0xE6161A20) // ~90%
val OrbitHairline = Color(0x1FFFFFFF)    // 12% белого — тонкие разделители/границы

// Светлая тема (для главного экрана/настроек, если системная тема светлая).
val OrbitLightBg = Color(0xFFF2F2F7)     // iOS systemGroupedBackground
val OrbitLightSurface = Color(0xFFFFFFFF)
val OrbitLightText = Color(0xFF1C1C1E)
