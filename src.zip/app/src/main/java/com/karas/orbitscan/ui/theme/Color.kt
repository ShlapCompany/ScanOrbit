package com.karas.orbitscan.ui.theme

import androidx.compose.ui.graphics.Color

val OrbitGreen = Color(0xFF00E5A8)
val OrbitYellow = Color(0xFFFFD54F)
val OrbitRed = Color(0xFFFF5252)
val OrbitDark = Color(0xFF101820)
val OrbitSurface = Color(0xFF162331)
