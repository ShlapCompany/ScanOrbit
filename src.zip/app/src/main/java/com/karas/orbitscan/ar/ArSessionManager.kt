package com.karas.orbitscan.ar

/**
 * Этап 2: здесь будет настоящая обёртка над com.google.ar.core.Session.
 * Сейчас интерфейс нужен, чтобы архитектура уже была правильной.
 */
interface ArSessionManager {
    val isArCoreSupported: Boolean
    val isDepthSupported: Boolean
    fun start()
    fun pause()
    fun resume()
    fun stop()
}

class StubArSessionManager : ArSessionManager {
    override val isArCoreSupported: Boolean = false
    override val isDepthSupported: Boolean = false
    override fun start() = Unit
    override fun pause() = Unit
    override fun resume() = Unit
    override fun stop() = Unit
}
