package com.karas.orbitscan.ar

import android.app.Activity
import android.content.Context
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Session
import com.google.ar.core.exceptions.UnavailableException

/**
 * Этап 2: реальная обёртка над com.google.ar.core.Session.
 *
 * Архитектурная заметка для продолжения (ГПТ/Claude):
 * - Этот интерфейс намеренно НЕ знает про OpenGL/рендер. Рендером занимается
 *   ArRenderer + GLSurfaceView (см. ui/scan/ArCameraView.kt).
 * - ArSessionManager отвечает ТОЛЬКО за жизненный цикл Session и за конфиг
 *   (depth/focus). Получение pose на каждый кадр идёт через ArRenderer ->
 *   CameraPoseTracker -> ScanViewModel.
 * - Этап 3 реализован без хранения Frame в SessionManager: tap-to-select обрабатывается
 *   прямо в ArRenderer на GL-потоке через frame.hitTest(x, y).
 */
interface ArSessionManager {
    /** Поддерживается ли ARCore на этом устройстве (после установки сервисов). */
    val isArCoreSupported: Boolean

    /** Поддерживается ли Depth API (Config.DepthMode.AUTOMATIC). */
    val isDepthSupported: Boolean

    /** Текущая ARCore-сессия или null, если ещё не создана / недоступна. */
    val session: Session?

    /**
     * Пытается создать и сконфигурировать Session.
     * Может потребовать установку/обновление Google Play Services for AR —
     * в этом случае возвращает результат RequiresInstall и НЕ создаёт сессию.
     */
    fun createSessionIfNeeded(activity: Activity): ArInitResult

    fun resume()
    fun pause()
    fun close()
}

/** Результат попытки инициализации ARCore. */
sealed interface ArInitResult {
    /** Сессия создана и готова. */
    data object Ready : ArInitResult
    /** Нужно установить/обновить Google Play Services for AR. UI должен повторить попытку. */
    data object RequiresInstall : ArInitResult
    /** Устройство не поддерживает ARCore — нужен fallback-режим. */
    data object Unsupported : ArInitResult
    /** Иная ошибка (нет разрешения камеры, апдейт сервиса и т.п.). */
    data class Error(val message: String) : ArInitResult
}

class RealArSessionManager(
    private val appContext: Context
) : ArSessionManager {

    override var session: Session? = null
        private set

    private var depthSupported = false
    private var userRequestedInstall = true

    override val isArCoreSupported: Boolean
        get() = ArCoreApk.getInstance().checkAvailability(appContext).isSupported

    override val isDepthSupported: Boolean
        get() = depthSupported

    override fun createSessionIfNeeded(activity: Activity): ArInitResult {
        if (session != null) return ArInitResult.Ready

        // Проверяем доступность ARCore. На некоторых устройствах ответ приходит
        // асинхронно (статус ...CHECKING) — тогда возвращаем RequiresInstall,
        // чтобы UI повторил попытку чуть позже.
        val availability = ArCoreApk.getInstance().checkAvailability(activity)
        if (availability.isTransient) {
            return ArInitResult.RequiresInstall
        }
        if (!availability.isSupported) {
            return ArInitResult.Unsupported
        }

        return try {
            // Запрос на установку/обновление Google Play Services for AR.
            when (ArCoreApk.getInstance().requestInstall(activity, userRequestedInstall)) {
                ArCoreApk.InstallStatus.INSTALL_REQUESTED -> {
                    // Activity будет приостановлена ради установки; при следующем
                    // заходе requestInstall уже не должен запрашивать снова.
                    userRequestedInstall = false
                    ArInitResult.RequiresInstall
                }
                ArCoreApk.InstallStatus.INSTALLED -> {
                    val newSession = Session(activity)
                    configureSession(newSession)
                    session = newSession
                    ArInitResult.Ready
                }
            }
        } catch (e: UnavailableException) {
            ArInitResult.Error(e.message ?: "ARCore unavailable")
        } catch (e: Exception) {
            ArInitResult.Error(e.message ?: "ARCore init error")
        }
    }

    private fun configureSession(session: Session) {
        val config = Config(session)
        // Depth включаем только если устройство умеет — иначе configure() кинет ошибку.
        depthSupported = session.isDepthModeSupported(Config.DepthMode.AUTOMATIC)
        config.depthMode = if (depthSupported) Config.DepthMode.AUTOMATIC else Config.DepthMode.DISABLED
        // Авто-фокус полезен для будущей фотограмметрии (Этап 5+).
        config.focusMode = Config.FocusMode.AUTO
        // Plane finding оставляем по умолчанию — пригодится для hit test на Этапе 3.
        config.updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
        session.configure(config)
    }

    override fun resume() {
        session?.resume()
    }

    override fun pause() {
        session?.pause()
    }

    override fun close() {
        session?.close()
        session = null
    }
}

/** Заглушка для устройств без ARCore и для Compose preview. */
class StubArSessionManager : ArSessionManager {
    override val isArCoreSupported: Boolean = false
    override val isDepthSupported: Boolean = false
    override val session: Session? = null
    override fun createSessionIfNeeded(activity: Activity): ArInitResult = ArInitResult.Unsupported
    override fun resume() = Unit
    override fun pause() = Unit
    override fun close() = Unit
}
