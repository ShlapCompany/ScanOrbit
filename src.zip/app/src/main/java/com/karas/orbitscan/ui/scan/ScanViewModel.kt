package com.karas.orbitscan.ui.scan

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.ViewModel
import com.karas.orbitscan.domain.capture.FrameCapturePolicy
import com.karas.orbitscan.domain.coverage.CoverageMap
import com.karas.orbitscan.domain.model.ScanFrame
import com.karas.orbitscan.domain.model.ScanObjectSize
import com.karas.orbitscan.domain.model.Vector3
import com.karas.orbitscan.domain.quality.QualityAnalyzer
import com.karas.orbitscan.storage.FileStorageManager
import com.karas.orbitscan.storage.ScanFrameCaptureCoordinator
import com.karas.orbitscan.storage.ScanSessionWriter
import com.karas.orbitscan.domain.model.ScanMode
import com.karas.orbitscan.domain.model.SectorState
import com.google.ar.core.Frame
import kotlin.math.cos
import kotlin.math.sin

class ScanViewModel : ViewModel() {
    var uiState by mutableStateOf(ScanUiState())
        private set

    private val qualityAnalyzer = QualityAnalyzer()
    private val capturePolicy = FrameCapturePolicy()
    private val mainHandler = Handler(Looper.getMainLooper())

    // Этап 5: координатор реального захвата кадров. Инициализируется из ScanScreen
    // (нужен Context для FileStorageManager), поэтому через setter.
    private var captureCoordinator: ScanFrameCaptureCoordinator? = null
    private var currentProjectId: String? = null
    // Накопленные кадры текущего скана (записываются в scan_session.json на Этапе 8).
    private val savedFrames = mutableListOf<ScanFrame>()

    // Этап 8: запись проекта на диск. storage/sessionWriter и метаданные устройства
    // приходят из ScanScreen (нужен Context и Build.*, которых не должно быть во ViewModel).
    private var storage: FileStorageManager? = null
    private val sessionWriter = ScanSessionWriter()
    private var deviceModel: String = "unknown"
    private var androidVersion: Int = 0
    private var appVersion: String = "0.1.0-mvp"
    private var depthSupported: Boolean = false

    fun attachCaptureCoordinator(coordinator: ScanFrameCaptureCoordinator) {
        captureCoordinator = coordinator
    }

    /** Этап 8: внедрение хранилища и метаданных устройства для записи scan_session.json. */
    fun attachStorage(
        storage: FileStorageManager,
        deviceModel: String,
        androidVersion: Int,
        appVersion: String,
        depthSupported: Boolean
    ) {
        this.storage = storage
        this.deviceModel = deviceModel
        this.androidVersion = androidVersion
        this.appVersion = appVersion
        this.depthSupported = depthSupported
    }

    /**
     * Этап 3: objectCenter теперь выбирается настоящим ARCore hit test.
     * В fallback-режиме остаётся условный центр Vector3.Zero, чтобы можно было тестировать UI.
     */
    private var objectCenter: Vector3? = null
    private var objectRadius = ScanObjectSize.Medium.radiusMeters
    private var selectedObjectSize = ScanObjectSize.Medium
    private var simulatedStep = 0

    // ---- Этап 2: переключение движка ----

    fun setEngineMode(mode: ScanEngineMode) {
        uiState = uiState.copy(engineMode = mode)
    }

    /**
     * Этап 3: результат успешного ARCore Frame.hitTest(x, y).
     *
     * center — реальная точка в AR-пространстве. Именно она становится центром
     * виртуальной сферы покрытия, относительно которой потом считаются сектора.
     */
    fun selectObjectFromArHit(
        center: Vector3,
        screenXFraction: Float,
        screenYFraction: Float
    ) {
        objectCenter = center
        simulatedStep = 0
        capturePolicy.reset()
        val freshCoverageMap = CoverageMap.create()

        uiState = uiState.copy(
            phase = ScanPhase.Ready,
            coverageMap = freshCoverageMap,
            coveragePercent = 0,
            weakOrGoodPercent = 0,
            frameCount = 0,
            currentSectorId = null,
            objectCenter = center,
            objectCenterScreenPosition = ObjectCenterScreenPosition(
                xFraction = screenXFraction.coerceIn(0f, 1f),
                yFraction = screenYFraction.coerceIn(0f, 1f)
            ),
            selectedObjectSize = selectedObjectSize,
            objectRadiusMeters = objectRadius,
            hint = "Центр объекта выбран. Выберите размер и нажмите «Начать».",
            qualityText = "Центр: x=${center.x.format1()}, y=${center.y.format1()}, z=${center.z.format1()}",
            isTracking = true
        )
    }

    /** Вызывается, если пользователь тапнул, но ARCore не нашёл подходящую поверхность/точку. */
    fun onObjectHitTestFailed() {
        uiState = uiState.copy(
            hint = "Не удалось выбрать центр. Наведите камеру на объект или поверхность рядом с ним и тапните ещё раз.",
            qualityText = "Hit test не дал результата"
        )
    }

    /**
     * Fallback-выбор объекта для устройств без ARCore.
     * Это не настоящий spatial center, но позволяет проходить сценарий MVP без AR.
     */
    fun selectObjectStub() {
        val center = Vector3.Zero
        objectCenter = center
        simulatedStep = 0
        capturePolicy.reset()
        val freshCoverageMap = CoverageMap.create()

        uiState = uiState.copy(
            phase = ScanPhase.Ready,
            coverageMap = freshCoverageMap,
            coveragePercent = 0,
            weakOrGoodPercent = 0,
            frameCount = 0,
            currentSectorId = null,
            objectCenter = center,
            objectCenterScreenPosition = null,
            selectedObjectSize = selectedObjectSize,
            objectRadiusMeters = objectRadius,
            hint = "Объект выбран в fallback-режиме. Радиус: ${objectRadius.format1()} м. Нажмите «Начать».",
            qualityText = "Fallback center",
            isTracking = true
        )
    }

    /** Этап 3: ручной выбор радиуса виртуальной сферы покрытия. */
    fun setObjectSize(size: ScanObjectSize) {
        selectedObjectSize = size
        objectRadius = size.radiusMeters
        uiState = uiState.copy(
            selectedObjectSize = size,
            objectRadiusMeters = objectRadius,
            hint = if (uiState.objectCenter != null) {
                "Размер: ${size.title}, радиус ${objectRadius.format1()} м. Нажмите «Начать»."
            } else {
                "Размер: ${size.title}. Теперь тапните по центру объекта."
            }
        )
    }

    /**
     * Этап 2-3: вызывается из рендера при каждом валидном ARCore-кадре.
     * Обновляет текущий сектор по реальному положению камеры относительно objectCenter.
     */
    fun onArPose(cameraPosition: Vector3, cameraSpeed: Float, trackingOk: Boolean) {
        if (uiState.phase != ScanPhase.Scanning) {
            // Вне фазы сканирования просто показываем tracking-статус и скорость.
            val phaseHint = if (uiState.phase == ScanPhase.SelectObject && trackingOk) {
                "Тапните по центру объекта или по поверхности рядом с ним."
            } else uiState.hint
            uiState = uiState.copy(
                isTracking = trackingOk,
                cameraSpeed = cameraSpeed,
                hint = phaseHint
            )
            return
        }

        if (!trackingOk) {
            // Трекинг потерян: не трогаем сектор/покрытие, только сообщаем пользователю.
            uiState = uiState.copy(
                isTracking = false,
                cameraSpeed = 0f,
                qualityText = "Tracking потерян",
                hint = "Медленно наведите камеру на уже снятую область."
            )
            return
        }

        val center = objectCenter
        if (center == null) {
            uiState = uiState.copy(
                phase = ScanPhase.SelectObject,
                hint = "Сначала выберите центр объекта тапом по экрану.",
                qualityText = "Центр объекта не выбран"
            )
            return
        }

        val coverageMap = uiState.coverageMap
        val sector = coverageMap.sectorForCameraPosition(center, cameraPosition)

        // Этап 5: onArPose теперь ТОЛЬКО обновляет индикаторы (текущий сектор,
        // скорость, подсказки). Реальное "принятие" сектора происходит в
        // onArFrameForCapture ПОСЛЕ успешного сохранения фото — чтобы зелёная
        // зона = реально сохранённый кадр, а не просто пролёт камеры.
        uiState = uiState.copy(
            currentSectorId = sector.id,
            cameraSpeed = cameraSpeed,
            hint = if (cameraSpeed > 0.9f) "Двигайтесь медленнее." else coverageMap.nextHint(sector.id),
            isTracking = true
        )
    }

    /**
     * Этап 5: вызывается из ArRenderer НА GL-ПОТОКЕ каждый tracking-кадр.
     * Здесь принимается решение о захвате и сам захват (acquireCameraImage),
     * т.к. frame валиден только в этом вызове.
     *
     * Обновление uiState делаем через mainHandler (мы не на main-потоке).
     */
    fun onArFrameForCapture(frame: Frame, cameraPosition: Vector3, cameraSpeed: Float) {
        if (uiState.phase != ScanPhase.Scanning) return
        val center = objectCenter ?: return
        val coordinator = captureCoordinator ?: return
        if (!coordinator.isActive()) return

        val coverageMap = uiState.coverageMap
        val sector = coverageMap.sectorForCameraPosition(center, cameraPosition)
        val quality = qualityAnalyzer.estimateStub(
            cameraSpeedMetersPerSecond = cameraSpeed,
            trackingOk = true,
            hasDepth = uiState.hasDepth
        )

        val now = System.currentTimeMillis()
        if (!capturePolicy.shouldCapture(now, sector.id, quality)) return

        // Резервируем сектор сразу, чтобы соседние кадры не захватывали повторно,
        // пока идёт асинхронная запись файла.
        capturePolicy.markCaptured(now, sector.id)

        coordinator.capture(
            frame = frame,
            sectorId = sector.id,
            qualityScore = quality.totalScore,
            blurScore = quality.blurScore,
            brightnessScore = quality.brightnessScore,
            hasDepth = quality.hasDepth
        ) { savedFrame ->
            // Колбэк приходит с фонового io-потока координатора.
            mainHandler.post {
                savedFrames.add(savedFrame)
                val updatedMap = uiState.coverageMap.updateWithAcceptedFrame(savedFrame.sectorId, quality)
                uiState = uiState.copy(
                    coverageMap = updatedMap,
                    coveragePercent = updatedMap.coveragePercent(),
                    weakOrGoodPercent = updatedMap.weakOrGoodPercent(),
                    frameCount = savedFrames.size,
                    qualityText = "Кадр сохранён: score ${quality.totalScore}/5",
                    hint = updatedMap.nextHint(savedFrame.sectorId)
                )
            }
        }
    }

    // ---- Общие действия (работают в обоих режимах) ----

    fun startScan() {
        if (objectCenter == null) {
            uiState = uiState.copy(
                phase = ScanPhase.SelectObject,
                hint = "Сначала выберите центр объекта: тапните по объекту на AR-камере.",
                qualityText = "Центр объекта не выбран"
            )
            return
        }

        // Этап 5: начинаем новый проект на диске и фиксируем его в координаторе.
        val projectId = java.util.UUID.randomUUID().toString()
        currentProjectId = projectId
        savedFrames.clear()
        captureCoordinator?.beginProject(projectId)

        uiState = uiState.copy(
            phase = ScanPhase.Scanning,
            hint = "Начните плавно обходить объект по кругу.",
            isTracking = true
        )
    }

    /**
     * Fallback-режим: симуляция кадра по кнопке "+ Кадр" (как в Этапе 1).
     * Используется, только если ARCore недоступен.
     */
    fun simulateUsefulFrame() {
        val now = System.currentTimeMillis()
        val coverageMap = uiState.coverageMap
        val center = objectCenter ?: Vector3.Zero
        val azimuth = simulatedStep * (360f / coverageMap.azimuthSectors)
        val elevationLayer = (simulatedStep / coverageMap.azimuthSectors) % coverageMap.elevationSectors
        val elevation = when (elevationLayer) {
            0 -> -35f
            1 -> 0f
            else -> 35f
        }

        val cameraPosition = cameraPositionFromAngles(azimuth, elevation, objectRadius + 1.2f)
        val sector = coverageMap.sectorForCameraPosition(center, cameraPosition)
        val quality = qualityAnalyzer.estimateStub(
            cameraSpeedMetersPerSecond = 0.35f,
            trackingOk = true,
            hasDepth = simulatedStep % 2 == 0
        )

        val shouldCapture = capturePolicy.shouldCapture(now, sector.id, quality)
        val newCoverageMap = if (shouldCapture) {
            capturePolicy.markCaptured(now, sector.id)
            coverageMap.updateWithAcceptedFrame(sector.id, quality)
        } else {
            coverageMap
        }

        simulatedStep++
        uiState = uiState.copy(
            coverageMap = newCoverageMap,
            coveragePercent = newCoverageMap.coveragePercent(),
            weakOrGoodPercent = newCoverageMap.weakOrGoodPercent(),
            frameCount = if (shouldCapture) uiState.frameCount + 1 else uiState.frameCount,
            currentSectorId = sector.id,
            hasDepth = quality.hasDepth,
            qualityText = if (shouldCapture) "Кадр принят: score ${quality.totalScore}/5" else "Кадр пропущен",
            hint = newCoverageMap.nextHint(sector.id),
            isTracking = true
        )
    }

    fun finishScan() {
        // Этап 5: фиксируем проект — больше не принимаем новые кадры.
        captureCoordinator?.endProject()

        // Этап 8: записываем scan_session.json (метаданные сессии + кадры).
        persistSessionJson()

        uiState = uiState.copy(
            phase = ScanPhase.Finished,
            hint = if (uiState.coveragePercent >= 70) {
                "Скан завершён. Сохранено кадров: ${savedFrames.size}. Можно открыть предпросмотр."
            } else {
                "Скан неполный (кадров: ${savedFrames.size}): лучше доснять красные и жёлтые зоны."
            }
        )
    }

    /**
     * Этап 8: собирает SessionMeta + состояния секторов и пишет scan_session.json.
     * Запись делаем на фоновом потоке (файловый I/O). Безопасно: на момент вызова
     * захват уже остановлен (endProject), savedFrames больше не растёт.
     */
    private fun persistSessionJson() {
        val storage = this.storage ?: return
        val projectId = currentProjectId ?: return
        val center = objectCenter ?: Vector3.Zero
        val map = uiState.coverageMap
        val coverage = uiState.coveragePercent

        // Снимаем неизменяемые копии, чтобы не читать mutable-состояние с фонового потока.
        val framesSnapshot = savedFrames.toList()
        val sectorStates: Map<Int, String> = map.sectors.associate { sector ->
            sector.id to when (sector.state) {
                SectorState.NotScanned -> "NOT_SCANNED"
                SectorState.Weak -> "WEAK"
                SectorState.Good -> "GOOD"
            }
        }

        val meta = ScanSessionWriter.SessionMeta(
            projectId = projectId,
            name = defaultProjectName(),
            mode = ScanMode.ObjectOrbitScan.name,
            createdAtMillis = System.currentTimeMillis(),
            deviceModel = deviceModel,
            androidVersion = androidVersion,
            appVersion = appVersion,
            depthSupported = depthSupported,
            objectCenter = floatArrayOf(center.x, center.y, center.z),
            objectRadius = objectRadius,
            azimuthSectors = map.azimuthSectors,
            elevationSectors = map.elevationSectors,
            coveragePercent = coverage
        )

        val targetFile = storage.sessionJsonFile(projectId)
        // Лёгкий фоновый поток для разовой записи JSON.
        Thread {
            sessionWriter.write(targetFile, meta, framesSnapshot, sectorStates)
        }.start()
    }

    /** Имя проекта по умолчанию: "Скан <дата>". Позже можно дать пользователю переименование. */
    private fun defaultProjectName(): String {
        val sdf = java.text.SimpleDateFormat("dd.MM.yyyy HH:mm", java.util.Locale.getDefault())
        return "Скан ${sdf.format(java.util.Date())}"
    }

    fun reset() {
        objectCenter = null
        objectRadius = ScanObjectSize.Medium.radiusMeters
        selectedObjectSize = ScanObjectSize.Medium
        simulatedStep = 0
        capturePolicy.reset()
        // Этап 5: сбрасываем проект и накопленные кадры.
        captureCoordinator?.endProject()
        currentProjectId = null
        savedFrames.clear()
        // engineMode сохраняем — он определяется аппаратными возможностями, не сбрасывается.
        uiState = ScanUiState(
            coverageMap = CoverageMap.create(),
            engineMode = uiState.engineMode
        )
    }

    private fun cameraPositionFromAngles(azimuthDegrees: Float, elevationDegrees: Float, distance: Float): Vector3 {
        val az = Math.toRadians(azimuthDegrees.toDouble())
        val el = Math.toRadians(elevationDegrees.toDouble())
        val horizontal = distance * cos(el).toFloat()
        return Vector3(
            x = horizontal * cos(az).toFloat(),
            y = distance * sin(el).toFloat(),
            z = horizontal * sin(az).toFloat()
        )
    }

    private fun Float.format1(): String = String.format(java.util.Locale.US, "%.1f", this)
}
