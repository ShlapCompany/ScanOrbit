package com.karas.orbitscan.ui.scan

import androidx.lifecycle.ViewModel
import com.karas.orbitscan.domain.capture.FrameCapturePolicy
import com.karas.orbitscan.domain.coverage.CoverageMap
import com.karas.orbitscan.domain.model.Vector3
import com.karas.orbitscan.domain.quality.QualityAnalyzer
import kotlin.math.cos
import kotlin.math.sin
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class ScanViewModel : ViewModel() {
    var uiState by mutableStateOf(ScanUiState())
        private set

    private val qualityAnalyzer = QualityAnalyzer()
    private val capturePolicy = FrameCapturePolicy()
    private val objectCenter = Vector3.Zero
    private val objectRadius = 1.5f
    private var simulatedStep = 0

    fun selectObjectStub() {
        uiState = uiState.copy(
            phase = ScanPhase.Ready,
            hint = "Объект выбран. Радиус MVP: $objectRadius м. Нажмите “Начать”.",
            isTracking = true
        )
    }

    fun startScan() {
        uiState = uiState.copy(
            phase = ScanPhase.Scanning,
            hint = "Начните плавно обходить объект по кругу.",
            isTracking = true
        )
    }

    fun simulateUsefulFrame() {
        val now = System.currentTimeMillis()
        val coverageMap = uiState.coverageMap
        val azimuth = simulatedStep * (360f / coverageMap.azimuthSectors)
        val elevationLayer = (simulatedStep / coverageMap.azimuthSectors) % coverageMap.elevationSectors
        val elevation = when (elevationLayer) {
            0 -> -35f
            1 -> 0f
            else -> 35f
        }

        val cameraPosition = cameraPositionFromAngles(azimuth, elevation, objectRadius + 1.2f)
        val sector = coverageMap.sectorForCameraPosition(objectCenter, cameraPosition)
        val quality = qualityAnalyzer.estimateStub(
            cameraSpeedMetersPerSecond = 0.35f,
            trackingOk = true,
            hasDepth = simulatedStep % 2 == 0
        )

        val shouldCapture = capturePolicy.shouldCapture(now, sector.id, quality)
        val newCoverageMap = if (shouldCapture) {
            capturePolicy.markCaptured(now, sector.id)
            coverageMap.updateWithAcceptedFrame(sector.id, quality)
        } else {
            coverageMap
        }

        simulatedStep++
        uiState = uiState.copy(
            coverageMap = newCoverageMap,
            coveragePercent = newCoverageMap.coveragePercent(),
            weakOrGoodPercent = newCoverageMap.weakOrGoodPercent(),
            frameCount = if (shouldCapture) uiState.frameCount + 1 else uiState.frameCount,
            currentSectorId = sector.id,
            hasDepth = quality.hasDepth,
            qualityText = if (shouldCapture) "Кадр принят: score ${quality.totalScore}/5" else "Кадр пропущен",
            hint = newCoverageMap.nextHint(sector.id),
            isTracking = true
        )
    }

    fun finishScan() {
        uiState = uiState.copy(
            phase = ScanPhase.Finished,
            hint = if (uiState.coveragePercent >= 70) {
                "Скан завершён. Можно открыть предпросмотр."
            } else {
                "Скан неполный: лучше доснять красные и жёлтые зоны."
            }
        )
    }

    fun reset() {
        simulatedStep = 0
        capturePolicy.reset()
        uiState = ScanUiState(coverageMap = CoverageMap.create())
    }

    private fun cameraPositionFromAngles(azimuthDegrees: Float, elevationDegrees: Float, distance: Float): Vector3 {
        val az = Math.toRadians(azimuthDegrees.toDouble())
        val el = Math.toRadians(elevationDegrees.toDouble())
        val horizontal = distance * cos(el).toFloat()
        return Vector3(
            x = horizontal * cos(az).toFloat(),
            y = distance * sin(el).toFloat(),
            z = horizontal * sin(az).toFloat()
        )
    }
}
