package com.karas.orbitscan.storage

import java.io.File

/** Объединяет per-frame PLY в preview/preview_points.ply для быстрого предпросмотра. */
object PointCloudMerger {
    fun mergeAsciiPly(inputPaths: List<String>, target: File): Boolean {
        return try {
            val vertices = mutableListOf<String>()
            inputPaths.map(::File).filter { it.exists() }.forEach { file ->
                var afterHeader = false
                file.forEachLine { line ->
                    if (afterHeader && line.isNotBlank()) vertices.add(line)
                    if (line.trim() == "end_header") afterHeader = true
                }
            }
            if (vertices.isEmpty()) return false
            target.parentFile?.mkdirs()
            target.writeText(buildString {
                appendLine("ply")
                appendLine("format ascii 1.0")
                appendLine("comment OrbitScan merged preview point cloud")
                appendLine("element vertex ${vertices.size}")
                appendLine("property float x")
                appendLine("property float y")
                appendLine("property float z")
                appendLine("end_header")
                vertices.forEach { appendLine(it) }
            })
            true
        } catch (e: Exception) {
            false
        }
    }
}
