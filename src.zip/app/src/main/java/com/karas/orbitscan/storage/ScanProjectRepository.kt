package com.karas.orbitscan.storage

import com.karas.orbitscan.domain.model.ScanMode
import com.karas.orbitscan.domain.model.ScanProject
import com.karas.orbitscan.domain.model.ScanStatus
import java.time.Instant

/**
 * Этап 8-10: файловый репозиторий проектов поверх scan_session.json.
 */
class ScanProjectRepository(
    private val storage: FileStorageManager,
    private val sessionWriter: ScanSessionWriter = ScanSessionWriter()
) {

    fun loadProjects(): List<ScanProject> {
        return storage.listProjectIds()
            .mapNotNull { id ->
                val summary = sessionWriter.readSummary(storage.sessionJsonFile(id)) ?: return@mapNotNull null
                summary.toScanProject(localPath = storage.projectDir(id).absolutePath)
            }
            .sortedByDescending { it.updatedAt }
    }

    fun loadProjectDetails(projectId: String): ScanSessionWriter.ProjectDetails? =
        sessionWriter.readDetails(storage.sessionJsonFile(projectId))

    fun deleteProject(projectId: String): Boolean = storage.deleteProject(projectId)

    private fun ScanSessionWriter.ProjectSummary.toScanProject(localPath: String): ScanProject {
        val createdInstant = if (createdAtMillis > 0) Instant.ofEpochMilli(createdAtMillis) else Instant.now()
        val updatedInstant = if (updatedAtMillis > 0) Instant.ofEpochMilli(updatedAtMillis) else createdInstant
        return ScanProject(
            id = id,
            name = name,
            mode = parseMode(mode),
            createdAt = createdInstant,
            updatedAt = updatedInstant,
            status = parseStatus(status, resultModelPath),
            coveragePercent = coveragePercent,
            frameCount = frameCount,
            thumbnailPath = thumbnailPath,
            localPath = localPath,
            resultModelPath = resultModelPath,
            serverJobId = serverJobId
        )
    }

    private fun parseMode(raw: String): ScanMode =
        ScanMode.entries.firstOrNull { it.name == raw } ?: ScanMode.ObjectOrbitScan

    private fun parseStatus(raw: String, resultModelPath: String?): ScanStatus {
        if (!resultModelPath.isNullOrBlank()) return ScanStatus.ModelReady
        return ScanStatus.entries.firstOrNull { it.name == raw } ?: ScanStatus.ScanFinished
    }
}
