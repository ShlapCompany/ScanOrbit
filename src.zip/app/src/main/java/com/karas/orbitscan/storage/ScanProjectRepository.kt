package com.karas.orbitscan.storage

import com.karas.orbitscan.domain.model.ScanMode
import com.karas.orbitscan.domain.model.ScanProject
import com.karas.orbitscan.domain.model.ScanStatus
import java.time.Instant
import java.util.UUID

/**
 * MVP-заглушка локального репозитория.
 * Этап 8: заменить на Room + FileStorageManager + scan_session.json.
 */
class ScanProjectRepository {
    fun demoProjects(): List<ScanProject> = listOf(
        ScanProject(
            id = UUID.randomUUID().toString(),
            name = "Тестовый объект",
            mode = ScanMode.ObjectOrbitScan,
            createdAt = Instant.now().minusSeconds(3600),
            updatedAt = Instant.now().minusSeconds(600),
            status = ScanStatus.Draft,
            coveragePercent = 42,
            frameCount = 24
        ),
        ScanProject(
            id = UUID.randomUUID().toString(),
            name = "Скан автомобиля",
            mode = ScanMode.CarScan,
            createdAt = Instant.now().minusSeconds(86_400),
            updatedAt = Instant.now().minusSeconds(70_000),
            status = ScanStatus.ScanFinished,
            coveragePercent = 76,
            frameCount = 88
        )
    )
}
