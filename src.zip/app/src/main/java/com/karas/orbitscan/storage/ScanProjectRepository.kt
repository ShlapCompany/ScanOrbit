package com.karas.orbitscan.storage

import com.karas.orbitscan.domain.model.ScanMode
import com.karas.orbitscan.domain.model.ScanProject
import com.karas.orbitscan.domain.model.ScanStatus
import java.time.Instant

/**
 * Этап 8: реальный репозиторий проектов поверх файлового хранилища.
 *
 * Источник правды — папки в filesDir/scans/<id>/ с scan_session.json внутри.
 * Room сознательно НЕ используем: для MVP список проектов маленький, а единый
 * scan_session.json проще и переносим (его же позже отправим на сервер, Этап 9).
 */
class ScanProjectRepository(
    private val storage: FileStorageManager,
    private val sessionWriter: ScanSessionWriter = ScanSessionWriter()
) {

    /** Все сохранённые проекты, новые сверху. Читает scan_session.json каждой папки. */
    fun loadProjects(): List<ScanProject> {
        return storage.listProjectIds()
            .mapNotNull { id ->
                val summary = sessionWriter.readSummary(storage.sessionJsonFile(id)) ?: return@mapNotNull null
                summary.toScanProject(localPath = storage.projectDir(id).absolutePath)
            }
            .sortedByDescending { it.createdAt }
    }

    fun deleteProject(projectId: String): Boolean = storage.deleteProject(projectId)

    private fun ScanSessionWriter.ProjectSummary.toScanProject(localPath: String): ScanProject {
        val createdInstant = if (createdAtMillis > 0) {
            Instant.ofEpochMilli(createdAtMillis)
        } else {
            Instant.now()
        }
        return ScanProject(
            id = id,
            name = name,
            mode = parseMode(mode),
            createdAt = createdInstant,
            updatedAt = createdInstant,
            // На Этапе 8 завершённый локальный скан = "Скан завершён".
            // Статусы обработки (Processing/ModelReady) появятся на Этапе 9 (сервер).
            status = ScanStatus.ScanFinished,
            coveragePercent = coveragePercent,
            frameCount = frameCount,
            thumbnailPath = thumbnailPath,
            localPath = localPath
        )
    }

    private fun parseMode(raw: String): ScanMode =
        ScanMode.entries.firstOrNull { it.name == raw } ?: ScanMode.ObjectOrbitScan
}
