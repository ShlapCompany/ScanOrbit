package com.karas.orbitscan.core

import android.content.Context
import android.content.SharedPreferences

/**
 * Простое хранилище настроек поверх SharedPreferences.
 *
 * Здесь только пользовательские переключатели и адрес сервера для будущего
 * коннекта с ПК (Этап 9). Сами проекты/файлы хранит FileStorageManager.
 */
class AppSettings(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("orbitscan_settings", Context.MODE_PRIVATE)

    /** Глобальный тумблер: разрешено ли сканирование вообще. */
    var scanningEnabled: Boolean
        get() = prefs.getBoolean(KEY_SCAN_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_SCAN_ENABLED, value).apply()

    /** Использовать Depth API, если устройство поддерживает. */
    var useDepth: Boolean
        get() = prefs.getBoolean(KEY_USE_DEPTH, true)
        set(value) = prefs.edit().putBoolean(KEY_USE_DEPTH, value).apply()

    /** Показывать расширенные подсказки во время скана. */
    var advancedHints: Boolean
        get() = prefs.getBoolean(KEY_ADVANCED_HINTS, true)
        set(value) = prefs.edit().putBoolean(KEY_ADVANCED_HINTS, value).apply()

    /** Адрес сервера-ПК для отправки проектов на реконструкцию (Этап 9). */
    var serverUrl: String
        get() = prefs.getString(KEY_SERVER_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_SERVER_URL, value).apply()

    companion object {
        private const val KEY_SCAN_ENABLED = "scanning_enabled"
        private const val KEY_USE_DEPTH = "use_depth"
        private const val KEY_ADVANCED_HINTS = "advanced_hints"
        private const val KEY_SERVER_URL = "server_url"
    }
}
