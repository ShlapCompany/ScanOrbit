package com.karas.orbitscan.storage

import android.graphics.Bitmap
import android.graphics.Color
import android.media.Image
import com.google.ar.core.Frame
import com.google.ar.core.exceptions.NotYetAvailableException
import com.karas.orbitscan.domain.model.CameraIntrinsics
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/**
 * Этап 7: извлечение depth/confidence и черновой point cloud.
 *
 * Это preview-данные, а не финальная реконструкция: depth может быть редким,
 * шумным и отсутствовать на части устройств/кадров. Все Image закрываются сразу.
 */
object DepthFrameSaver {

    data class DepthCapture(
        val depthPngBytes: ByteArray,
        val confidencePngBytes: ByteArray?,
        val pointCloudPlyBytes: ByteArray?,
        val validPointCount: Int,
        val averageConfidence: Float
    )

    data class SavedDepth(
        val depthPath: String,
        val confidencePath: String?,
        val pointCloudPath: String?,
        val validPointCount: Int,
        val averageConfidence: Float
    )

    fun captureDepth(frame: Frame, intrinsics: CameraIntrinsics?): DepthCapture? {
        val depthImage = tryAcquireRawDepth(frame) ?: tryAcquireDenseDepth(frame) ?: return null
        depthImage.use { depth ->
            val confidenceImage = tryAcquireConfidence(frame)
            confidenceImage?.use { conf ->
                return buildDepthCapture(depth, conf, intrinsics)
            }
            return buildDepthCapture(depth, null, intrinsics)
        }
    }

    fun writeDepthOutputs(
        capture: DepthCapture,
        depthFile: File,
        confidenceFile: File,
        pointCloudFile: File
    ): SavedDepth? {
        return try {
            depthFile.parentFile?.mkdirs()
            FileOutputStream(depthFile).use { it.write(capture.depthPngBytes) }

            val confPath = capture.confidencePngBytes?.let { bytes ->
                confidenceFile.parentFile?.mkdirs()
                FileOutputStream(confidenceFile).use { it.write(bytes) }
                confidenceFile.absolutePath
            }

            val cloudPath = capture.pointCloudPlyBytes?.let { bytes ->
                pointCloudFile.parentFile?.mkdirs()
                FileOutputStream(pointCloudFile).use { it.write(bytes) }
                pointCloudFile.absolutePath
            }

            SavedDepth(
                depthPath = depthFile.absolutePath,
                confidencePath = confPath,
                pointCloudPath = cloudPath,
                validPointCount = capture.validPointCount,
                averageConfidence = capture.averageConfidence
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun tryAcquireRawDepth(frame: Frame): Image? = try {
        frame.acquireRawDepthImage16Bits()
    } catch (e: NotYetAvailableException) {
        null
    } catch (e: Throwable) {
        null
    }

    private fun tryAcquireDenseDepth(frame: Frame): Image? = try {
        frame.acquireDepthImage16Bits()
    } catch (e: NotYetAvailableException) {
        null
    } catch (e: Throwable) {
        null
    }

    private fun tryAcquireConfidence(frame: Frame): Image? = try {
        frame.acquireRawDepthConfidenceImage()
    } catch (e: NotYetAvailableException) {
        null
    } catch (e: Throwable) {
        null
    }

    private fun buildDepthCapture(
        depthImage: Image,
        confidenceImage: Image?,
        intrinsics: CameraIntrinsics?
    ): DepthCapture? {
        val width = depthImage.width
        val height = depthImage.height
        if (width <= 0 || height <= 0) return null

        val depthMm = IntArray(width * height)
        val confidence = IntArray(width * height) { if (confidenceImage == null) 255 else 0 }

        readDepth16(depthImage, depthMm)
        if (confidenceImage != null) readConfidence8(confidenceImage, confidence)

        val depthPng = encodeDepthPreviewPng(depthMm, width, height)
        val confidencePng = if (confidenceImage != null) encodeConfidencePng(confidence, width, height) else null
        val pointCloud = buildPointCloudPly(depthMm, confidence, width, height, intrinsics)

        val valid = pointCloud.first
        val avgConf = if (valid > 0) pointCloud.second else 0f

        return DepthCapture(
            depthPngBytes = depthPng,
            confidencePngBytes = confidencePng,
            pointCloudPlyBytes = pointCloud.third,
            validPointCount = valid,
            averageConfidence = avgConf
        )
    }

    private fun readDepth16(image: Image, outDepthMm: IntArray) {
        val plane = image.planes[0]
        val buffer = plane.buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        val rowStride = plane.rowStride
        val pixelStride = max(2, plane.pixelStride)
        val width = image.width
        val height = image.height

        for (y in 0 until height) {
            for (x in 0 until width) {
                val index = y * rowStride + x * pixelStride
                if (index + 1 < buffer.capacity()) {
                    outDepthMm[y * width + x] = buffer.getShort(index).toInt() and 0xFFFF
                }
            }
        }
    }

    private fun readConfidence8(image: Image, outConfidence: IntArray) {
        val plane = image.planes[0]
        val buffer = plane.buffer.duplicate()
        val rowStride = plane.rowStride
        val pixelStride = max(1, plane.pixelStride)
        val width = image.width
        val height = image.height

        for (y in 0 until height) {
            for (x in 0 until width) {
                val index = y * rowStride + x * pixelStride
                if (index < buffer.capacity()) {
                    outConfidence[y * width + x] = buffer.get(index).toInt() and 0xFF
                }
            }
        }
    }

    private fun encodeDepthPreviewPng(depthMm: IntArray, width: Int, height: Int): ByteArray {
        val pixels = IntArray(width * height)
        for (i in depthMm.indices) {
            val mm = depthMm[i]
            val v = if (mm <= 0) 0 else (255 - (mm.coerceAtMost(8000) * 255 / 8000)).coerceIn(0, 255)
            pixels[i] = Color.rgb(v, v, v)
        }
        return bitmapToPng(width, height, pixels)
    }

    private fun encodeConfidencePng(conf: IntArray, width: Int, height: Int): ByteArray {
        val pixels = IntArray(width * height)
        for (i in conf.indices) {
            val v = conf[i].coerceIn(0, 255)
            pixels[i] = Color.rgb(v, v, v)
        }
        return bitmapToPng(width, height, pixels)
    }

    private fun bitmapToPng(width: Int, height: Int, pixels: IntArray): ByteArray {
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height)
        val out = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
        bitmap.recycle()
        return out.toByteArray()
    }

    /** Returns Triple(validCount, averageConfidence, plyBytes). */
    private fun buildPointCloudPly(
        depthMm: IntArray,
        confidence: IntArray,
        width: Int,
        height: Int,
        intrinsics: CameraIntrinsics?
    ): Triple<Int, Float, ByteArray?> {
        if (intrinsics == null) return Triple(0, 0f, null)

        val fx = intrinsics.focalLengthX * width.toFloat() / max(1, intrinsics.imageWidth).toFloat()
        val fy = intrinsics.focalLengthY * height.toFloat() / max(1, intrinsics.imageHeight).toFloat()
        val cx = intrinsics.principalPointX * width.toFloat() / max(1, intrinsics.imageWidth).toFloat()
        val cy = intrinsics.principalPointY * height.toFloat() / max(1, intrinsics.imageHeight).toFloat()
        if (fx <= 0f || fy <= 0f) return Triple(0, 0f, null)

        val step = max(2, min(width, height) / 80)
        val points = ArrayList<String>(4096)
        var confidenceSum = 0f

        var y = 0
        while (y < height) {
            var x = 0
            while (x < width) {
                val index = y * width + x
                val mm = depthMm[index]
                val conf = confidence[index]
                if (mm in 200..15000 && conf >= 96) {
                    val z = mm / 1000f
                    val px = (x - cx) / fx * z
                    val py = -(y - cy) / fy * z
                    points.add("$px $py $z")
                    confidenceSum += conf / 255f
                }
                x += step
            }
            y += step
        }

        if (points.isEmpty()) return Triple(0, 0f, null)
        val header = buildString {
            appendLine("ply")
            appendLine("format ascii 1.0")
            appendLine("comment OrbitScan preview point cloud in camera coordinates")
            appendLine("element vertex ${points.size}")
            appendLine("property float x")
            appendLine("property float y")
            appendLine("property float z")
            appendLine("end_header")
        }
        val body = points.joinToString(separator = "\n", postfix = "\n")
        return Triple(points.size, confidenceSum / points.size.toFloat(), (header + body).toByteArray())
    }
}
