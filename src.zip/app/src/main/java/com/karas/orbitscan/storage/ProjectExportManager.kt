package com.karas.orbitscan.storage

import android.content.Context
import android.net.Uri
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Экспортирует приватные файлы проекта через Storage Access Framework.
 * Так пользователь может сохранить GLB/ZIP в Downloads или отправить файл дальше.
 */
class ProjectExportManager(
    private val appContext: Context,
    private val storage: FileStorageManager
) {
    fun copyModelGlbToUri(projectId: String, targetUri: Uri): Boolean {
        val source = storage.modelGlbFile(projectId)
        return copyFileToUri(source, targetUri)
    }

    fun exportProjectZipToUri(projectId: String, targetUri: Uri): Boolean {
        val zip = createProjectZip(projectId) ?: return false
        return copyFileToUri(zip, targetUri)
    }

    fun createProjectZip(projectId: String): File? {
        val projectDir = storage.projectDir(projectId)
        if (!projectDir.exists() || !projectDir.isDirectory) return null

        val exportDir = File(appContext.cacheDir, "exports").apply { mkdirs() }
        val zipFile = File(exportDir, "orbitscan_${projectId.take(8)}.zip")
        if (zipFile.exists()) zipFile.delete()

        ZipOutputStream(BufferedOutputStream(zipFile.outputStream())).use { zipOut ->
            projectDir.walkTopDown()
                .filter { it.isFile }
                .forEach { file ->
                    val relativeName = file.relativeTo(projectDir).invariantSeparatorsPath
                    zipOut.putNextEntry(ZipEntry(relativeName))
                    BufferedInputStream(FileInputStream(file)).use { input ->
                        input.copyTo(zipOut)
                    }
                    zipOut.closeEntry()
                }
        }
        return zipFile
    }

    private fun copyFileToUri(source: File, targetUri: Uri): Boolean {
        if (!source.exists() || !source.isFile) return false
        return try {
            appContext.contentResolver.openOutputStream(targetUri)?.use { output ->
                BufferedInputStream(FileInputStream(source)).use { input ->
                    input.copyTo(output)
                }
            } ?: return false
            true
        } catch (e: Exception) {
            false
        }
    }
}
