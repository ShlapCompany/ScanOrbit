package com.karas.orbitscan.ui.scan

import com.karas.orbitscan.domain.coverage.CoverageMap
import com.karas.orbitscan.domain.model.ScanObjectSize
import com.karas.orbitscan.domain.model.Vector3

sealed interface ScanPhase {
    data object SelectObject : ScanPhase
    data object Ready : ScanPhase
    data object Scanning : ScanPhase
    data object Finished : ScanPhase
}

/**
 * Этап 2-3: режим работы экрана сканирования.
 * - Ar: работает настоящая ARCore-сессия, сектор обновляется по движению телефона.
 * - Fallback: ARCore недоступен/нет разрешения — остаётся ручной режим с кнопкой "+ Кадр".
 * - Initializing: идёт проверка ARCore / установка сервисов.
 */
sealed interface ScanEngineMode {
    data object Initializing : ScanEngineMode
    data object Ar : ScanEngineMode
    data class Fallback(val reason: String) : ScanEngineMode
}

/**
 * Экранная позиция выбранного центра объекта. Нужна только для UI-маркера поверх камеры.
 * x/y хранятся как доли ширины/высоты GLSurfaceView: 0.0..1.0.
 */
data class ObjectCenterScreenPosition(
    val xFraction: Float,
    val yFraction: Float
)

data class ScanUiState(
    val phase: ScanPhase = ScanPhase.SelectObject,
    val engineMode: ScanEngineMode = ScanEngineMode.Initializing,
    val coverageMap: CoverageMap = CoverageMap.create(),
    val coveragePercent: Int = 0,
    val weakOrGoodPercent: Int = 0,
    val frameCount: Int = 0,
    val currentSectorId: Int? = null,
    val hint: String = "Наведите камеру на центр объекта и тапните по нему.",
    val qualityText: String = "Ожидание",
    val isTracking: Boolean = false,
    val hasDepth: Boolean = false,
    // Этап 2: живая скорость камеры (м/с) из ARCore — для подсказок и отладки.
    val cameraSpeed: Float = 0f,
    // Этап 3: выбранный пользователем центр объекта в AR-пространстве.
    val objectCenter: Vector3? = null,
    val objectCenterScreenPosition: ObjectCenterScreenPosition? = null,
    val selectedObjectSize: ScanObjectSize = ScanObjectSize.Medium,
    val objectRadiusMeters: Float = ScanObjectSize.Medium.radiusMeters
)
