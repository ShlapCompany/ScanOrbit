package com.karas.orbitscan.ui.scan

import com.karas.orbitscan.domain.coverage.CoverageMap

sealed interface ScanPhase {
    data object SelectObject : ScanPhase
    data object Ready : ScanPhase
    data object Scanning : ScanPhase
    data object Finished : ScanPhase
}

data class ScanUiState(
    val phase: ScanPhase = ScanPhase.SelectObject,
    val coverageMap: CoverageMap = CoverageMap.create(),
    val coveragePercent: Int = 0,
    val weakOrGoodPercent: Int = 0,
    val frameCount: Int = 0,
    val currentSectorId: Int? = null,
    val hint: String = "Наведите камеру на центр объекта и нажмите кнопку выбора.",
    val qualityText: String = "Ожидание",
    val isTracking: Boolean = false,
    val hasDepth: Boolean = false
)
