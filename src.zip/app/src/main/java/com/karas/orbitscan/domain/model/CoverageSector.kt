package com.karas.orbitscan.domain.model

enum class SectorState {
    NotScanned,
    Weak,
    Good
}

data class CoverageSector(
    val id: Int,
    val azimuthIndex: Int,
    val elevationIndex: Int,
    val score: Int = 0,
    val state: SectorState = SectorState.NotScanned,
    val isRequired: Boolean = true
)
