package com.karas.orbitscan.domain.coverage

import com.karas.orbitscan.domain.model.CoverageSector
import com.karas.orbitscan.domain.model.FrameQuality
import com.karas.orbitscan.domain.model.SectorState
import com.karas.orbitscan.domain.model.Vector3
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.floor
import kotlin.math.sqrt

class CoverageMap private constructor(
    val azimuthSectors: Int,
    val elevationSectors: Int,
    val sectors: List<CoverageSector>
) {
    fun updateWithAcceptedFrame(sectorId: Int, quality: FrameQuality): CoverageMap {
        val delta = 1 +
            (if (quality.cameraSpeedScore >= 0.45f) 1 else 0) +
            (if (quality.blurScore >= 0.45f) 1 else 0) +
            (if (quality.brightnessScore >= 0.45f) 1 else 0) +
            (if (quality.hasDepth) 1 else 0)

        val newSectors = sectors.map { sector ->
            if (sector.id != sectorId) sector else {
                val newScore = (sector.score + delta).coerceAtMost(5)
                sector.copy(score = newScore, state = stateForScore(newScore))
            }
        }
        return CoverageMap(azimuthSectors, elevationSectors, newSectors)
    }

    fun sectorForCameraPosition(objectCenter: Vector3, cameraPosition: Vector3): CoverageSector {
        val direction = (cameraPosition - objectCenter).normalized()
        val azimuthRadians = atan2(direction.z.toDouble(), direction.x.toDouble())
        val azimuthDegrees = ((Math.toDegrees(azimuthRadians) + 360.0) % 360.0).toFloat()

        val horizontalLength = sqrt(direction.x * direction.x + direction.z * direction.z)
        val elevationRadians = atan2(direction.y.toDouble(), horizontalLength.toDouble())
        val elevationDegrees = Math.toDegrees(elevationRadians).toFloat().coerceIn(-89.9f, 89.9f)

        val azimuthIndex = floor(azimuthDegrees / (360f / azimuthSectors)).toInt()
            .coerceIn(0, azimuthSectors - 1)
        val elevationIndex = floor((elevationDegrees + 90f) / (180f / elevationSectors)).toInt()
            .coerceIn(0, elevationSectors - 1)

        return sectors.first { it.azimuthIndex == azimuthIndex && it.elevationIndex == elevationIndex }
    }

    fun coveragePercent(): Int {
        val required = sectors.filter { it.isRequired }
        if (required.isEmpty()) return 0
        val goodCount = required.count { it.state == SectorState.Good }
        return ((goodCount.toFloat() / required.size.toFloat()) * 100f).toInt()
    }

    fun weakOrGoodPercent(): Int {
        val required = sectors.filter { it.isRequired }
        if (required.isEmpty()) return 0
        val covered = required.count { it.state != SectorState.NotScanned }
        return ((covered.toFloat() / required.size.toFloat()) * 100f).toInt()
    }

    fun nextHint(currentSectorId: Int? = null): String {
        val required = sectors.filter { it.isRequired }
        val notScanned = required.filter { it.state == SectorState.NotScanned }
        val weak = required.filter { it.state == SectorState.Weak }

        if (notScanned.isEmpty() && weak.isEmpty()) return "Покрытие хорошее, можно завершать скан."
        if (notScanned.isEmpty() && weak.isNotEmpty()) return "Есть жёлтые зоны: пройдите их ещё раз медленнее."

        val topMissing = notScanned.count { it.elevationIndex == elevationSectors - 1 }
        val bottomMissing = notScanned.count { it.elevationIndex == 0 }
        val middleMissing = notScanned.count { it.elevationIndex == elevationSectors / 2 }

        if (topMissing > middleMissing) return "Поднимите камеру выше и снимите объект немного сверху."
        if (bottomMissing > middleMissing) return "Опустите камеру ниже и снимите нижнюю часть объекта."

        val nearest = notScanned.firstOrNull()
        return if (nearest != null) {
            val side = when (nearest.azimuthIndex) {
                in 0..3 -> "спереди/справа"
                in 4..7 -> "сзади/справа"
                in 8..11 -> "сзади/слева"
                else -> "спереди/слева"
            }
            "Остались красные зоны: снимите объект $side."
        } else {
            "Продолжайте плавно обходить объект по кругу."
        }
    }

    companion object {
        fun create(
            azimuthSectors: Int = 16,
            elevationSectors: Int = 3
        ): CoverageMap {
            val sectors = buildList {
                var id = 0
                repeat(elevationSectors) { elevation ->
                    repeat(azimuthSectors) { azimuth ->
                        add(
                            CoverageSector(
                                id = id++,
                                azimuthIndex = azimuth,
                                elevationIndex = elevation,
                                // Для MVP все сектора обязательные. Позже можно сделать маску обязательности по режиму.
                                isRequired = true
                            )
                        )
                    }
                }
            }
            return CoverageMap(azimuthSectors, elevationSectors, sectors)
        }

        private fun stateForScore(score: Int): SectorState = when {
            score <= 0 -> SectorState.NotScanned
            score < 3 -> SectorState.Weak
            else -> SectorState.Good
        }
    }
}
