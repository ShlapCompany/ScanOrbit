package com.karas.orbitscan.reconstruction

import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

object GlbFileInspector {
    data class GlbInfo(
        val isValid: Boolean,
        val version: Int,
        val declaredLength: Int,
        val fileLength: Long,
        val jsonPreview: String?
    )

    fun inspect(path: String?): GlbInfo? {
        if (path.isNullOrBlank()) return null
        val file = File(path)
        if (!file.exists() || file.length() < 20) return null
        return try {
            val bytes = file.readBytes()
            val buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
            val magic = buffer.int
            val version = buffer.int
            val length = buffer.int
            if (magic != 0x46546C67) {
                return GlbInfo(false, version, length, file.length(), null)
            }
            val chunkLength = buffer.int
            val chunkType = buffer.int
            val preview = if (chunkType == 0x4E4F534A && chunkLength > 0 && buffer.remaining() >= chunkLength) {
                val jsonBytes = ByteArray(chunkLength)
                buffer.get(jsonBytes)
                String(jsonBytes, Charsets.UTF_8).trim()
            } else null
            GlbInfo(true, version, length, file.length(), preview)
        } catch (e: Exception) {
            null
        }
    }
}
