package com.karas.orbitscan.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.karas.orbitscan.ui.home.HomeScreen
import com.karas.orbitscan.ui.preview.PreviewScreen
import com.karas.orbitscan.ui.scan.ScanScreen
import com.karas.orbitscan.ui.settings.SettingsScreen

private enum class Screen {
    Home,
    Scan,
    Preview,
    Settings
}

@Composable
fun OrbitScanApp() {
    var screen by remember { mutableStateOf(Screen.Home) }

    when (screen) {
        Screen.Home -> HomeScreen(
            onNewScanClick = { screen = Screen.Scan },
            onSettingsClick = { screen = Screen.Settings },
            onOpenProjectClick = { screen = Screen.Preview }
        )
        Screen.Scan -> ScanScreen(
            onBackClick = { screen = Screen.Home },
            onPreviewClick = { screen = Screen.Preview }
        )
        Screen.Preview -> PreviewScreen(
            onBackClick = { screen = Screen.Home },
            onContinueScanClick = { screen = Screen.Scan }
        )
        Screen.Settings -> SettingsScreen(onBackClick = { screen = Screen.Home })
    }
}
