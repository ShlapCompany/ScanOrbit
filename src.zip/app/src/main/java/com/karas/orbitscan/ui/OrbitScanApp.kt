package com.karas.orbitscan.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.karas.orbitscan.ui.home.HomeScreen
import com.karas.orbitscan.ui.preview.PreviewScreen
import com.karas.orbitscan.ui.scan.ScanScreen
import com.karas.orbitscan.ui.settings.SettingsScreen
import com.karas.orbitscan.ui.viewer.ModelViewerScreen

private enum class Screen {
    Home,       // проекты (слева)
    Scan,       // сканирование (центр, плюсик)
    Settings,   // настройки (справа)
    Preview,    // детали проекта (без нижней навигации)
    ModelViewer // просмотр модели (без нижней навигации)
}

@Composable
fun OrbitScanApp() {
    var screen by remember { mutableStateOf(Screen.Home) }
    var selectedProjectId by remember { mutableStateOf<String?>(null) }
    var selectedModelPath by remember { mutableStateOf<String?>(null) }

    // Нижняя навигация видна только на трёх главных вкладках.
    // На Scan (камера на весь экран), Preview и ModelViewer — скрыта.
    val showBottomBar = screen == Screen.Home || screen == Screen.Settings

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                OrbitBottomBar(
                    current = screen,
                    onProjects = { screen = Screen.Home },
                    onScan = {
                        selectedProjectId = null
                        selectedModelPath = null
                        screen = Screen.Scan
                    },
                    onSettings = { screen = Screen.Settings }
                )
            }
        }
    ) { padding ->
        val contentModifier = Modifier.padding(padding)
        when (screen) {
            Screen.Home -> HomeScreen(
                modifier = contentModifier,
                onNewScanClick = {
                    selectedProjectId = null
                    selectedModelPath = null
                    screen = Screen.Scan
                },
                onSettingsClick = { screen = Screen.Settings },
                onOpenProjectClick = { projectId ->
                    selectedProjectId = projectId
                    screen = Screen.Preview
                }
            )
            Screen.Scan -> ScanScreen(
                onBackClick = { screen = Screen.Home },
                onPreviewClick = { projectId ->
                    selectedProjectId = projectId ?: selectedProjectId
                    screen = Screen.Preview
                }
            )
            Screen.Settings -> SettingsScreen(
                modifier = contentModifier,
                onBackClick = { screen = Screen.Home }
            )
            Screen.Preview -> PreviewScreen(
                projectId = selectedProjectId,
                onBackClick = { screen = Screen.Home },
                onContinueScanClick = { screen = Screen.Scan },
                onOpenModelClick = { modelPath ->
                    selectedModelPath = modelPath
                    screen = Screen.ModelViewer
                }
            )
            Screen.ModelViewer -> ModelViewerScreen(
                modelPath = selectedModelPath,
                onBackClick = { screen = Screen.Preview }
            )
        }
    }
}

@Composable
private fun OrbitBottomBar(
    current: Screen,
    onProjects: () -> Unit,
    onScan: () -> Unit,
    onSettings: () -> Unit
) {
    NavigationBar {
        NavigationBarItem(
            selected = current == Screen.Home,
            onClick = onProjects,
            icon = { Icon(Icons.Filled.List, contentDescription = "Проекты") },
            label = { Text("Проекты") }
        )
        NavigationBarItem(
            selected = current == Screen.Scan,
            onClick = onScan,
            icon = { Icon(Icons.Filled.Add, contentDescription = "Новый скан") },
            label = { Text("Скан") }
        )
        NavigationBarItem(
            selected = current == Screen.Settings,
            onClick = onSettings,
            icon = { Icon(Icons.Filled.Settings, contentDescription = "Настройки") },
            label = { Text("Настройки") }
        )
    }
}
