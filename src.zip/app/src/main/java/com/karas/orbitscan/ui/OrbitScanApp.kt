package com.karas.orbitscan.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import com.karas.orbitscan.ui.home.HomeScreen
import com.karas.orbitscan.ui.preview.PreviewScreen
import com.karas.orbitscan.ui.scan.ScanScreen
import com.karas.orbitscan.ui.settings.SettingsScreen
import com.karas.orbitscan.ui.viewer.ModelViewerScreen

private enum class Screen {
    Home,
    Scan,
    Preview,
    ModelViewer,
    Settings
}

@Composable
fun OrbitScanApp() {
    var screen by remember { mutableStateOf(Screen.Home) }
    var selectedProjectId by remember { mutableStateOf<String?>(null) }
    var selectedModelPath by remember { mutableStateOf<String?>(null) }

    when (screen) {
        Screen.Home -> HomeScreen(
            onNewScanClick = {
                selectedProjectId = null
                selectedModelPath = null
                screen = Screen.Scan
            },
            onSettingsClick = { screen = Screen.Settings },
            onOpenProjectClick = { projectId ->
                selectedProjectId = projectId
                screen = Screen.Preview
            }
        )
        Screen.Scan -> ScanScreen(
            onBackClick = { screen = Screen.Home },
            onPreviewClick = { projectId ->
                selectedProjectId = projectId ?: selectedProjectId
                screen = Screen.Preview
            }
        )
        Screen.Preview -> PreviewScreen(
            projectId = selectedProjectId,
            onBackClick = { screen = Screen.Home },
            onContinueScanClick = { screen = Screen.Scan },
            onOpenModelClick = { modelPath ->
                selectedModelPath = modelPath
                screen = Screen.ModelViewer
            }
        )
        Screen.ModelViewer -> ModelViewerScreen(
            modelPath = selectedModelPath,
            onBackClick = { screen = Screen.Preview }
        )
        Screen.Settings -> SettingsScreen(onBackClick = { screen = Screen.Home })
    }
}
