package com.karas.orbitscan.storage

import com.karas.orbitscan.domain.model.CameraIntrinsics
import com.karas.orbitscan.domain.model.ScanFrame
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Этап 5: сериализует метаданные скан-сессии и кадров в scan_session.json.
 *
 * Используем org.json (входит в Android SDK) — без сторонних зависимостей.
 * Структура соответствует разделам 9.1 и 9.2 ТЗ. На Этапе 9 этот же JSON
 * (или его подмножество) уйдёт на сервер вместе с фотографиями.
 */
class ScanSessionWriter {

    /**
     * Метаданные уровня сессии. cameraIntrinsics берём из первого валидного кадра
     * (для MVP достаточно; ARCore intrinsics стабильны в рамках сессии).
     */
    data class SessionMeta(
        val projectId: String,
        val name: String,
        val mode: String,
        val createdAtMillis: Long,
        val deviceModel: String,
        val androidVersion: Int,
        val appVersion: String,
        val depthSupported: Boolean,
        val objectCenter: FloatArray,   // [x,y,z]
        val objectRadius: Float,
        val azimuthSectors: Int,
        val elevationSectors: Int,
        val coveragePercent: Int
    )

    fun write(
        targetFile: File,
        meta: SessionMeta,
        frames: List<ScanFrame>,
        sectorStates: Map<Int, String>
    ): Boolean {
        return try {
            val root = JSONObject().apply {
                put("id", meta.projectId)
                put("name", meta.name)
                put("mode", meta.mode)
                put("createdAtMillis", meta.createdAtMillis)
                put("device", meta.deviceModel)
                put("androidVersion", meta.androidVersion)
                put("appVersion", meta.appVersion)
                put("depthSupported", meta.depthSupported)
                put("objectCenter", JSONArray(listOf(
                    meta.objectCenter.getOrElse(0) { 0f },
                    meta.objectCenter.getOrElse(1) { 0f },
                    meta.objectCenter.getOrElse(2) { 0f }
                )))
                put("objectRadius", meta.objectRadius)
                put("azimuthSectors", meta.azimuthSectors)
                put("elevationSectors", meta.elevationSectors)
                put("coveragePercent", meta.coveragePercent)

                // Состояния секторов: { "0": "GOOD", "1": "NOT_SCANNED", ... }
                val sectorsJson = JSONObject()
                sectorStates.forEach { (id, state) -> sectorsJson.put(id.toString(), state) }
                put("sectors", sectorsJson)

                // Кадры
                val framesJson = JSONArray()
                frames.forEach { framesJson.put(frameToJson(it)) }
                put("frames", framesJson)
            }

            targetFile.parentFile?.mkdirs()
            targetFile.writeText(root.toString(2))
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun frameToJson(frame: ScanFrame): JSONObject = JSONObject().apply {
        put("id", frame.id)
        put("imagePath", frame.imagePath)
        put("timestampMillis", frame.timestampMillis)
        put("sectorId", frame.sectorId)
        put("qualityScore", frame.qualityScore)
        put("blurScore", frame.blurScore.toDouble())
        put("brightnessScore", frame.brightnessScore.toDouble())
        put("hasDepth", frame.hasDepth)
        frame.depthPath?.let { put("depthPath", it) }
        frame.confidencePath?.let { put("confidencePath", it) }

        frame.cameraPose?.let { pose ->
            put("cameraPosition", JSONArray(listOf(pose.position.x, pose.position.y, pose.position.z)))
            put("cameraRotation", JSONArray(pose.rotationQuaternion.toList()))
        }
        frame.cameraIntrinsics?.let { put("cameraIntrinsics", intrinsicsToJson(it)) }
    }

    private fun intrinsicsToJson(intr: CameraIntrinsics): JSONObject = JSONObject().apply {
        put("focalLengthX", intr.focalLengthX.toDouble())
        put("focalLengthY", intr.focalLengthY.toDouble())
        put("principalPointX", intr.principalPointX.toDouble())
        put("principalPointY", intr.principalPointY.toDouble())
        put("imageWidth", intr.imageWidth)
        put("imageHeight", intr.imageHeight)
    }

    /**
     * Этап 8: лёгкое чтение метаданных проекта для списка на главном экране.
     * Возвращает компактную сводку (без полного списка кадров — он не нужен в списке).
     */
    data class ProjectSummary(
        val id: String,
        val name: String,
        val mode: String,
        val createdAtMillis: Long,
        val coveragePercent: Int,
        val frameCount: Int,
        val thumbnailPath: String?
    )

    fun readSummary(file: File): ProjectSummary? {
        return try {
            if (!file.exists()) return null
            val root = JSONObject(file.readText())
            val framesCount = root.optJSONArray("frames")?.length() ?: 0
            ProjectSummary(
                id = root.optString("id"),
                name = root.optString("name", "Без названия"),
                mode = root.optString("mode", "ObjectOrbitScan"),
                createdAtMillis = root.optLong("createdAtMillis", 0L),
                coveragePercent = root.optInt("coveragePercent", 0),
                frameCount = framesCount,
                thumbnailPath = if (root.has("thumbnailPath")) root.optString("thumbnailPath") else null
            )
        } catch (e: Exception) {
            null
        }
    }
}
