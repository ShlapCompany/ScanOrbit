package com.karas.orbitscan.storage

import com.karas.orbitscan.domain.model.CameraIntrinsics
import com.karas.orbitscan.domain.model.ScanFrame
import com.karas.orbitscan.domain.model.ScanStatus
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Этап 8-10: запись/чтение scan_session.json.
 *
 * JSON остаётся главным переносимым форматом проекта: его можно открыть локально,
 * отправить на сервер реконструкции и обновить статус после обработки.
 */
class ScanSessionWriter {

    data class SessionMeta(
        val projectId: String,
        val name: String,
        val mode: String,
        val createdAtMillis: Long,
        val deviceModel: String,
        val androidVersion: Int,
        val appVersion: String,
        val depthSupported: Boolean,
        val objectCenter: FloatArray,
        val objectRadius: Float,
        val azimuthSectors: Int,
        val elevationSectors: Int,
        val coveragePercent: Int,
        val thumbnailPath: String? = null,
        val previewPointCloudPath: String? = null
    )

    fun write(
        targetFile: File,
        meta: SessionMeta,
        frames: List<ScanFrame>,
        sectorStates: Map<Int, String>
    ): Boolean {
        return try {
            val root = JSONObject().apply {
                put("id", meta.projectId)
                put("name", meta.name)
                put("mode", meta.mode)
                put("createdAtMillis", meta.createdAtMillis)
                put("updatedAtMillis", System.currentTimeMillis())
                put("device", meta.deviceModel)
                put("androidVersion", meta.androidVersion)
                put("appVersion", meta.appVersion)
                put("depthSupported", meta.depthSupported)
                put("usedRawDepth", frames.any { it.hasDepth })
                put("status", ScanStatus.ScanFinished.name)
                put("objectCenter", JSONArray(listOf(
                    meta.objectCenter.getOrElse(0) { 0f },
                    meta.objectCenter.getOrElse(1) { 0f },
                    meta.objectCenter.getOrElse(2) { 0f }
                )))
                put("objectRadius", meta.objectRadius)
                put("azimuthSectors", meta.azimuthSectors)
                put("elevationSectors", meta.elevationSectors)
                put("coveragePercent", meta.coveragePercent)
                meta.thumbnailPath?.let { put("thumbnailPath", it) }
                meta.previewPointCloudPath?.let { put("previewPointCloudPath", it) }

                val sectorsJson = JSONObject()
                sectorStates.forEach { (id, state) -> sectorsJson.put(id.toString(), state) }
                put("sectors", sectorsJson)

                val framesJson = JSONArray()
                frames.forEach { framesJson.put(frameToJson(it)) }
                put("frames", framesJson)
            }

            targetFile.parentFile?.mkdirs()
            targetFile.writeText(root.toString(2))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun updateProcessingStatus(
        file: File,
        status: ScanStatus,
        serverJobId: String? = null,
        processingStage: String? = null,
        processingProgress: Int? = null,
        resultModelPath: String? = null,
        errorMessage: String? = null
    ): Boolean {
        return try {
            if (!file.exists()) return false
            val root = JSONObject(file.readText())
            root.put("status", status.name)
            root.put("updatedAtMillis", System.currentTimeMillis())
            serverJobId?.let { root.put("serverJobId", it) }
            processingStage?.let { root.put("processingStage", it) }
            processingProgress?.let { root.put("processingProgress", it.coerceIn(0, 100)) }
            resultModelPath?.let { root.put("resultModelPath", it) }
            errorMessage?.let { root.put("errorMessage", it) }
            file.writeText(root.toString(2))
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun frameToJson(frame: ScanFrame): JSONObject = JSONObject().apply {
        put("id", frame.id)
        put("imagePath", frame.imagePath)
        put("timestampMillis", frame.timestampMillis)
        put("sectorId", frame.sectorId)
        put("qualityScore", frame.qualityScore)
        put("blurScore", frame.blurScore.toDouble())
        put("brightnessScore", frame.brightnessScore.toDouble())
        put("hasDepth", frame.hasDepth)
        put("depthPointCount", frame.depthPointCount)
        put("depthAverageConfidence", frame.depthAverageConfidence.toDouble())
        frame.depthPath?.let { put("depthPath", it) }
        frame.confidencePath?.let { put("confidencePath", it) }
        frame.pointCloudPath?.let { put("pointCloudPath", it) }

        frame.cameraPose?.let { pose ->
            put("cameraPosition", JSONArray(listOf(pose.position.x, pose.position.y, pose.position.z)))
            put("cameraRotation", JSONArray(pose.rotationQuaternion.toList()))
        }
        frame.cameraIntrinsics?.let { put("cameraIntrinsics", intrinsicsToJson(it)) }
    }

    private fun intrinsicsToJson(intr: CameraIntrinsics): JSONObject = JSONObject().apply {
        put("focalLengthX", intr.focalLengthX.toDouble())
        put("focalLengthY", intr.focalLengthY.toDouble())
        put("principalPointX", intr.principalPointX.toDouble())
        put("principalPointY", intr.principalPointY.toDouble())
        put("imageWidth", intr.imageWidth)
        put("imageHeight", intr.imageHeight)
    }

    data class ProjectSummary(
        val id: String,
        val name: String,
        val mode: String,
        val createdAtMillis: Long,
        val updatedAtMillis: Long,
        val status: String,
        val coveragePercent: Int,
        val frameCount: Int,
        val thumbnailPath: String?,
        val resultModelPath: String?,
        val serverJobId: String?,
        val previewPointCloudPath: String?
    )

    data class FrameSummary(
        val id: String,
        val imagePath: String,
        val timestampMillis: Long,
        val sectorId: Int,
        val qualityScore: Int,
        val blurScore: Float,
        val brightnessScore: Float,
        val hasDepth: Boolean,
        val depthPath: String?,
        val confidencePath: String?,
        val pointCloudPath: String?,
        val depthPointCount: Int,
        val cameraPosition: FloatArray?
    )

    data class ProjectDetails(
        val summary: ProjectSummary,
        val azimuthSectors: Int,
        val elevationSectors: Int,
        val objectRadius: Float,
        val sectors: Map<Int, String>,
        val frames: List<FrameSummary>,
        val processingStage: String?,
        val processingProgress: Int,
        val errorMessage: String?
    )

    fun readSummary(file: File): ProjectSummary? = readRoot(file)?.toProjectSummary()

    fun readDetails(file: File): ProjectDetails? {
        return try {
            val root = readRoot(file) ?: return null
            val sectorsJson = root.optJSONObject("sectors") ?: JSONObject()
            val sectors = mutableMapOf<Int, String>()
            sectorsJson.keys().forEach { key -> sectors[key.toIntOrNull() ?: return@forEach] = sectorsJson.optString(key) }

            val framesJson = root.optJSONArray("frames") ?: JSONArray()
            val frames = buildList {
                for (i in 0 until framesJson.length()) {
                    val item = framesJson.optJSONObject(i) ?: continue
                    add(item.toFrameSummary())
                }
            }

            ProjectDetails(
                summary = root.toProjectSummary(),
                azimuthSectors = root.optInt("azimuthSectors", 16),
                elevationSectors = root.optInt("elevationSectors", 3),
                objectRadius = root.optDouble("objectRadius", 1.5).toFloat(),
                sectors = sectors,
                frames = frames,
                processingStage = root.optStringOrNull("processingStage"),
                processingProgress = root.optInt("processingProgress", 0),
                errorMessage = root.optStringOrNull("errorMessage")
            )
        } catch (e: Exception) {
            null
        }
    }

    private fun readRoot(file: File): JSONObject? = try {
        if (!file.exists()) null else JSONObject(file.readText())
    } catch (e: Exception) {
        null
    }

    private fun JSONObject.toProjectSummary(): ProjectSummary {
        val framesCount = optJSONArray("frames")?.length() ?: 0
        return ProjectSummary(
            id = optString("id"),
            name = optString("name", "Без названия"),
            mode = optString("mode", "ObjectOrbitScan"),
            createdAtMillis = optLong("createdAtMillis", 0L),
            updatedAtMillis = optLong("updatedAtMillis", optLong("createdAtMillis", 0L)),
            status = optString("status", ScanStatus.ScanFinished.name),
            coveragePercent = optInt("coveragePercent", 0),
            frameCount = framesCount,
            thumbnailPath = optStringOrNull("thumbnailPath"),
            resultModelPath = optStringOrNull("resultModelPath"),
            serverJobId = optStringOrNull("serverJobId"),
            previewPointCloudPath = optStringOrNull("previewPointCloudPath")
        )
    }

    private fun JSONObject.toFrameSummary(): FrameSummary {
        val pos = optJSONArray("cameraPosition")?.let { arr ->
            floatArrayOf(
                arr.optDouble(0, 0.0).toFloat(),
                arr.optDouble(1, 0.0).toFloat(),
                arr.optDouble(2, 0.0).toFloat()
            )
        }
        return FrameSummary(
            id = optString("id"),
            imagePath = optString("imagePath"),
            timestampMillis = optLong("timestampMillis"),
            sectorId = optInt("sectorId"),
            qualityScore = optInt("qualityScore"),
            blurScore = optDouble("blurScore", 0.0).toFloat(),
            brightnessScore = optDouble("brightnessScore", 0.0).toFloat(),
            hasDepth = optBoolean("hasDepth", false),
            depthPath = optStringOrNull("depthPath"),
            confidencePath = optStringOrNull("confidencePath"),
            pointCloudPath = optStringOrNull("pointCloudPath"),
            depthPointCount = optInt("depthPointCount", 0),
            cameraPosition = pos
        )
    }

    private fun JSONObject.optStringOrNull(key: String): String? {
        if (!has(key)) return null
        val value = optString(key, "")
        return value.takeIf { it.isNotBlank() && it != "null" }
    }
}
