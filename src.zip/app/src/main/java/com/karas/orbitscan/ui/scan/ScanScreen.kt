package com.karas.orbitscan.ui.scan

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import com.karas.orbitscan.ui.components.GlassPanel
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.karas.orbitscan.ar.ArInitResult
import com.karas.orbitscan.ar.RealArSessionManager
import com.karas.orbitscan.ar.RealCameraPoseTracker
import com.karas.orbitscan.domain.model.ScanObjectSize
import com.karas.orbitscan.domain.model.SectorState
import com.karas.orbitscan.domain.model.Vector3
import com.karas.orbitscan.ui.theme.OrbitGreen
import com.karas.orbitscan.ui.theme.OrbitRed
import com.karas.orbitscan.ui.theme.OrbitYellow

/**
 * Этап 3: экран сканирования с выбором центра объекта.
 *
 * Поток:
 *  1. Проверяем CAMERA и запускаем ARCore Session.
 *  2. Пользователь тапает по объекту/поверхности в AR-камере.
 *  3. ArRenderer делает Frame.hitTest(x, y) и возвращает objectCenter.
 *  4. Пользователь выбирает примерный размер объекта.
 *  5. После «Начать» покрытие считается относительно выбранного objectCenter.
 *
 * Если ARCore недоступен, остаётся fallback-режим: условный центр + ручная кнопка «+ Кадр».
 */
@Composable
fun ScanScreen(
    onBackClick: () -> Unit,
    onPreviewClick: (String?) -> Unit,
    viewModel: ScanViewModel = viewModel()
) {
    val state = viewModel.uiState
    val context = LocalContext.current
    val activity = context as? Activity

    // Один экземпляр менеджера сессии и трекера на время жизни экрана.
    val sessionManager = remember { RealArSessionManager(context.applicationContext) }
    val poseTracker = remember { RealCameraPoseTracker() }

    // Этап 5: файловое хранилище + координатор захвата кадров.
    val storage = remember { com.karas.orbitscan.storage.FileStorageManager(context.applicationContext) }
    val captureCoordinator = remember { com.karas.orbitscan.storage.ScanFrameCaptureCoordinator(storage) }
    androidx.compose.runtime.LaunchedEffect(captureCoordinator) {
        viewModel.attachCaptureCoordinator(captureCoordinator)
        // Этап 8: даём ViewModel хранилище и метаданные устройства для scan_session.json.
        viewModel.attachStorage(
            storage = storage,
            deviceModel = android.os.Build.MODEL ?: "unknown",
            androidVersion = android.os.Build.VERSION.SDK_INT,
            appVersion = "0.1.0-mvp",
            depthSupported = sessionManager.isDepthSupported
        )
    }
    DisposableEffect(Unit) {
        onDispose { captureCoordinator.shutdown() }
    }

    // После успешной инициализации ARCore depthSupported становится известен — обновляем VM.
    LaunchedEffect(state.engineMode) {
        viewModel.attachStorage(
            storage = storage,
            deviceModel = android.os.Build.MODEL ?: "unknown",
            androidVersion = android.os.Build.VERSION.SDK_INT,
            appVersion = "0.1.0-mvp",
            depthSupported = sessionManager.isDepthSupported
        )
    }

    var hasCameraPermission by remember { mutableStateOf(CameraPermission.isGranted(context)) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            viewModel.setEngineMode(ScanEngineMode.Fallback("Нет разрешения на камеру"))
        } else if (activity != null) {
            tryInitAr(sessionManager, viewModel, activity)
        }
    }

    // Запрос разрешения / инициализация ARCore при первом показе экрана.
    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(CameraPermission.PERMISSION)
        } else if (activity != null) {
            tryInitAr(sessionManager, viewModel, activity)
        } else {
            viewModel.setEngineMode(ScanEngineMode.Fallback("Нет доступа к Activity"))
        }
    }

    // resume/pause/close ARCore-сессии вместе с экраном.
    DisposableEffect(state.engineMode) {
        if (state.engineMode is ScanEngineMode.Ar) {
            runCatching { sessionManager.resume() }
        }
        onDispose {
            runCatching { sessionManager.pause() }
        }
    }
    DisposableEffect(Unit) {
        onDispose { runCatching { sessionManager.close() } }
    }

    Scaffold { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF071018))
        ) {
            when (val mode = state.engineMode) {
                is ScanEngineMode.Ar -> {
                    ArCameraView(
                        modifier = Modifier.fillMaxSize(),
                        sessionProvider = { sessionManager.session },
                        poseTracker = poseTracker,
                        onTrackingState = { tracking ->
                            // Сообщаем ViewModel о потере/восстановлении трекинга
                            // (onPoseUpdated приходит только при tracking=true).
                            if (!tracking) {
                                viewModel.onArPose(
                                    cameraPosition = Vector3.Zero,
                                    cameraSpeed = 0f,
                                    trackingOk = false
                                )
                            }
                        },
                        onPoseUpdated = {
                            val pose = poseTracker.currentPoseOrNull()
                            val tracking = pose != null
                            val position = pose?.position ?: Vector3.Zero
                            viewModel.onArPose(
                                cameraPosition = position,
                                cameraSpeed = poseTracker.cameraSpeedMetersPerSecond(),
                                trackingOk = tracking
                            )
                        },
                        onObjectCenterSelected = viewModel::selectObjectFromArHit,
                        onObjectSelectionFailed = viewModel::onObjectHitTestFailed,
                        onArFrameForCapture = { frame ->
                            // GL-поток: решение о захвате + сам захват внутри ViewModel.
                            val pose = poseTracker.currentPoseOrNull()
                            viewModel.onArFrameForCapture(
                                frame = frame,
                                cameraPosition = pose?.position ?: Vector3.Zero,
                                cameraSpeed = poseTracker.cameraSpeedMetersPerSecond()
                            )
                        }
                    )
                }
                is ScanEngineMode.Fallback -> FallbackSurface(reason = mode.reason)
                ScanEngineMode.Initializing -> InitializingSurface()
            }

            ObjectCenterMarker(state = state)

            // Этап 5.1 (UI): минималистичный оверлей в стиле Polycam.
            // Камера на весь экран, поверх — только компактные элементы.
            // panelsExpanded управляет раскрытием детальной панели (сетка + размер).
            var panelsExpanded by remember { mutableStateOf(false) }

            // Верх: тонкая строка статуса + кнопка раскрытия.
            CompactStatusBar(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                state = state,
                expanded = panelsExpanded,
                onToggleExpand = { panelsExpanded = !panelsExpanded }
            )

            // Детальная панель (сетка покрытия + выбор размера) — только если раскрыта.
            if (panelsExpanded) {
                DetailPanel(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 64.dp, start = 12.dp, end = 12.dp),
                    state = state,
                    onObjectSizeSelected = viewModel::setObjectSize
                )
            }

            // Низ: компактные кнопки управления.
            CompactBottomControls(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(horizontal = 12.dp, vertical = 16.dp),
                state = state,
                onSelectObject = viewModel::selectObjectStub,
                onStart = viewModel::startScan,
                onSimulateFrame = viewModel::simulateUsefulFrame,
                onFinish = viewModel::finishScan,
                onPreview = { onPreviewClick(state.currentProjectId) },
                onReset = viewModel::reset,
                onBack = onBackClick
            )
        }
    }
}

/** Запускает инициализацию ARCore и проставляет engineMode по результату. */
private fun tryInitAr(
    sessionManager: RealArSessionManager,
    viewModel: ScanViewModel,
    activity: Activity
) {
    when (val result = sessionManager.createSessionIfNeeded(activity)) {
        ArInitResult.Ready -> {
            runCatching { sessionManager.resume() }
            viewModel.setEngineMode(ScanEngineMode.Ar)
        }
        ArInitResult.RequiresInstall -> {
            // Сервисы AR устанавливаются/обновляются — останемся в Initializing,
            // следующий заход на экран повторит попытку.
            viewModel.setEngineMode(ScanEngineMode.Initializing)
        }
        ArInitResult.Unsupported -> {
            viewModel.setEngineMode(ScanEngineMode.Fallback("Устройство не поддерживает ARCore"))
        }
        is ArInitResult.Error -> {
            viewModel.setEngineMode(ScanEngineMode.Fallback(result.message))
        }
    }
}

@Composable
private fun InitializingSurface() {
    Box(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Инициализация ARCore…",
            color = Color.White.copy(alpha = 0.7f),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.Center)
        )
    }
}

@Composable
private fun FallbackSurface(reason: String) {
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Режим фотосканирования (без AR)",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = reason,
                color = Color.White.copy(alpha = 0.6f),
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "Используйте «Выбрать объект», затем «+ Кадр», чтобы заполнять зоны покрытия.",
                color = Color.White.copy(alpha = 0.6f),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun ObjectCenterMarker(state: ScanUiState) {
    val point = state.objectCenterScreenPosition ?: return
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val markerSize = 34.dp
        val x = maxWidth * point.xFraction - markerSize / 2f
        val y = maxHeight * point.yFraction - markerSize / 2f
        Box(
            modifier = Modifier
                .offset(x = x, y = y)
                .size(markerSize)
                .clip(CircleShape)
                .background(OrbitGreen.copy(alpha = 0.22f))
                .border(width = 2.dp, color = OrbitGreen, shape = CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(OrbitGreen)
            )
        }
    }
}

// ============================================================================
// Этап 5.1 — минималистичный UI в духе Polycam.
// Камера на весь экран; данные — компактным оверлеем поверх.
// ============================================================================

/**
 * Компактная верхняя строка: процент покрытия, число фото, тонкий прогресс,
 * одна строка-подсказка и кнопка раскрытия детальной панели.
 * Высота минимальна, камера остаётся видимой.
 */
@Composable
private fun CompactStatusBar(
    modifier: Modifier,
    state: ScanUiState,
    expanded: Boolean,
    onToggleExpand: () -> Unit
) {
    GlassPanel(
        modifier = modifier.fillMaxWidth(),
        cornerRadius = 16.dp,
        contentPadding = 12.dp
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${state.coveragePercent}%",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium
                )
                Text(
                    text = "Фото: ${state.frameCount}",
                    color = Color.White.copy(alpha = 0.85f),
                    style = MaterialTheme.typography.bodySmall
                )
                // Маленький индикатор трекинга точкой.
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(if (state.isTracking) OrbitGreen else OrbitRed)
                )
                Text(
                    text = if (expanded) "Свернуть ▲" else "Детали ▼",
                    color = OrbitGreen,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier.clickable { onToggleExpand() }
                )
            }
            LinearProgressIndicator(
                progress = { state.coveragePercent / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(3.dp)
                    .clip(RoundedCornerShape(2.dp)),
                color = OrbitGreen,
                trackColor = Color.White.copy(alpha = 0.18f)
            )
            // Одна короткая строка-подсказка (главное, что нужно пользователю сейчас).
            Text(
                text = state.hint,
                color = Color.White.copy(alpha = 0.9f),
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2
            )
        }
    }
}

/**
 * Раскрываемая панель с деталями: сетка покрытия + выбор размера объекта.
 * Показывается только когда пользователь нажал "Детали".
 */
@Composable
private fun DetailPanel(
    modifier: Modifier,
    state: ScanUiState,
    onObjectSizeSelected: (ScanObjectSize) -> Unit
) {
    GlassPanel(
        modifier = modifier.fillMaxWidth(),
        strong = true,
        cornerRadius = 16.dp,
        contentPadding = 14.dp
    ) {
        Column(
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Статус-строка с техн. деталями (для отладки/продвинутых).
            Text(
                text = "Tracking: ${if (state.isTracking) "OK" else "нет"} · " +
                    "Depth: ${if (state.hasDepth) "есть" else "нет"} · ${state.qualityText}",
                color = Color.White.copy(alpha = 0.8f),
                style = MaterialTheme.typography.labelSmall
            )
            Text(
                text = "Центр: ${if (state.objectCenter != null) "выбран" else "не выбран"} · " +
                    "Радиус: ${state.objectRadiusMeters} м",
                color = Color.White.copy(alpha = 0.8f),
                style = MaterialTheme.typography.labelSmall
            )

            // Компактная сетка покрытия.
            val map = state.coverageMap
            Text(
                text = "Покрытие ${map.azimuthSectors}×${map.elevationSectors}",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium
            )
            repeat(map.elevationSectors) { elevation ->
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                    repeat(map.azimuthSectors) { azimuth ->
                        val sector = map.sectors.first {
                            it.azimuthIndex == azimuth && it.elevationIndex == elevation
                        }
                        val color = when (sector.state) {
                            SectorState.NotScanned -> OrbitRed
                            SectorState.Weak -> OrbitYellow
                            SectorState.Good -> OrbitGreen
                        }
                        val alpha = if (sector.id == state.currentSectorId) 1f else 0.5f
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(color.copy(alpha = alpha))
                        )
                    }
                }
            }

            // Выбор размера объекта — только до начала сканирования.
            if (state.phase == ScanPhase.SelectObject || state.phase == ScanPhase.Ready) {
                Text(
                    text = "Размер объекта",
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CompactSizeButton(ScanObjectSize.Small, state.selectedObjectSize, onObjectSizeSelected, Modifier.weight(1f))
                    CompactSizeButton(ScanObjectSize.Medium, state.selectedObjectSize, onObjectSizeSelected, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CompactSizeButton(ScanObjectSize.Large, state.selectedObjectSize, onObjectSizeSelected, Modifier.weight(1f))
                    CompactSizeButton(ScanObjectSize.Car, state.selectedObjectSize, onObjectSizeSelected, Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun CompactSizeButton(
    size: ScanObjectSize,
    selected: ScanObjectSize,
    onClick: (ScanObjectSize) -> Unit,
    modifier: Modifier = Modifier
) {
    val isSelected = selected == size
    if (isSelected) {
        Button(onClick = { onClick(size) }, modifier = modifier) {
            Text("${size.title} ${size.radiusMeters}м", style = MaterialTheme.typography.labelSmall)
        }
    } else {
        OutlinedButton(onClick = { onClick(size) }, modifier = modifier) {
            Text("${size.title} ${size.radiusMeters}м", style = MaterialTheme.typography.labelSmall)
        }
    }
}

/**
 * Компактные нижние кнопки. Главная кнопка действия — крупная по центру,
 * Назад/Предпросмотр — мелкими по бокам.
 */
@Composable
private fun CompactBottomControls(
    modifier: Modifier,
    state: ScanUiState,
    onSelectObject: () -> Unit,
    onStart: () -> Unit,
    onSimulateFrame: () -> Unit,
    onFinish: () -> Unit,
    onPreview: () -> Unit,
    onReset: () -> Unit,
    onBack: () -> Unit
) {
    val isAr = state.engineMode is ScanEngineMode.Ar

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Главное действие по фазе — крупной кнопкой.
        when (state.phase) {
            ScanPhase.SelectObject -> {
                if (!isAr) {
                    PrimaryActionButton("Выбрать объект", onSelectObject)
                }
                // В AR-режиме объект выбирается тапом по камере — отдельная кнопка не нужна.
            }
            ScanPhase.Ready -> PrimaryActionButton("Начать сканирование", onStart)
            ScanPhase.Scanning -> {
                if (isAr) {
                    PrimaryActionButton("Завершить", onFinish)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PrimaryActionButton("+ Кадр", onSimulateFrame, Modifier.weight(1f))
                        SecondaryActionButton("Завершить", onFinish, Modifier.weight(1f))
                    }
                }
            }
            ScanPhase.Finished -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryActionButton("Открыть", onPreview, Modifier.weight(1f))
                SecondaryActionButton("Сброс", onReset, Modifier.weight(1f))
            }
        }

        // Вспомогательная строка: Назад + Предпросмотр — мелко.
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            SecondaryActionButton("Назад", onBack, Modifier.weight(1f))
            if (state.phase != ScanPhase.Finished) {
                SecondaryActionButton("Предпросмотр", onPreview, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun PrimaryActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier.fillMaxWidth()
) {
    Button(onClick = onClick, modifier = modifier) {
        Text(text)
    }
}

@Composable
private fun SecondaryActionButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlassPanel(
        modifier = modifier,
        cornerRadius = 12.dp,
        contentPadding = 0.dp
    ) {
        OutlinedButton(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            border = null,
            colors = androidx.compose.material3.ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
        ) {
            Text(text, style = MaterialTheme.typography.labelLarge)
        }
    }
}
