package com.karas.orbitscan.ui.scan

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.karas.orbitscan.domain.model.SectorState
import com.karas.orbitscan.ui.theme.OrbitGreen
import com.karas.orbitscan.ui.theme.OrbitRed
import com.karas.orbitscan.ui.theme.OrbitYellow

@Composable
fun ScanScreen(
    onBackClick: () -> Unit,
    onPreviewClick: () -> Unit,
    viewModel: ScanViewModel = viewModel()
) {
    val state = viewModel.uiState

    Scaffold { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF071018))
        ) {
            FakeCameraSurface(
                modifier = Modifier.fillMaxSize(),
                state = state
            )

            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TopScanPanel(state = state)
                CoverageGrid(state = state)
            }

            BottomScanControls(
                modifier = Modifier.align(Alignment.BottomCenter),
                state = state,
                onSelectObject = viewModel::selectObjectStub,
                onStart = viewModel::startScan,
                onSimulateFrame = viewModel::simulateUsefulFrame,
                onFinish = viewModel::finishScan,
                onPreview = onPreviewClick,
                onReset = viewModel::reset,
                onBack = onBackClick
            )
        }
    }
}

@Composable
private fun FakeCameraSurface(
    modifier: Modifier,
    state: ScanUiState
) {
    Box(modifier = modifier) {
        Text(
            text = "AR Camera Preview\nЭтап 2: здесь будет ARCore Session",
            color = Color.White.copy(alpha = 0.55f),
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.align(Alignment.Center)
        )
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .size(180.dp)
                .clip(RoundedCornerShape(100.dp))
                .background(Color.White.copy(alpha = 0.06f))
        )
        Text(
            text = when (state.phase) {
                ScanPhase.SelectObject -> "тап по объекту"
                ScanPhase.Ready -> "объект выбран"
                ScanPhase.Scanning -> "сканирование"
                ScanPhase.Finished -> "завершено"
            },
            color = Color.White,
            modifier = Modifier.align(Alignment.Center)
        )
    }
}

@Composable
private fun TopScanPanel(state: ScanUiState) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Покрытие: ${state.coveragePercent}%", fontWeight = FontWeight.Bold)
                Text("Фото: ${state.frameCount}")
            }
            LinearProgressIndicator(
                progress = { state.coveragePercent / 100f },
                modifier = Modifier.fillMaxWidth()
            )
            Text(state.hint, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = "Tracking: ${if (state.isTracking) "OK" else "нет"} · Depth: ${if (state.hasDepth) "есть" else "нет"} · ${state.qualityText}",
                style = MaterialTheme.typography.labelMedium
            )
        }
    }
}

@Composable
private fun CoverageGrid(state: ScanUiState) {
    val map = state.coverageMap
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Сетка покрытия: ${map.azimuthSectors} × ${map.elevationSectors}")
            repeat(map.elevationSectors) { elevation ->
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    repeat(map.azimuthSectors) { azimuth ->
                        val sector = map.sectors.first { it.azimuthIndex == azimuth && it.elevationIndex == elevation }
                        val color = when (sector.state) {
                            SectorState.NotScanned -> OrbitRed
                            SectorState.Weak -> OrbitYellow
                            SectorState.Good -> OrbitGreen
                        }
                        val borderAlpha = if (sector.id == state.currentSectorId) 1f else 0.55f
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(color.copy(alpha = borderAlpha))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomScanControls(
    modifier: Modifier,
    state: ScanUiState,
    onSelectObject: () -> Unit,
    onStart: () -> Unit,
    onSimulateFrame: () -> Unit,
    onFinish: () -> Unit,
    onPreview: () -> Unit,
    onReset: () -> Unit,
    onBack: () -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Назад") }
                OutlinedButton(onClick = onPreview, modifier = Modifier.weight(1f)) { Text("Предпросмотр") }
            }

            when (state.phase) {
                ScanPhase.SelectObject -> Button(onClick = onSelectObject, modifier = Modifier.fillMaxWidth()) {
                    Text("Выбрать объект")
                }
                ScanPhase.Ready -> Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                    Text("Начать")
                }
                ScanPhase.Scanning -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onSimulateFrame, modifier = Modifier.weight(1f)) { Text("+ Кадр") }
                    OutlinedButton(onClick = onFinish, modifier = Modifier.weight(1f)) { Text("Завершить") }
                }
                ScanPhase.Finished -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onPreview, modifier = Modifier.weight(1f)) { Text("Открыть") }
                    OutlinedButton(onClick = onReset, modifier = Modifier.weight(1f)) { Text("Сброс") }
                }
            }
        }
    }
}
