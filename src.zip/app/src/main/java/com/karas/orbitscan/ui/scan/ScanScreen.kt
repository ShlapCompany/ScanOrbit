package com.karas.orbitscan.ui.scan

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.karas.orbitscan.ar.ArInitResult
import com.karas.orbitscan.ar.RealArSessionManager
import com.karas.orbitscan.ar.RealCameraPoseTracker
import com.karas.orbitscan.domain.model.ScanObjectSize
import com.karas.orbitscan.domain.model.SectorState
import com.karas.orbitscan.domain.model.Vector3
import com.karas.orbitscan.ui.theme.OrbitGreen
import com.karas.orbitscan.ui.theme.OrbitRed
import com.karas.orbitscan.ui.theme.OrbitYellow

/**
 * Этап 3: экран сканирования с выбором центра объекта.
 *
 * Поток:
 *  1. Проверяем CAMERA и запускаем ARCore Session.
 *  2. Пользователь тапает по объекту/поверхности в AR-камере.
 *  3. ArRenderer делает Frame.hitTest(x, y) и возвращает objectCenter.
 *  4. Пользователь выбирает примерный размер объекта.
 *  5. После «Начать» покрытие считается относительно выбранного objectCenter.
 *
 * Если ARCore недоступен, остаётся fallback-режим: условный центр + ручная кнопка «+ Кадр».
 */
@Composable
fun ScanScreen(
    onBackClick: () -> Unit,
    onPreviewClick: () -> Unit,
    viewModel: ScanViewModel = viewModel()
) {
    val state = viewModel.uiState
    val context = LocalContext.current
    val activity = context as? Activity

    // Один экземпляр менеджера сессии и трекера на время жизни экрана.
    val sessionManager = remember { RealArSessionManager(context.applicationContext) }
    val poseTracker = remember { RealCameraPoseTracker() }

    // Этап 5: файловое хранилище + координатор захвата кадров.
    val storage = remember { com.karas.orbitscan.storage.FileStorageManager(context.applicationContext) }
    val captureCoordinator = remember { com.karas.orbitscan.storage.ScanFrameCaptureCoordinator(storage) }
    androidx.compose.runtime.LaunchedEffect(captureCoordinator) {
        viewModel.attachCaptureCoordinator(captureCoordinator)
    }
    DisposableEffect(Unit) {
        onDispose { captureCoordinator.shutdown() }
    }

    var hasCameraPermission by remember { mutableStateOf(CameraPermission.isGranted(context)) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            viewModel.setEngineMode(ScanEngineMode.Fallback("Нет разрешения на камеру"))
        } else if (activity != null) {
            tryInitAr(sessionManager, viewModel, activity)
        }
    }

    // Запрос разрешения / инициализация ARCore при первом показе экрана.
    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(CameraPermission.PERMISSION)
        } else if (activity != null) {
            tryInitAr(sessionManager, viewModel, activity)
        } else {
            viewModel.setEngineMode(ScanEngineMode.Fallback("Нет доступа к Activity"))
        }
    }

    // resume/pause/close ARCore-сессии вместе с экраном.
    DisposableEffect(state.engineMode) {
        if (state.engineMode is ScanEngineMode.Ar) {
            runCatching { sessionManager.resume() }
        }
        onDispose {
            runCatching { sessionManager.pause() }
        }
    }
    DisposableEffect(Unit) {
        onDispose { runCatching { sessionManager.close() } }
    }

    Scaffold { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(Color(0xFF071018))
        ) {
            when (val mode = state.engineMode) {
                is ScanEngineMode.Ar -> {
                    ArCameraView(
                        modifier = Modifier.fillMaxSize(),
                        sessionProvider = { sessionManager.session },
                        poseTracker = poseTracker,
                        onTrackingState = { tracking ->
                            // Сообщаем ViewModel о потере/восстановлении трекинга
                            // (onPoseUpdated приходит только при tracking=true).
                            if (!tracking) {
                                viewModel.onArPose(
                                    cameraPosition = Vector3.Zero,
                                    cameraSpeed = 0f,
                                    trackingOk = false
                                )
                            }
                        },
                        onPoseUpdated = {
                            val pose = poseTracker.currentPoseOrNull()
                            val tracking = pose != null
                            val position = pose?.position ?: Vector3.Zero
                            viewModel.onArPose(
                                cameraPosition = position,
                                cameraSpeed = poseTracker.cameraSpeedMetersPerSecond(),
                                trackingOk = tracking
                            )
                        },
                        onObjectCenterSelected = viewModel::selectObjectFromArHit,
                        onObjectSelectionFailed = viewModel::onObjectHitTestFailed,
                        onArFrameForCapture = { frame ->
                            // GL-поток: решение о захвате + сам захват внутри ViewModel.
                            val pose = poseTracker.currentPoseOrNull()
                            viewModel.onArFrameForCapture(
                                frame = frame,
                                cameraPosition = pose?.position ?: Vector3.Zero,
                                cameraSpeed = poseTracker.cameraSpeedMetersPerSecond()
                            )
                        }
                    )
                }
                is ScanEngineMode.Fallback -> FallbackSurface(reason = mode.reason)
                ScanEngineMode.Initializing -> InitializingSurface()
            }

            ObjectCenterMarker(state = state)

            Column(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TopScanPanel(
                    state = state,
                    onObjectSizeSelected = viewModel::setObjectSize
                )
                CoverageGrid(state = state)
            }

            BottomScanControls(
                modifier = Modifier.align(Alignment.BottomCenter),
                state = state,
                onSelectObject = viewModel::selectObjectStub,
                onStart = viewModel::startScan,
                onSimulateFrame = viewModel::simulateUsefulFrame,
                onFinish = viewModel::finishScan,
                onPreview = onPreviewClick,
                onReset = viewModel::reset,
                onBack = onBackClick
            )
        }
    }
}

/** Запускает инициализацию ARCore и проставляет engineMode по результату. */
private fun tryInitAr(
    sessionManager: RealArSessionManager,
    viewModel: ScanViewModel,
    activity: Activity
) {
    when (val result = sessionManager.createSessionIfNeeded(activity)) {
        ArInitResult.Ready -> {
            runCatching { sessionManager.resume() }
            viewModel.setEngineMode(ScanEngineMode.Ar)
        }
        ArInitResult.RequiresInstall -> {
            // Сервисы AR устанавливаются/обновляются — останемся в Initializing,
            // следующий заход на экран повторит попытку.
            viewModel.setEngineMode(ScanEngineMode.Initializing)
        }
        ArInitResult.Unsupported -> {
            viewModel.setEngineMode(ScanEngineMode.Fallback("Устройство не поддерживает ARCore"))
        }
        is ArInitResult.Error -> {
            viewModel.setEngineMode(ScanEngineMode.Fallback(result.message))
        }
    }
}

@Composable
private fun InitializingSurface() {
    Box(modifier = Modifier.fillMaxSize()) {
        Text(
            text = "Инициализация ARCore…",
            color = Color.White.copy(alpha = 0.7f),
            style = MaterialTheme.typography.titleMedium,
            modifier = Modifier.align(Alignment.Center)
        )
    }
}

@Composable
private fun FallbackSurface(reason: String) {
    Box(modifier = Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Режим фотосканирования (без AR)",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium
            )
            Text(
                text = reason,
                color = Color.White.copy(alpha = 0.6f),
                style = MaterialTheme.typography.bodySmall
            )
            Text(
                text = "Используйте «Выбрать объект», затем «+ Кадр», чтобы заполнять зоны покрытия.",
                color = Color.White.copy(alpha = 0.6f),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

@Composable
private fun ObjectCenterMarker(state: ScanUiState) {
    val point = state.objectCenterScreenPosition ?: return
    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val markerSize = 34.dp
        val x = maxWidth * point.xFraction - markerSize / 2f
        val y = maxHeight * point.yFraction - markerSize / 2f
        Box(
            modifier = Modifier
                .offset(x = x, y = y)
                .size(markerSize)
                .clip(CircleShape)
                .background(OrbitGreen.copy(alpha = 0.22f))
                .border(width = 2.dp, color = OrbitGreen, shape = CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(OrbitGreen)
            )
        }
    }
}

@Composable
private fun TopScanPanel(
    state: ScanUiState,
    onObjectSizeSelected: (ScanObjectSize) -> Unit
) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Покрытие: ${state.coveragePercent}%", fontWeight = FontWeight.Bold)
                Text("Фото: ${state.frameCount}")
            }
            LinearProgressIndicator(
                progress = { state.coveragePercent / 100f },
                modifier = Modifier.fillMaxWidth()
            )
            Text(state.hint, style = MaterialTheme.typography.bodyMedium)
            Text(
                text = "Tracking: ${if (state.isTracking) "OK" else "нет"} · Depth: ${if (state.hasDepth) "есть" else "нет"} · ${state.qualityText}",
                style = MaterialTheme.typography.labelMedium
            )
            Text(
                text = "Центр: ${if (state.objectCenter != null) "выбран" else "не выбран"} · Радиус: ${state.objectRadiusMeters} м",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
            )
            ObjectSizeSelector(state = state, onObjectSizeSelected = onObjectSizeSelected)
        }
    }
}

@Composable
private fun ObjectSizeSelector(
    state: ScanUiState,
    onObjectSizeSelected: (ScanObjectSize) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Размер объекта", style = MaterialTheme.typography.labelMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SizeButton(
                size = ScanObjectSize.Small,
                selected = state.selectedObjectSize == ScanObjectSize.Small,
                onClick = onObjectSizeSelected,
                modifier = Modifier.weight(1f)
            )
            SizeButton(
                size = ScanObjectSize.Medium,
                selected = state.selectedObjectSize == ScanObjectSize.Medium,
                onClick = onObjectSizeSelected,
                modifier = Modifier.weight(1f)
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            SizeButton(
                size = ScanObjectSize.Large,
                selected = state.selectedObjectSize == ScanObjectSize.Large,
                onClick = onObjectSizeSelected,
                modifier = Modifier.weight(1f)
            )
            SizeButton(
                size = ScanObjectSize.Car,
                selected = state.selectedObjectSize == ScanObjectSize.Car,
                onClick = onObjectSizeSelected,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SizeButton(
    size: ScanObjectSize,
    selected: Boolean,
    onClick: (ScanObjectSize) -> Unit,
    modifier: Modifier = Modifier
) {
    if (selected) {
        Button(onClick = { onClick(size) }, modifier = modifier) {
            Text("${size.title} · ${size.radiusMeters} м")
        }
    } else {
        OutlinedButton(onClick = { onClick(size) }, modifier = modifier) {
            Text("${size.title} · ${size.radiusMeters} м")
        }
    }
}

@Composable
private fun CoverageGrid(state: ScanUiState) {
    val map = state.coverageMap
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f))) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text("Сетка покрытия: ${map.azimuthSectors} × ${map.elevationSectors}")
            repeat(map.elevationSectors) { elevation ->
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    repeat(map.azimuthSectors) { azimuth ->
                        val sector = map.sectors.first { it.azimuthIndex == azimuth && it.elevationIndex == elevation }
                        val color = when (sector.state) {
                            SectorState.NotScanned -> OrbitRed
                            SectorState.Weak -> OrbitYellow
                            SectorState.Good -> OrbitGreen
                        }
                        val borderAlpha = if (sector.id == state.currentSectorId) 1f else 0.55f
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(color.copy(alpha = borderAlpha))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BottomScanControls(
    modifier: Modifier,
    state: ScanUiState,
    onSelectObject: () -> Unit,
    onStart: () -> Unit,
    onSimulateFrame: () -> Unit,
    onFinish: () -> Unit,
    onPreview: () -> Unit,
    onReset: () -> Unit,
    onBack: () -> Unit
) {
    // В AR-режиме скрываем кнопку "+ Кадр": сектор обновляется движением телефона.
    val isAr = state.engineMode is ScanEngineMode.Ar

    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f))
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onBack, modifier = Modifier.weight(1f)) { Text("Назад") }
                OutlinedButton(onClick = onPreview, modifier = Modifier.weight(1f)) { Text("Предпросмотр") }
            }

            when (state.phase) {
                ScanPhase.SelectObject -> {
                    if (isAr) {
                        Text(
                            text = "Тапните по центру объекта на изображении камеры.",
                            style = MaterialTheme.typography.bodyMedium
                        )
                        OutlinedButton(onClick = onSelectObject, modifier = Modifier.fillMaxWidth()) {
                            Text("Временно выбрать условный центр")
                        }
                    } else {
                        Button(onClick = onSelectObject, modifier = Modifier.fillMaxWidth()) {
                            Text("Выбрать объект")
                        }
                    }
                }
                ScanPhase.Ready -> Button(onClick = onStart, modifier = Modifier.fillMaxWidth()) {
                    Text("Начать")
                }
                ScanPhase.Scanning -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (!isAr) {
                        Button(onClick = onSimulateFrame, modifier = Modifier.weight(1f)) { Text("+ Кадр") }
                    }
                    OutlinedButton(onClick = onFinish, modifier = Modifier.weight(1f)) { Text("Завершить") }
                }
                ScanPhase.Finished -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onPreview, modifier = Modifier.weight(1f)) { Text("Открыть") }
                    OutlinedButton(onClick = onReset, modifier = Modifier.weight(1f)) { Text("Сброс") }
                }
            }
        }
    }
}
