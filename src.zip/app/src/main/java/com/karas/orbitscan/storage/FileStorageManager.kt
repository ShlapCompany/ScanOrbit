package com.karas.orbitscan.storage

import android.content.Context
import java.io.File

/**
 * Этап 5: управляет файловой структурой одного скан-проекта на диске.
 *
 * Структура (по разделу 9 ТЗ):
 *   <filesDir>/scans/<projectId>/
 *       scan_session.json
 *       frames/frame_0001.jpg ...
 *       preview/thumbnail.jpg
 *       logs/scan_log.txt
 *
 * Используем context.filesDir (внутреннее приватное хранилище) — не требует
 * разрешений и соответствует разделу 20 ТЗ (данные хранятся локально и приватно).
 */
class FileStorageManager(private val appContext: Context) {

    private val scansRoot: File
        get() = File(appContext.filesDir, "scans").apply { mkdirs() }

    fun projectDir(projectId: String): File =
        File(scansRoot, projectId).apply { mkdirs() }

    fun framesDir(projectId: String): File =
        File(projectDir(projectId), "frames").apply { mkdirs() }

    fun previewDir(projectId: String): File =
        File(projectDir(projectId), "preview").apply { mkdirs() }

    fun depthDir(projectId: String): File =
        File(projectDir(projectId), "depth").apply { mkdirs() }

    fun outputDir(projectId: String): File =
        File(projectDir(projectId), "output").apply { mkdirs() }

    fun logsDir(projectId: String): File =
        File(projectDir(projectId), "logs").apply { mkdirs() }

    fun sessionJsonFile(projectId: String): File =
        File(projectDir(projectId), "scan_session.json")

    /** Имя файла кадра вида frame_0001.jpg (1-индексация, 4 знака). */
    fun frameFile(projectId: String, frameIndex: Int): File {
        val name = "frame_%04d.jpg".format(frameIndex)
        return File(framesDir(projectId), name)
    }

    fun thumbnailFile(projectId: String): File =
        File(previewDir(projectId), "thumbnail.jpg")

    fun depthFile(projectId: String, frameIndex: Int): File =
        File(depthDir(projectId), "depth_%04d.png".format(frameIndex))

    fun confidenceFile(projectId: String, frameIndex: Int): File =
        File(depthDir(projectId), "confidence_%04d.png".format(frameIndex))

    fun pointCloudFile(projectId: String, frameIndex: Int): File =
        File(previewDir(projectId), "points_%04d.ply".format(frameIndex))

    fun previewPointCloudFile(projectId: String): File =
        File(previewDir(projectId), "preview_points.ply")

    fun modelGlbFile(projectId: String): File =
        File(outputDir(projectId), "model.glb")

    fun localPreviewGlbFile(projectId: String): File =
        File(outputDir(projectId), "local_depth_preview.glb")

    fun logFile(projectId: String): File =
        File(logsDir(projectId), "scan_log.txt")

    /** Полностью удаляет проект с диска (раздел 20 ТЗ — возможность удалить данные). */
    fun deleteProject(projectId: String): Boolean =
        projectDir(projectId).deleteRecursively()

    fun listProjectIds(): List<String> =
        scansRoot.listFiles()?.filter { it.isDirectory }?.map { it.name } ?: emptyList()
}
