package com.karas.orbitscan.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors: ColorScheme = darkColorScheme(
    primary = OrbitGreen,
    secondary = OrbitYellow,
    tertiary = OrbitRed,
    background = OrbitDark,
    surface = OrbitSurface,
    onPrimary = Color.Black,
    onSecondary = Color.Black,
    onTertiary = Color.White,
    onBackground = Color.White,
    onSurface = Color.White
)

private val AppTypography = Typography()

private val LightColors: ColorScheme = lightColorScheme(
    primary = Color(0xFF00876C),
    secondary = Color(0xFF8A6500),
    tertiary = Color(0xFFBA1A1A),
    background = Color(0xFFF7FAFA),
    surface = Color.White,
    onPrimary = Color.White,
    onSecondary = Color.White,
    onTertiary = Color.White,
    onBackground = Color(0xFF101820),
    onSurface = Color(0xFF101820)
)

@Composable
fun OrbitScanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = AppTypography,
        content = content
    )
}
