package com.karas.orbitscan.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

/**
 * Этап 5.2 — iOS-вдохновлённая тема: глубокий тёмный фон, стеклянные поверхности,
 * крупные мягкие скругления, типографика Inter.
 */
private val DarkColors: ColorScheme = darkColorScheme(
    primary = OrbitGreen,
    onPrimary = Color.Black,
    secondary = OrbitBlue,
    onSecondary = Color.White,
    tertiary = OrbitYellow,
    onTertiary = Color.Black,
    error = OrbitRed,
    background = OrbitDark,
    onBackground = Color.White,
    surface = OrbitSurface,
    onSurface = Color.White,
    surfaceVariant = OrbitSurfaceElevated,
    onSurfaceVariant = Color(0xFFB8B8BE),
    outline = OrbitHairline
)

private val LightColors: ColorScheme = lightColorScheme(
    primary = Color(0xFF14B85C),
    onPrimary = Color.White,
    secondary = OrbitBlue,
    onSecondary = Color.White,
    tertiary = Color(0xFFB58A00),
    error = Color(0xFFD93025),
    background = OrbitLightBg,
    onBackground = OrbitLightText,
    surface = OrbitLightSurface,
    onSurface = OrbitLightText,
    surfaceVariant = Color(0xFFE5E5EA),
    onSurfaceVariant = Color(0xFF6C6C70),
    outline = Color(0x1F000000)
)

// iOS-стиль: крупные «continuous»-подобные скругления.
private val OrbitShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(20.dp),
    extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun OrbitScanTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = OrbitTypography,
        shapes = OrbitShapes,
        content = content
    )
}
