package com.karas.orbitscan.domain.model

/**
 * Этап 3: примерный размер объекта, который задаёт радиус виртуальной сферы покрытия.
 *
 * В MVP пользователь выбирает размер вручную после выбора центра объекта. Позже это
 * можно заменить оценкой bounding box по нескольким tap-точкам или depth-данным.
 */
enum class ScanObjectSize(
    val title: String,
    val radiusMeters: Float
) {
    Small(title = "Маленький", radiusMeters = 0.5f),
    Medium(title = "Средний", radiusMeters = 1.5f),
    Large(title = "Большой", radiusMeters = 3.0f),
    Car(title = "Авто", radiusMeters = 4.5f)
}
