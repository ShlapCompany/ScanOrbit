package com.karas.orbitscan.ui.preview

import android.graphics.BitmapFactory
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.karas.orbitscan.reconstruction.GlbFileInspector
import com.karas.orbitscan.domain.model.ScanStatus
import com.karas.orbitscan.reconstruction.LocalPointCloudGlbBuilder
import com.karas.orbitscan.reconstruction.MockReconstructionApi
import com.karas.orbitscan.reconstruction.ReconstructionStatus
import com.karas.orbitscan.storage.FileStorageManager
import com.karas.orbitscan.storage.ProjectExportManager
import com.karas.orbitscan.storage.ScanProjectRepository
import com.karas.orbitscan.storage.ScanSessionWriter
import com.karas.orbitscan.ui.theme.OrbitGreen
import com.karas.orbitscan.ui.theme.OrbitRed
import com.karas.orbitscan.ui.theme.OrbitYellow
import com.karas.orbitscan.ui.viewer.GlbModelViewer
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun PreviewScreen(
    projectId: String?,
    onBackClick: () -> Unit,
    onContinueScanClick: () -> Unit,
    onOpenModelClick: (String) -> Unit
) {
    val context = LocalContext.current
    val storage = remember { FileStorageManager(context.applicationContext) }
    val repository = remember { ScanProjectRepository(storage) }
    val reconstructionApi = remember { MockReconstructionApi(storage) }
    val exportManager = remember { ProjectExportManager(context.applicationContext, storage) }
    val scope = rememberCoroutineScope()

    var details by remember(projectId) { mutableStateOf<ScanSessionWriter.ProjectDetails?>(null) }
    var processingStatus by remember { mutableStateOf<ReconstructionStatus?>(null) }
    var isProcessing by remember { mutableStateOf(false) }
    var exportMessage by remember { mutableStateOf<String?>(null) }
    var localBuildMessage by remember { mutableStateOf<String?>(null) }

    fun showExportMessage(message: String) {
        exportMessage = message
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    }

    val modelExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("model/gltf-binary")
    ) { uri ->
        val pid = projectId
        if (uri != null && pid != null) {
            scope.launch {
                val ok = exportManager.copyModelGlbToUri(pid, uri)
                showExportMessage(if (ok) "GLB сохранён" else "Не удалось сохранить GLB")
            }
        }
    }

    val modelObjExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        val pid = projectId
        if (uri != null && pid != null) {
            scope.launch {
                val ok = exportManager.copyModelObjToUri(pid, uri)
                showExportMessage(if (ok) "OBJ сохранён" else "Сначала соберите модель (нет OBJ)")
            }
        }
    }

    val projectZipExportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/zip")
    ) { uri ->
        val pid = projectId
        if (uri != null && pid != null) {
            scope.launch {
                val ok = exportManager.exportProjectZipToUri(pid, uri)
                showExportMessage(if (ok) "ZIP проекта сохранён" else "Не удалось сохранить ZIP")
            }
        }
    }

    fun reload() {
        details = projectId?.let { repository.loadProjectDetails(it) }
    }

    LaunchedEffect(projectId) { reload() }

    Scaffold { padding ->
        when {
            projectId == null -> EmptyPreview(onBackClick)
            details == null -> Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp)
            ) {
                LoadingOrMissingProject(onBackClick = onBackClick)
            }
            else -> {
                val d = details!!
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item { PreviewHeader(details = d) }

                    item {
                        if (!d.summary.resultModelPath.isNullOrBlank()) {
                            GlbResultPanel(
                                modelPath = d.summary.resultModelPath,
                                onOpenModelClick = onOpenModelClick
                            )
                        } else {
                            ScanPreviewPanel(details = d)
                        }
                    }

                    item { CoverageCard(details = d) }

                    item {
                        LocalReconstructionCard(
                            details = d,
                            localBuildMessage = localBuildMessage,
                            onBuildLocalDepthModelClick = {
                                val pid = projectId
                                if (pid != null) {
                                    scope.launch {
                                        val output = storage.localPreviewGlbFile(pid)
                                        val result = LocalPointCloudGlbBuilder.buildDepthPreviewModel(d, output)
                                        // Сразу собираем и OBJ-версию (тот же point cloud).
                                        val objResult = LocalPointCloudGlbBuilder.buildObj(
                                            d, storage.modelObjFile(pid)
                                        )
                                        localBuildMessage = result.message +
                                            (if (objResult.ok) " · OBJ готов" else "")
                                        if (result.ok && result.outputPath != null) {
                                            ScanSessionWriter().updateProcessingStatus(
                                                file = storage.sessionJsonFile(pid),
                                                status = ScanStatus.ModelReady,
                                                processingStage = "LOCAL_DEPTH_PREVIEW",
                                                processingProgress = 100,
                                                resultModelPath = result.outputPath
                                            )
                                            reload()
                                        }
                                    }
                                }
                            }
                        )
                    }

                    item {
                        ProcessingCard(
                            details = d,
                            isProcessing = isProcessing,
                            processingStatus = processingStatus,
                            onProcessClick = {
                                val pid = projectId
                                if (pid != null && !isProcessing) {
                                    isProcessing = true
                                    scope.launch {
                                        reconstructionApi.processProject(pid) { status ->
                                            processingStatus = status
                                            reload()
                                        }
                                        isProcessing = false
                                        reload()
                                    }
                                }
                            }
                        )
                    }

                    item {
                        ExportCard(
                            details = d,
                            exportMessage = exportMessage,
                            onExportModelClick = {
                                modelExportLauncher.launch("orbitscan_${d.summary.id.take(8)}.glb")
                            },
                            onExportObjClick = {
                                modelObjExportLauncher.launch("orbitscan_${d.summary.id.take(8)}.obj")
                            },
                            onExportProjectZipClick = {
                                projectZipExportLauncher.launch("orbitscan_${d.summary.id.take(8)}.zip")
                            }
                        )
                    }

                    item {
                        ActionButtons(
                            hasModel = !d.summary.resultModelPath.isNullOrBlank(),
                            modelPath = d.summary.resultModelPath,
                            onOpenModelClick = onOpenModelClick,
                            onBackClick = onBackClick,
                            onContinueScanClick = onContinueScanClick
                        )
                    }

                    item {
                        Text(
                            text = "Кадры (${d.frames.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    items(d.frames.take(80), key = { it.id }) { frame ->
                        FrameRow(frame)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyPreview(onBackClick: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Нет выбранного проекта", style = MaterialTheme.typography.titleLarge)
            Button(onClick = onBackClick) { Text("Домой") }
        }
    }
}

@Composable
private fun LoadingOrMissingProject(onBackClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Проект ещё не найден", fontWeight = FontWeight.SemiBold)
            Text("Если вы только что завершили скан, подождите секунду. scan_session.json мог ещё записываться.")
            Button(onClick = onBackClick) { Text("Домой") }
        }
    }
}

@Composable
private fun PreviewHeader(details: ScanSessionWriter.ProjectDetails) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Предпросмотр скана", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(details.summary.name, style = MaterialTheme.typography.titleMedium)
        Text(
            "${details.summary.status} · ${details.summary.coveragePercent}% · ${details.summary.frameCount} фото",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun ScanPreviewPanel(details: ScanSessionWriter.ProjectDetails) {
    val thumbnailPath = details.summary.thumbnailPath
    val thumbnail = remember(thumbnailPath) {
        thumbnailPath?.let { path -> runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull() }
    }
    val depthFrames = details.frames.count { it.hasDepth }
    val pointCount = details.frames.sumOf { it.depthPointCount }
    val mergedCloud = details.summary.previewPointCloudPath

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF101820)),
        contentAlignment = Alignment.Center
    ) {
        if (thumbnail != null) {
            Image(
                bitmap = thumbnail,
                contentDescription = "Thumbnail",
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(Color.Black.copy(alpha = 0.45f))
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Черновой preview", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Камеры: ${details.frames.size}", color = Color.White.copy(alpha = 0.85f))
            Text("Depth-кадры: $depthFrames", color = Color.White.copy(alpha = 0.85f))
            Text("Point cloud точек: $pointCount", color = Color.White.copy(alpha = 0.85f))
            Text("PLY: ${if (mergedCloud != null) File(mergedCloud).name else "нет"}", color = Color.White.copy(alpha = 0.75f))
            Text("Готовая GLB-модель появится после обработки", color = Color.White.copy(alpha = 0.7f))
        }
    }
}

@Composable
private fun GlbResultPanel(
    modelPath: String?,
    onOpenModelClick: (String) -> Unit
) {
    val info = remember(modelPath) { GlbFileInspector.inspect(modelPath) }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Готовая GLB-модель", fontWeight = FontWeight.Bold)
            if (!modelPath.isNullOrBlank()) {
                GlbModelViewer(
                    modelPath = modelPath,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(360.dp)
                        .clip(RoundedCornerShape(22.dp))
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(260.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(Color(0xFF0F1823)),
                    contentAlignment = Alignment.Center
                ) {
                    Text("Файл модели ещё не готов", color = Color.White)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                val path = modelPath
                if (!path.isNullOrBlank()) {
                    Button(onClick = { onOpenModelClick(path) }, modifier = Modifier.weight(1f)) {
                        Text("Открыть 3D")
                    }
                }
            }
            Text(
                text = if (info?.isValid == true) "GLB 2.0 · ${info.fileLength} байт" else "Файл модели найден, но формат не распознан",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
            if (info?.jsonPreview != null) {
                Text(
                    text = info.jsonPreview.take(180),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}

@Composable
private fun CoverageCard(details: ScanSessionWriter.ProjectDetails) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Карта покрытия", fontWeight = FontWeight.Bold)
            repeat(details.elevationSectors) { elevation ->
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    repeat(details.azimuthSectors) { azimuth ->
                        val id = elevation * details.azimuthSectors + azimuth
                        val state = details.sectors[id] ?: "NOT_SCANNED"
                        val color = when (state) {
                            "GOOD" -> OrbitGreen
                            "WEAK" -> OrbitYellow
                            else -> OrbitRed
                        }
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(color.copy(alpha = 0.82f))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun LocalReconstructionCard(
    details: ScanSessionWriter.ProjectDetails,
    localBuildMessage: String?,
    onBuildLocalDepthModelClick: () -> Unit
) {
    val depthFrames = details.frames.count { it.hasDepth }
    val pointCount = details.frames.sumOf { it.depthPointCount }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Локальная модель на телефоне", fontWeight = FontWeight.Bold)
            Text(
                "На телефоне можно собрать только черновую depth-модель, если устройство реально записало Depth/Raw Depth. Это будет voxel/point-cloud GLB без текстур, не фотограмметрия.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
            Text("Depth-кадры: $depthFrames · depth-точки: $pointCount", style = MaterialTheme.typography.bodySmall)
            Button(
                onClick = onBuildLocalDepthModelClick,
                enabled = pointCount > 20,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Собрать локальный depth GLB")
            }
            if (pointCount <= 20) {
                Text(
                    "В этом скане depth-точек почти нет. Значит, локально форму собрать нечем: экспортируй ZIP и обрабатывай на ПК/сервере.",
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            localBuildMessage?.let {
                Text(it, color = OrbitGreen, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun ProcessingCard(
    details: ScanSessionWriter.ProjectDetails,
    isProcessing: Boolean,
    processingStatus: ReconstructionStatus?,
    onProcessClick: () -> Unit
) {
    val currentProgress = processingStatus?.progress ?: details.processingProgress
    val currentStage = processingStatus?.title ?: details.processingStage

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Обработка", fontWeight = FontWeight.Bold)
            if (!details.summary.resultModelPath.isNullOrBlank()) {
                Text("Модель готова: ${details.summary.resultModelPath}", style = MaterialTheme.typography.bodySmall)
            } else {
                Text(currentStage ?: "Серверная реконструкция ещё не запускалась")
                Text(
                    "Сейчас эта кнопка запускает mock-пайплайн и создаёт тестовый зелёный куб. Это проверка viewer/export, а не модель отсканированного объекта.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall
                )
                if (isProcessing || currentProgress > 0) {
                    LinearProgressIndicator(
                        progress = { currentProgress / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Button(onClick = onProcessClick, enabled = !isProcessing && details.frames.isNotEmpty()) {
                    Text(if (isProcessing) "Обработка…" else "Mock обработка / куб")
                }
                if (details.frames.isEmpty()) {
                    Text("Нет сохранённых кадров. Сначала сделайте скан.", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun ExportCard(
    details: ScanSessionWriter.ProjectDetails,
    exportMessage: String?,
    onExportModelClick: () -> Unit,
    onExportObjClick: () -> Unit,
    onExportProjectZipClick: () -> Unit
) {
    val hasModel = !details.summary.resultModelPath.isNullOrBlank()
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Экспорт", fontWeight = FontWeight.Bold)
            Text(
                "Можно сохранить модель (GLB или OBJ) или весь проект в доступную папку телефона.",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall
            )
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(
                    onClick = onExportProjectZipClick,
                    enabled = details.frames.isNotEmpty(),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("ZIP")
                }
                Button(
                    onClick = onExportModelClick,
                    enabled = hasModel,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("GLB")
                }
                Button(
                    onClick = onExportObjClick,
                    enabled = hasModel,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("OBJ")
                }
            }
            if (!hasModel) {
                Text(
                    "GLB появится после обработки. ZIP уже можно экспортировать: в нём будут кадры и scan_session.json.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.labelSmall
                )
            }
            exportMessage?.let {
                Text(it, color = OrbitGreen, style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun ActionButtons(
    hasModel: Boolean,
    modelPath: String?,
    onOpenModelClick: (String) -> Unit,
    onBackClick: () -> Unit,
    onContinueScanClick: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        val path = modelPath
        if (hasModel && !path.isNullOrBlank()) {
            Button(onClick = { onOpenModelClick(path) }, modifier = Modifier.fillMaxWidth()) {
                Text("Открыть модель на весь экран")
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onBackClick, modifier = Modifier.weight(1f)) { Text("Домой") }
            Button(onClick = onContinueScanClick, modifier = Modifier.weight(1f)) {
                Text(if (hasModel) "Новый скан" else "Доснять")
            }
        }
    }
}

@Composable
private fun FrameRow(frame: ScanSessionWriter.FrameSummary) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Сектор ${frame.sectorId} · Q${frame.qualityScore}/5", fontWeight = FontWeight.SemiBold)
            Text(
                "Свет ${(frame.brightnessScore * 100).toInt()}% · резкость ${(frame.blurScore * 100).toInt()}% · depth ${if (frame.hasDepth) "есть" else "нет"}",
                style = MaterialTheme.typography.bodySmall
            )
            if (frame.pointCloudPath != null) {
                Text("Point cloud: ${frame.depthPointCount} точек", style = MaterialTheme.typography.bodySmall)
            }
            Text(
                text = File(frame.imagePath).name.ifBlank { frame.imagePath },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
