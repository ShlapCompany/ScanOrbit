package com.karas.orbitscan.ui.preview

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

@Composable
fun PreviewScreen(
    onBackClick: () -> Unit,
    onContinueScanClick: () -> Unit
) {
    Scaffold { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Предпросмотр скана", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("MVP-экран: здесь будет point cloud, позиции камер, сфера покрытия и список кадров.")

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Color(0xFF101820)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "3D Preview Placeholder\nPoint Cloud / Camera Poses / GLB Viewer",
                    color = Color.White.copy(alpha = 0.75f)
                )
            }

            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Проблемы скана", fontWeight = FontWeight.Bold)
                    Text("• Модель ещё не обработана сервером")
                    Text("• Depth preview появится после подключения Raw Depth API")
                    Text("• Сейчас экран готов под интеграцию Этапа 7")
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = onBackClick, modifier = Modifier.weight(1f)) { Text("Домой") }
                Button(onClick = onContinueScanClick, modifier = Modifier.weight(1f)) { Text("Доснять") }
            }
        }
    }
}
