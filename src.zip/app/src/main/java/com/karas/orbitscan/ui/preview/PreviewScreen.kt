package com.karas.orbitscan.ui.preview

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.karas.orbitscan.reconstruction.GlbFileInspector
import com.karas.orbitscan.reconstruction.MockReconstructionApi
import com.karas.orbitscan.reconstruction.ReconstructionStatus
import com.karas.orbitscan.storage.FileStorageManager
import com.karas.orbitscan.storage.ScanProjectRepository
import com.karas.orbitscan.storage.ScanSessionWriter
import com.karas.orbitscan.ui.theme.OrbitGreen
import com.karas.orbitscan.ui.theme.OrbitRed
import com.karas.orbitscan.ui.theme.OrbitYellow
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun PreviewScreen(
    projectId: String?,
    onBackClick: () -> Unit,
    onContinueScanClick: () -> Unit
) {
    val context = LocalContext.current
    val storage = remember { FileStorageManager(context.applicationContext) }
    val repository = remember { ScanProjectRepository(storage) }
    val reconstructionApi = remember { MockReconstructionApi(storage) }
    val scope = rememberCoroutineScope()

    var details by remember(projectId) { mutableStateOf<ScanSessionWriter.ProjectDetails?>(null) }
    var processingStatus by remember { mutableStateOf<ReconstructionStatus?>(null) }
    var isProcessing by remember { mutableStateOf(false) }

    fun reload() {
        details = projectId?.let { repository.loadProjectDetails(it) }
    }

    LaunchedEffect(projectId) { reload() }

    Scaffold { padding ->
        when {
            projectId == null -> EmptyPreview(onBackClick)
            details == null -> Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(20.dp)
            ) {
                LoadingOrMissingProject(onBackClick = onBackClick)
            }
            else -> {
                val d = details!!
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(padding)
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item { PreviewHeader(details = d) }

                    item {
                        if (!d.summary.resultModelPath.isNullOrBlank()) {
                            GlbResultPanel(modelPath = d.summary.resultModelPath)
                        } else {
                            ScanPreviewPanel(details = d)
                        }
                    }

                    item { CoverageCard(details = d) }

                    item {
                        ProcessingCard(
                            details = d,
                            isProcessing = isProcessing,
                            processingStatus = processingStatus,
                            onProcessClick = {
                                val pid = projectId
                                if (pid != null && !isProcessing) {
                                    isProcessing = true
                                    scope.launch {
                                        reconstructionApi.processProject(pid) { status ->
                                            processingStatus = status
                                            reload()
                                        }
                                        isProcessing = false
                                        reload()
                                    }
                                }
                            }
                        )
                    }

                    item {
                        ActionButtons(
                            hasModel = !d.summary.resultModelPath.isNullOrBlank(),
                            onBackClick = onBackClick,
                            onContinueScanClick = onContinueScanClick
                        )
                    }

                    item {
                        Text(
                            text = "Кадры (${d.frames.size})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    items(d.frames.take(80), key = { it.id }) { frame ->
                        FrameRow(frame)
                    }
                }
            }
        }
    }
}

@Composable
private fun EmptyPreview(onBackClick: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Нет выбранного проекта", style = MaterialTheme.typography.titleLarge)
            Button(onClick = onBackClick) { Text("Домой") }
        }
    }
}

@Composable
private fun LoadingOrMissingProject(onBackClick: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Проект ещё не найден", fontWeight = FontWeight.SemiBold)
            Text("Если вы только что завершили скан, подождите секунду. scan_session.json мог ещё записываться.")
            Button(onClick = onBackClick) { Text("Домой") }
        }
    }
}

@Composable
private fun PreviewHeader(details: ScanSessionWriter.ProjectDetails) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Предпросмотр скана", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(details.summary.name, style = MaterialTheme.typography.titleMedium)
        Text(
            "${details.summary.status} · ${details.summary.coveragePercent}% · ${details.summary.frameCount} фото",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            style = MaterialTheme.typography.bodyMedium
        )
    }
}

@Composable
private fun ScanPreviewPanel(details: ScanSessionWriter.ProjectDetails) {
    val thumbnailPath = details.summary.thumbnailPath
    val thumbnail = remember(thumbnailPath) {
        thumbnailPath?.let { path -> runCatching { BitmapFactory.decodeFile(path)?.asImageBitmap() }.getOrNull() }
    }
    val depthFrames = details.frames.count { it.hasDepth }
    val pointCount = details.frames.sumOf { it.depthPointCount }
    val mergedCloud = details.summary.previewPointCloudPath

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF101820)),
        contentAlignment = Alignment.Center
    ) {
        if (thumbnail != null) {
            Image(
                bitmap = thumbnail,
                contentDescription = "Thumbnail",
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(Color.Black.copy(alpha = 0.45f))
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Черновой preview", color = Color.White, fontWeight = FontWeight.Bold)
            Text("Камеры: ${details.frames.size}", color = Color.White.copy(alpha = 0.85f))
            Text("Depth-кадры: $depthFrames", color = Color.White.copy(alpha = 0.85f))
            Text("Point cloud точек: $pointCount", color = Color.White.copy(alpha = 0.85f))
            Text("PLY: ${if (mergedCloud != null) File(mergedCloud).name else "нет"}", color = Color.White.copy(alpha = 0.75f))
            Text("Готовая GLB-модель появится после обработки", color = Color.White.copy(alpha = 0.7f))
        }
    }
}

@Composable
private fun GlbResultPanel(modelPath: String?) {
    val info = remember(modelPath) { GlbFileInspector.inspect(modelPath) }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(300.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(Color(0xFF0F1823)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("GLB-модель готова", color = Color.White, fontWeight = FontWeight.Bold)
            Text(
                text = if (info?.isValid == true) "GLB 2.0 · ${info.fileLength} байт" else "Файл модели найден, но формат не распознан",
                color = Color.White.copy(alpha = 0.85f)
            )
            Text(
                text = "Native GLB viewer adapter: подключен inspector. Полный Filament/SceneView-рендер — следующий хвост.",
                color = Color.White.copy(alpha = 0.65f),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 28.dp)
            )
            if (info?.jsonPreview != null) {
                Text(
                    text = info.jsonPreview.take(140),
                    color = Color.White.copy(alpha = 0.55f),
                    style = MaterialTheme.typography.labelSmall,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(horizontal = 28.dp)
                )
            }
        }
    }
}

@Composable
private fun CoverageCard(details: ScanSessionWriter.ProjectDetails) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Карта покрытия", fontWeight = FontWeight.Bold)
            repeat(details.elevationSectors) { elevation ->
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    repeat(details.azimuthSectors) { azimuth ->
                        val id = elevation * details.azimuthSectors + azimuth
                        val state = details.sectors[id] ?: "NOT_SCANNED"
                        val color = when (state) {
                            "GOOD" -> OrbitGreen
                            "WEAK" -> OrbitYellow
                            else -> OrbitRed
                        }
                        Box(
                            modifier = Modifier
                                .size(14.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(color.copy(alpha = 0.82f))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ProcessingCard(
    details: ScanSessionWriter.ProjectDetails,
    isProcessing: Boolean,
    processingStatus: ReconstructionStatus?,
    onProcessClick: () -> Unit
) {
    val currentProgress = processingStatus?.progress ?: details.processingProgress
    val currentStage = processingStatus?.title ?: details.processingStage

    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Обработка", fontWeight = FontWeight.Bold)
            if (!details.summary.resultModelPath.isNullOrBlank()) {
                Text("Модель готова: ${details.summary.resultModelPath}", style = MaterialTheme.typography.bodySmall)
            } else {
                Text(currentStage ?: "Серверная реконструкция ещё не запускалась")
                if (isProcessing || currentProgress > 0) {
                    LinearProgressIndicator(
                        progress = { currentProgress / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                Button(onClick = onProcessClick, enabled = !isProcessing && details.frames.isNotEmpty()) {
                    Text(if (isProcessing) "Обработка…" else "Отправить на обработку")
                }
                if (details.frames.isEmpty()) {
                    Text("Нет сохранённых кадров. Сначала сделайте скан.", color = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun ActionButtons(
    hasModel: Boolean,
    onBackClick: () -> Unit,
    onContinueScanClick: () -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedButton(onClick = onBackClick, modifier = Modifier.weight(1f)) { Text("Домой") }
        Button(onClick = onContinueScanClick, modifier = Modifier.weight(1f)) {
            Text(if (hasModel) "Новый скан" else "Доснять")
        }
    }
}

@Composable
private fun FrameRow(frame: ScanSessionWriter.FrameSummary) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Сектор ${frame.sectorId} · Q${frame.qualityScore}/5", fontWeight = FontWeight.SemiBold)
            Text(
                "Свет ${(frame.brightnessScore * 100).toInt()}% · резкость ${(frame.blurScore * 100).toInt()}% · depth ${if (frame.hasDepth) "есть" else "нет"}",
                style = MaterialTheme.typography.bodySmall
            )
            if (frame.pointCloudPath != null) {
                Text("Point cloud: ${frame.depthPointCount} точек", style = MaterialTheme.typography.bodySmall)
            }
            Text(
                text = File(frame.imagePath).name.ifBlank { frame.imagePath },
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
