package com.karas.orbitscan.domain.model

enum class ScanMode(val title: String, val description: String) {
    ObjectOrbitScan(
        title = "Object Orbit Scan",
        description = "Основной MVP-режим: пользователь обходит объект по кругу."
    ),
    CarScan(
        title = "Car Scan",
        description = "Будущий режим для автомобиля: круги, колёса, крыша, углы."
    ),
    SmallObjectScan(
        title = "Small Object Scan",
        description = "Будущий режим для маленьких объектов на столе."
    )
}
