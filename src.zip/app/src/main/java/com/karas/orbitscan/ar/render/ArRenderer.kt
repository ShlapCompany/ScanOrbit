package com.karas.orbitscan.ar.render

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import com.google.ar.core.DepthPoint
import com.google.ar.core.HitResult
import com.google.ar.core.Plane
import com.google.ar.core.Point
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import com.karas.orbitscan.ar.CameraPoseTracker
import com.karas.orbitscan.domain.model.Vector3
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * Этап 2-3: GLSurfaceView.Renderer, который на каждом кадре:
 *  1) отдаёт ARCore текстуру камеры (setCameraTextureName);
 *  2) дёргает session.update();
 *  3) рисует фон-камеру;
 *  4) пробрасывает pose + trackingState наружу;
 *  5) Этап 3: обрабатывает tap-to-select через Frame.hitTest(x, y).
 *
 * Тяжёлую доменную логику (сектора/качество/кадры) тут НЕ делаем — только низкоуровневые
 * ARCore-события. ViewModel получает уже готовый center в AR-пространстве.
 */
class ArRenderer(
    private val sessionProvider: () -> Session?,
    private val poseTracker: CameraPoseTracker,
    private val onTrackingState: (Boolean) -> Unit,
    private val onPoseUpdated: () -> Unit,
    private val onObjectCenterSelected: (center: Vector3, screenXFraction: Float, screenYFraction: Float) -> Unit,
    private val onObjectSelectionFailed: () -> Unit,
    // Этап 5: вызывается на GL-потоке КАЖДЫЙ tracking-кадр. Получатель (через ViewModel)
    // решает, нужно ли захватывать кадр, и если да — синхронно работает с frame
    // (acquireCameraImage валиден только в пределах этого вызова).
    private val onArFrameForCapture: (frame: com.google.ar.core.Frame) -> Unit
) : GLSurfaceView.Renderer {

    private val backgroundRenderer = CameraBackgroundRenderer()
    private var viewportWidth = 0
    private var viewportHeight = 0
    private var viewportChanged = false

    @Volatile
    private var pendingTap: TapRequest? = null

    /** Вызывается из UI-потока при ACTION_UP на GLSurfaceView. Обрабатывается на GL-потоке. */
    fun queueObjectSelectionTap(x: Float, y: Float) {
        pendingTap = TapRequest(x = x, y = y)
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0.02f, 0.06f, 0.09f, 1.0f)
        backgroundRenderer.createOnGlThread()
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        viewportWidth = width
        viewportHeight = height
        viewportChanged = true
        GLES20.glViewport(0, 0, width, height)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)
        val session = sessionProvider() ?: return

        // Привязываем нашу OES-текстуру к сессии (один раз достаточно, но безопасно каждый кадр).
        session.setCameraTextureName(backgroundRenderer.textureId)

        if (viewportChanged && viewportWidth > 0 && viewportHeight > 0) {
            // Сообщаем ARCore об ориентации/размере дисплея (rotation 0 — портрет по умолчанию).
            session.setDisplayGeometry(0, viewportWidth, viewportHeight)
            viewportChanged = false
        }

        try {
            val frame = session.update()
            backgroundRenderer.draw(frame)

            val camera = frame.camera
            val tracking = camera.trackingState == TrackingState.TRACKING
            onTrackingState(tracking)

            if (tracking) {
                poseTracker.onArCorePose(camera.pose, frame.timestamp)
                onPoseUpdated()
                processPendingTap(frame)
                // Этап 5: отдаём живой frame для возможного захвата (решение — снаружи).
                onArFrameForCapture(frame)
            } else {
                // Если пользователь тапнул во время потери tracking, сразу сообщаем, что выбрать нельзя.
                if (pendingTap != null) {
                    pendingTap = null
                    onObjectSelectionFailed()
                }
            }
        } catch (e: CameraNotAvailableException) {
            // Камера временно недоступна (например, свернули приложение) — пропускаем кадр.
        } catch (e: Throwable) {
            // Никогда не роняем GL-поток из-за одного плохого кадра.
        }
    }

    private fun processPendingTap(frame: com.google.ar.core.Frame) {
        val tap = pendingTap ?: return
        pendingTap = null

        val hit = frame.hitTest(tap.x, tap.y).firstOrNull { it.isUsableForObjectCenter() }
        if (hit == null || viewportWidth <= 0 || viewportHeight <= 0) {
            onObjectSelectionFailed()
            return
        }

        val pose = hit.hitPose
        val center = Vector3(pose.tx(), pose.ty(), pose.tz())
        onObjectCenterSelected(
            center,
            (tap.x / viewportWidth.toFloat()).coerceIn(0f, 1f),
            (tap.y / viewportHeight.toFloat()).coerceIn(0f, 1f)
        )
    }

    private fun HitResult.isUsableForObjectCenter(): Boolean {
        val t = trackable
        return when (t) {
            is Plane -> t.trackingState == TrackingState.TRACKING && t.isPoseInPolygon(hitPose)
            is Point -> t.trackingState == TrackingState.TRACKING
            is DepthPoint -> t.trackingState == TrackingState.TRACKING
            else -> false
        }
    }

    private data class TapRequest(
        val x: Float,
        val y: Float
    )
}
