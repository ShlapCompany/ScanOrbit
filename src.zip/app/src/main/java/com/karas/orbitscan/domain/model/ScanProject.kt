package com.karas.orbitscan.domain.model

import java.time.Instant

data class ScanProject(
    val id: String,
    val name: String,
    val mode: ScanMode,
    val createdAt: Instant,
    val updatedAt: Instant,
    val status: ScanStatus,
    val coveragePercent: Int,
    val frameCount: Int,
    val thumbnailPath: String? = null,
    val localPath: String? = null,
    val resultModelPath: String? = null,
    val serverJobId: String? = null
)
