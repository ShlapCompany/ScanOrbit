# OrbitScan — следующие хвосты после export + GLB viewer

Сейчас в приложении есть:

- ARCore capture pipeline;
- выбор центра объекта;
- карта покрытия;
- quality analyzer;
- сохранение кадров и scan_session.json;
- depth/point cloud preview;
- mock reconstruction;
- экспорт GLB/ZIP через системный диалог;
- встроенный GLB viewer на SceneView/Filament.

Что осталось делать дальше:

1. Реальный backend вместо `MockReconstructionApi`:
   - FastAPI endpoints;
   - загрузка ZIP/кадров/metadata;
   - очередь задач;
   - COLMAP/OpenMVS pipeline;
   - возврат готового `model.glb`.

2. Клиентский API вместо mock:
   - Retrofit/Ktor;
   - `POST /scan-jobs`;
   - upload;
   - polling статуса;
   - download результата.

3. Настройки:
   - DataStore;
   - адрес локального/удалённого backend;
   - качество фото;
   - depth on/off;
   - минимальная задержка между кадрами.

4. UX:
   - досъёмка существующего проекта;
   - удаление проекта с сервера;
   - экран логов обработки;
   - отдельный полноэкранный model viewer.
