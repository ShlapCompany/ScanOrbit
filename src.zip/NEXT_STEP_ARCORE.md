# Прогресс по этапам OrbitScan

## ✅ Этап 1 — каркас (UI, экраны, модели, CoverageMap, симуляция)
## ✅ Этап 2 — настоящая ARCore-камера (Session, preview, pose, tracking, fallback)
## ✅ Этап 3 — выбор центра объекта через hit test + размер объекта
## ✅ Этап 4 — сетка покрытия (фактически закрыт ещё на Этапе 2-3: CoverageMap,
   сектора по реальной позиции камеры, проценты, подсказки)

## ✅ Этап 5 — захват реальных кадров (СДЕЛАНО в этой итерации)

Новые файлы (storage/):
- `FrameImageSaver.kt` — YUV_420_888 (frame.acquireCameraImage()) -> NV21 -> JPEG.
  Учитывает rowStride/pixelStride. Запись файла отдельным методом (для фона).
- `FileStorageManager.kt` — структура проекта на диске (filesDir/scans/<id>/):
  frames/, preview/, logs/, scan_session.json. Имена кадров frame_0001.jpg.
  Есть deleteProject() и listProjectIds().
- `ScanSessionWriter.kt` — сериализация сессии и кадров в scan_session.json
  через org.json (без новых зависимостей). Поля по разделам 9.1/9.2 ТЗ:
  pose, intrinsics, sectorId, quality, hasDepth и т.д.
- `ScanFrameCaptureCoordinator.kt` — ядро захвата:
  * capture(frame, ...) ВЫЗЫВАЕТСЯ НА GL-ПОТОКЕ;
  * acquireCameraImage().use{} — байты JPEG извлекаются синхронно, Image сразу закрывается;
  * pose + intrinsics (camera.imageIntrinsics) снимаются с того же кадра;
  * запись файла уходит в single-thread executor (фон);
  * готовый ScanFrame возвращается через колбэк.

Изменённые файлы:
- `ar/render/ArRenderer.kt` — добавлен колбэк `onArFrameForCapture(frame)`,
  вызывается на GL-потоке каждый tracking-кадр.
- `ui/scan/ArCameraView.kt` — прокидывает onArFrameForCapture БЕЗ mainHandler
  (захват обязан идти на GL-потоке).
- `ui/scan/ScanViewModel.kt`:
  * `attachCaptureCoordinator()` — внедрение координатора;
  * `onArPose()` теперь ТОЛЬКО обновляет индикаторы (сектор/скорость/подсказки);
  * `onArFrameForCapture()` (GL-поток) — решение о захвате (FrameCapturePolicy) +
    вызов координатора; сектор красится в GOOD ТОЛЬКО после успешного сохранения файла;
  * startScan() заводит projectId и beginProject(); finishScan()/reset() — endProject().
- `ui/scan/ScanScreen.kt` — создаёт FileStorageManager + ScanFrameCaptureCoordinator,
  attach к VM, прокидывает onArFrameForCapture, shutdown координатора в onDispose.

Definition of Done Этапа 5 — выполнено:
- реальные JPEG сохраняются в filesDir/scans/<projectId>/frames/ ✅
- к кадру пишутся pose + intrinsics + sectorId + quality (в объекте ScanFrame) ✅
- захват привязан к принятию сектора (не чаще FrameCapturePolicy) ✅
- зелёная зона = реально сохранённый кадр ✅
- Image корректно закрывается (нет утечки / ResourceExhausted) ✅
- запись не блокирует GL-поток (фоновый executor) ✅

ИЗВЕСТНЫЕ TODO (осознанные упрощения, НЕ баги):
1. scan_session.json пишется не автоматически — ScanSessionWriter готов, но его
   вызов надо подключить на Этапе 8 (в finishScan, собрав SessionMeta + savedFrames).
2. QualityAnalyzer всё ещё estimateStub (яркость/блюр захардкожены ~0.7).
   Реальный анализ пикселей — Этап 6.
3. depth/confidence не сохраняются (depthPath/confidencePath = null). Этап 7.
4. Чтение uiState.coverageMap идёт с GL-потока, запись с main — для MVP ок
   (FrameCapturePolicy.markCaptured защищает от двойного захвата сектора).

---

## ⏭️ Следующий — на выбор:

### Этап 8 — сохранение проектов (рекомендую следующим)
- Подключить ScanSessionWriter.write() в finishScan(): собрать SessionMeta
  (deviceModel = Build.MODEL, androidVersion = Build.VERSION.SDK_INT, appVersion,
  depthSupported из sessionManager.isDepthSupported, objectCenter, objectRadius,
  azimuth/elevationSectors, coveragePercent, sectorStates).
- Заменить ScanProjectRepository.demoProjects() на чтение реальных проектов
  из FileStorageManager.listProjectIds() + парсинг scan_session.json.
- Показать реальные проекты на HomeScreen, открытие/удаление.

### Этап 6 — реальный QualityAnalyzer
- Яркость: средняя по Y-плоскости (она уже есть в YUV image).
- Блюр: вариация лапласиана по downscaled Y.
- Подключить в onArFrameForCapture вместо estimateStub.

### Этап 7 — depth/point cloud
- frame.acquireDepthImage16Bits() при isDepthSupported.
- Сохранять depth PNG + confidence; показать грубую point cloud в предпросмотре.

## Заметки API ARCore (проверено)
- frame.acquireCameraImage() -> Image YUV_420_888 (закрывать обязательно!).
- camera.imageIntrinsics: .focalLength{fx,fy}, .principalPoint{cx,cy}, .imageDimensions{w,h}.
- YUV->JPEG: YuvImage(NV21).compressToJpeg(...). Учитывать rowStride/pixelStride.

---

## ✅ Этап 8 — сохранение проектов (СДЕЛАНО)
- ScanSessionWriter.readSummary() — парсит scan_session.json -> ProjectSummary.
- ScanProjectRepository переписан: loadProjects() читает реальные папки
  filesDir/scans/<id>/scan_session.json, deleteProject() удаляет.
- ScanViewModel.attachStorage(...) + persistSessionJson() в finishScan():
  собирает SessionMeta (Build.MODEL, SDK_INT, depthSupported, центр, сектора,
  coverage) + savedFrames -> пишет scan_session.json в фоне.
- HomeScreen: реальный список проектов, пустое состояние, удаление, авто-обновление.
- Дизайн (Этап 5.2): тема Inter + iOS-палитра + GlassPanel применены глобально.

TODO для Этапа 9 (сервер) / доработок:
- Открытие конкретного проекта в предпросмотре (сейчас onOpenProjectClick без id;
  нужно прокинуть projectId и грузить кадры/JSON выбранного проекта).
- thumbnail.jpg не генерируется (можно сохранять первый принятый кадр как превью).
- Переименование проекта (сейчас имя авто: "Скан <дата>").
