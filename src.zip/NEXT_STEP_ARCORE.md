# Следующий этап для Claude: Этап 2 — настоящая ARCore-камера

Контекст: в проекте уже есть Compose UI, экраны, модели данных, CoverageMap, ScanViewModel и заглушки `ArSessionManager`, `CameraPoseTracker`.

Задача: заменить фейковый экран камеры на настоящую ARCore-сессию.

## Что сделать

1. Запросить runtime permission `CAMERA`.
2. Проверить ARCore availability.
3. Если ARCore не поддерживается — показать fallback-сообщение и оставить режим ручного фотосканирования.
4. Создать ARCore `Session`.
5. Настроить session config:
   - plane finding можно включить для hit test;
   - DepthMode AUTOMATIC, если поддерживается;
   - InstantPlacementMode можно не включать в MVP.
6. Показывать camera preview через GLSurfaceView или другой безопасный renderer.
7. На каждом frame получать:
   - `frame.camera.trackingState`;
   - `frame.camera.pose`;
   - `camera.imageIntrinsics`;
   - `camera.textureIntrinsics`.
8. Передать pose в `CameraPoseTracker`.
9. Подключить расчёт текущего сектора через `CoverageMap.sectorForCameraPosition(...)`.
10. Пока не сохранять реальные фото, но уже обновлять текущий сектор по реальному положению камеры.

## Важно

Не трогай серверную реконструкцию. Не добавляй COLMAP. Не усложняй UI. Нужно только заставить приложение реально видеть ARCore tracking и менять текущий сектор по движению телефона.

## Definition of Done

Этап считается готовым, если:

- приложение запрашивает разрешение камеры;
- на поддерживаемом устройстве запускается ARCore camera preview;
- приложение показывает tracking status;
- при движении телефона вокруг выбранного центра меняется текущий sectorId;
- приложение не падает на устройстве без Depth API;
- при отсутствии ARCore показывается понятный fallback.
