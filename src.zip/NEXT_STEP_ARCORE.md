# OrbitScan — следующие шаги

Текущая версия закрывает важные хвосты MVP:

- экспорт GLB и ZIP проекта через системный file picker;
- встроенный GLB viewer через SceneView/Filament;
- отдельный fullscreen viewer;
- mock GLB для проверки viewer/export;
- локальный depth-preview GLB из ARCore Depth/Raw Depth точек.

Что остаётся для настоящей 3D-модели:

1. Backend/PC reconstruction pipeline:
   - загрузка ZIP/кадров;
   - COLMAP feature extraction/matching/mapper;
   - OpenMVS densify/mesh/texture;
   - экспорт GLB;
   - скачивание результата в приложение.

2. Улучшить локальную depth-реконструкцию:
   - лучше трансформировать depth-точки в world-space;
   - добавить цвет точкам по camera image;
   - экспортировать PLY/GLB point cloud;
   - фильтровать выбросы;
   - добавлять simple meshing только при достаточном depth.

3. Настройки:
   - DataStore;
   - переключатель Depth API;
   - частота кадров;
   - качество JPEG;
   - серверный URL.

4. Досъёмка существующего проекта:
   - открыть старый проект;
   - продолжить сканирование с текущей CoverageMap;
   - обновить scan_session.json.
