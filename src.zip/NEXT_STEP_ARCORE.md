# OrbitScan — следующий шаг после этапов 6/7/9/10

## Что закрыто в текущем архиве

- Этап 6: реальный QualityAnalyzer по Y-плоскости camera image.
- Этап 7: depth/confidence PNG + PLY point cloud, если устройство отдаёт ARCore Depth.
- Этап 9: mock backend pipeline и клиентская архитектура `reconstruction/`.
- Этап 10: результат обработки появляется как `output/model.glb`; экран предпросмотра умеет обнаружить и проверить GLB.
- Мелкие хвосты: открытие конкретного проекта с главного экрана, thumbnail первого кадра, чтение реальных проектов, удаление.

## Что делать дальше

### 1. Подключить настоящий backend вместо mock

Заменить `MockReconstructionApi` на реальный клиент:

- `POST /scan-jobs`
- `POST /scan-jobs/{id}/upload`
- `GET /scan-jobs/{id}`
- `GET /scan-jobs/{id}/result`
- `GET /scan-jobs/{id}/logs`

`UploadManager.buildManifest(projectId)` уже собирает список файлов проекта.

### 2. Реальный GLB-viewer на телефоне

Текущий экран результата — GLB inspector. Следующий хвост: подключить Filament/SceneView и заменить `GlbResultPanel` на настоящий 3D-viewer:

- orbit camera;
- pinch zoom;
- reset camera;
- texture on/off;
- later: wireframe.

### 3. Досъёмка существующего проекта

Сейчас `Доснять` открывает новый ScanScreen. Нужно прокинуть `projectId` в ScanScreen и загрузить старые сектора/кадры, чтобы продолжать тот же проект.

### 4. Экспорт проекта

Добавить экспорт ZIP:

- frames/;
- depth/;
- scan_session.json;
- preview_points.ply;
- output/model.glb, если есть.

### 5. Настройки через DataStore

Подключить реальные настройки:

- JPEG quality;
- useDepth;
- saveDepthConfidence;
- minDelayMillis;
- server URL;
- advanced hints.
